#ifndef DECODE_H
#define DECODE_H

#include "types.h"

/*
 * -----------------------------------------------------------------
 *  Decoding pipeline (skeleton)
 *
 *  stego_image.bmp  --->  output.<original-extn>
 * -----------------------------------------------------------------
 */
class Decoder
{

    private:
    DecodeInfo &m_info;
    
public:
    explicit Decoder(DecodeInfo &info) : m_info(info) {}

    // Top level driver - calls every stage below, in order.
    Status do_decoding();

    // Stage 1: open the stego image, validate
    Status open_files();

    // Stage 2: skip past the 54-byte BMP header (nothing hidden there)
    Status skip_bmp_header();

    // Stage 3: decode magic string & confirm it matches MAGIC_STRING
    Status decode_and_check_magic_string();

    // Stage 4: decode secret file's original extension
    Status decode_secret_file_extn();

    // Stage 5: decode the size (in bytes) of the secret file
    Status decode_secret_file_size();

    // Stage 6: decode the secret data itself and write it to output
    Status decode_secret_file_data();

    // ---- low level helpers ----
    char decode_byte_from_lsb(char *image_buffer);
    int decode_size_from_lsb(char *image_buffer);
    Status decode_data_from_image(char *data, int size,
                                   std::ifstream &fptr_stego_image);
    int decode_int_from_image(std::ifstream &fptr_stego_image);


};

#endif // DECODE_H
