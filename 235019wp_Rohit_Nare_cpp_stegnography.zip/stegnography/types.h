#ifndef TYPES_H
#define TYPES_H

#include <fstream>
#include <string>

/*
 * ---------------------------------------------------------------
 *  Common types & constants used across Encode / Decode modules
 * ---------------------------------------------------------------
 */

// Magic string embedded right after the secret-file-size, used to
// verify (while decoding) that this image was actually steganographed
// by this application and not a random/unrelated BMP file.
const std::string MAGIC_STRING = "#*";

// Standard BMP header size (bytes 0-53) for 24-bit uncompressed BMPs.
const unsigned int BMP_HEADER_SIZE = 54;

// Return status used by every stage of the pipeline.
enum class Status
{
    SUCCESS,
    FAILURE
};

// Operation requested by the user on the command line.
enum class OperationType
{
    ENCODE,
    DECODE,
    UNSUPPORTED
};

// encoding class
struct EncodeInfo
{
    //  Source image  
    std::string src_image_fname;
    std::ifstream fptr_src_image;

    //  Secret file 
    std::string secret_fname;
    std::ifstream fptr_secret;

    long secret_file_size;
    char extn_secret_file[5];

    //  Output of encoding = (stego) image 

    std::string stego_image_fname;
    std::ofstream fptr_stego_image;

    // Scratch buffer used while copying pixel data, 1 byte -> 1 bit
    char image_data[8];
};

//class for decoding.
struct DecodeInfo
{
    std::string stego_image_fname;
    std::ifstream fptr_stego_image;

    std::string output_fname;
    std::ofstream fptr_output;

    long secret_file_size;
    char extn_secret_file[5];

    char image_data[8];
};

#endif // TYPES_H
