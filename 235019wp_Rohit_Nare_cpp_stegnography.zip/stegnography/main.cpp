#include <iostream>
#include <cstring>
#include "types.h"
#include "encode.h"
#include "decode.h"

using namespace std;

/*
 * -----------------------------------------------------------------
 *  LSB Image Steganography - CLI driver
 *
 *  Usage:
 *    Encode : ./lsb_steg -e <cover.bmp> <secret_file> [stego_output.bmp]
 *    Decode : ./lsb_steg -d <stego.bmp> [output_base_name]
 *
 *  Examples:
 *    ./lsb_steg -e cover.bmp secret.txt stego.bmp
 *    ./lsb_steg -d stego.bmp decoded
 *        -> produces decoded.txt (extension recovered automatically)
 * -----------------------------------------------------------------
 */

static void print_usage(const char *prog_name)
{
    cout << "Usage:\n"
              << "  Encode : " << prog_name << " -e <cover.bmp> <secret_file> [stego_output.bmp]\n"
              << "  Decode : " << prog_name << " -d <stego.bmp> [output_base_name]\n";
}

static OperationType check_operation_type(const char *arg)
{
    if (strcmp(arg, "-e") == 0)
        return OperationType::ENCODE;
    if (strcmp(arg, "-d") == 0)
        return OperationType::DECODE;
    return OperationType::UNSUPPORTED;
}

int main(int argc, char *argv[])
{
    if (argc < 3)
    {
        print_usage(argv[0]);
        return 1;
    }

    OperationType op_type = check_operation_type(argv[1]);

    switch (op_type)
    {
    case OperationType::ENCODE:
    {
        if (argc < 4)
        {
            std::cout << "ERROR: Missing arguments for encoding\n";
            print_usage(argv[0]);
            return 1;
        }

        EncodeInfo info; // encode structure

        info.src_image_fname = argv[2];
        info.secret_fname = argv[3];
        info.stego_image_fname = (argc >= 5) ? argv[4] : "stego_image.bmp";

        /*cout << info.src_image_fname<<"\n";
        cout << info.secret_fname<<"\n";
        cout << info.stego_image_fname<<"\n";*/


        Encoder encoder(info);
        
        if (encoder.do_encoding() == Status::SUCCESS)
        {
            std::cout << "INFO: Encoding completed successfully -> "
                      << info.stego_image_fname << "\n";
        }
        else
        {
            std::cerr << "ERROR: Encoding failed\n";
            return 1;
        }
        break;
    }

    case OperationType::DECODE:
    {
        DecodeInfo info;
        info.stego_image_fname = argv[2];
        info.output_fname = (argc >= 4) ? argv[3] : "decoded_output";

        Decoder decoder(info);
        if (decoder.do_decoding() == Status::SUCCESS)
        {
            std::cout << "INFO: Decoding completed successfully -> "
                      << info.output_fname << "\n";
        }
        else
        {
            std::cerr << "ERROR: Decoding failed\n";
            return 1;
        }
        break;
    }

    default:
        std::cerr << "ERROR: Unsupported operation. Use -e (encode) or -d (decode)\n";
        print_usage(argv[0]);
        return 1;
    }

    return 0;
}
