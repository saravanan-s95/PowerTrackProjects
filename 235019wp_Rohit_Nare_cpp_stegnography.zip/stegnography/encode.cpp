#include <iostream>
#include <cstring>
#include "encode.h"

/*
 * do_encoding()
 * -------------
 * Drives the entire encode pipeline, stage by stage. If any stage
 * fails, we bail out immediately with a helpful error message.
 */
Status Encoder::do_encoding()
{
    if (open_files() == Status::FAILURE)
    {
        std::cerr << "ERROR: Unable to open required files\n";
        return Status::FAILURE;
    }

    if (check_capacity() == Status::FAILURE)
    {
        std::cerr << "ERROR: Image doesn't have enough capacity to "
                     "hold the secret file\n";
        return Status::FAILURE;
    }

    if (copy_bmp_header() == Status::FAILURE)
    {
        std::cerr << "ERROR: Failed to copy BMP header\n";
        return Status::FAILURE;
    }

    if (encode_magic_string() == Status::FAILURE)
    {
        std::cerr << "ERROR: Failed to encode magic string\n";
        return Status::FAILURE;
    }

    if (encode_secret_file_extn() == Status::FAILURE)
    {
        std::cerr << "ERROR: Failed to encode secret file extension\n";
        return Status::FAILURE;
    }

    if (encode_secret_file_size() == Status::FAILURE)
    {
        std::cerr << "ERROR: Failed to encode secret file size\n";
        return Status::FAILURE;
    }

    if (encode_secret_file_data() == Status::FAILURE)
    {
        std::cerr << "ERROR: Failed to encode secret file data\n";
        return Status::FAILURE;
    }

    if (copy_remaining_img_data() == Status::FAILURE)
    {
        std::cerr << "ERROR: Failed to copy remaining image data\n";
        return Status::FAILURE;
    }

    return Status::SUCCESS;
}

//open_files()

Status Encoder::open_files()
{
    m_info.fptr_src_image.open(m_info.src_image_fname, std::ios::binary);
    if (!m_info.fptr_src_image)
    {
        std::cerr << "ERROR: Unable to open source image file "
                  << m_info.src_image_fname << "\n";
        return Status::FAILURE;
    }

    m_info.fptr_secret.open(m_info.secret_fname, std::ios::binary);
    if (!m_info.fptr_secret)
    {
        std::cerr << "ERROR: Unable to open secret file "
                  << m_info.secret_fname << "\n";
        return Status::FAILURE;
    }

    m_info.fptr_stego_image.open(m_info.stego_image_fname, std::ios::binary);
    if (!m_info.fptr_stego_image)
    {
        std::cerr << "ERROR: Unable to open output stego image file "
                  << m_info.stego_image_fname << "\n";
        return Status::FAILURE;
    }

    // Pull out the secret file's extension (".txt", ".c" etc.) for
    // later use while decoding.
    size_t dot_pos = m_info.secret_fname.find_last_of('.');
    std::string extn = (dot_pos == std::string::npos)? "" : m_info.secret_fname.substr(dot_pos);
    std::strncpy(m_info.extn_secret_file, extn.c_str(), 4);
    m_info.extn_secret_file[4] = '\0';

    return Status::SUCCESS;
}

/*
 * get_file_size()
 * ---------------
 * Returns size, in bytes, of the already-open secret file.
 */
long Encoder::get_file_size()
{
    m_info.fptr_secret.seekg(0, std::ios::end);
    long size = m_info.fptr_secret.tellg();
    m_info.fptr_secret.seekg(0, std::ios::beg);
    return size;
}

/*
 get_image_capacity()
 */
long Encoder::get_image_capacity()
{
    m_info.fptr_src_image.seekg(0, std::ios::end);
    long file_size = m_info.fptr_src_image.tellg();
    m_info.fptr_src_image.seekg(BMP_HEADER_SIZE, std::ios::beg);

    long pixel_data_size = file_size - BMP_HEADER_SIZE;
    return pixel_data_size / 8;
}

/*
 * check_capacity()
 * -----------------
 * Confirms the cover image can hold:
 *   magic string + 4-byte extn size + extn + 4-byte secret size + secret data
 */
Status Encoder::check_capacity()
{
    long image_capacity = get_image_capacity();
    m_info.secret_file_size = get_file_size();

    long required = MAGIC_STRING.size()
                     + sizeof(int) + std::strlen(m_info.extn_secret_file)
                     + sizeof(int) + m_info.secret_file_size;

    if (image_capacity < required)
    {
        return Status::FAILURE;
    }

    std::cout << "INFO: Image capacity   = " << image_capacity << " bytes\n";
    std::cout << "INFO: Secret file size = " << m_info.secret_file_size << " bytes\n";

    return Status::SUCCESS;
}

/*
 * copy_bmp_header()
 * ------------------
 * The first 54 bytes of a BMP file are the header - copied verbatim,
 * nothing is hidden here (modifying it could corrupt the image).
 */
Status Encoder::copy_bmp_header()
{
    char header[BMP_HEADER_SIZE];

    m_info.fptr_src_image.seekg(0, std::ios::beg);
    m_info.fptr_src_image.read(header, BMP_HEADER_SIZE);
    if (!m_info.fptr_src_image)
        return Status::FAILURE;

    m_info.fptr_stego_image.write(header, BMP_HEADER_SIZE);
    if (!m_info.fptr_stego_image)
        return Status::FAILURE;

    return Status::SUCCESS;
}

/*
 * encode_byte_to_lsb()
 * ---------------------
 * Takes ONE byte of real data and hides each of its 8 bits inside
 * the LSB of 8 consecutive bytes of image pixel data.
 */
Status Encoder::encode_byte_to_lsb(char data, char *image_buffer)
{
    for (int bit = 0; bit < 8; bit++)
    {
        int bit_value = (data >> (7 - bit)) & 1;

        // Clear the LSB, then set it to our bit value
        image_buffer[bit] = (image_buffer[bit] & 0xFE) | bit_value;
    }
    return Status::SUCCESS;
}

/*
 * encode_data_to_image()
 * ------------------------
 * Reads `size` bytes of pixel data from the source image (8 bytes
 * per character of `data`), hides each character, and writes the
 * result out to the stego image.
 */
Status Encoder::encode_data_to_image(const char *data, int size,
                                      std::ifstream &fptr_src_image,
                                      std::ofstream &fptr_stego_image)
{
    char image_buffer[8];

    for (int i = 0; i < size; i++)
    {
        fptr_src_image.read(image_buffer, 8);
        if (!fptr_src_image)
            return Status::FAILURE;

        encode_byte_to_lsb(data[i], image_buffer);

        fptr_stego_image.write(image_buffer, 8);
        if (!fptr_stego_image)
            return Status::FAILURE;
    }
    return Status::SUCCESS;
}

/*
 * encode_size_to_lsb() / encode_int_to_image()
 * -----------------------------------------------
 * An `int` (4 bytes) is hidden across 32 bytes of pixel data -
 * i.e. treat the int as 4 chars and reuse encode_byte_to_lsb().
 */
Status Encoder::encode_int_to_image(int data, std::ifstream &fptr_src_image,
                                     std::ofstream &fptr_stego_image)
{
    char buffer[sizeof(int)];
    std::memcpy(buffer, &data, sizeof(int));
    return encode_data_to_image(buffer, sizeof(int), fptr_src_image, fptr_stego_image);
}

Status Encoder::encode_magic_string()
{
    return encode_data_to_image(MAGIC_STRING.c_str(), MAGIC_STRING.size(),
                                 m_info.fptr_src_image, m_info.fptr_stego_image);
}

Status Encoder::encode_secret_file_extn()
{
    int extn_size = std::strlen(m_info.extn_secret_file);

    if (encode_int_to_image(extn_size, m_info.fptr_src_image,
                             m_info.fptr_stego_image) == Status::FAILURE)
        return Status::FAILURE;

    return encode_data_to_image(m_info.extn_secret_file, extn_size,
                                 m_info.fptr_src_image, m_info.fptr_stego_image);
}

Status Encoder::encode_secret_file_size()
{
    return encode_int_to_image((int)m_info.secret_file_size,
                                m_info.fptr_src_image, m_info.fptr_stego_image);
}

/*
 * encode_secret_file_data()
 * ----------------------------
 * Reads the secret file in chunks and hides it, chunk by chunk, so
 * we don't need to load the whole secret file into memory at once.
 */
Status Encoder::encode_secret_file_data()
{
    char buffer[1024];
    long remaining = m_info.secret_file_size;

    m_info.fptr_secret.seekg(0, std::ios::beg);

    while (remaining > 0)
    {
        long chunk = (remaining > (long)sizeof(buffer)) ? (long)sizeof(buffer) : remaining;

        m_info.fptr_secret.read(buffer, chunk);
        if (!m_info.fptr_secret)
            return Status::FAILURE;

        if (encode_data_to_image(buffer, (int)chunk, m_info.fptr_src_image,
                                  m_info.fptr_stego_image) == Status::FAILURE)
            return Status::FAILURE;

        remaining -= chunk;
    }
    return Status::SUCCESS;
}

/*
 * copy_remaining_img_data()
 * ----------------------------
 * Whatever pixel bytes of the cover image were NOT used to hide
 * data must still be copied across unchanged, or the stego image
 * will be truncated / corrupted.
 */
Status Encoder::copy_remaining_img_data()
{
    char ch;
    while (m_info.fptr_src_image.get(ch))
    {
        m_info.fptr_stego_image.put(ch);
    }
    return Status::SUCCESS;
}
