#ifndef ENCODE_H
#define ENCODE_H

#include "types.h"


class Encoder
{
    private:
    EncodeInfo &m_info;
    
public:
    explicit Encoder(EncodeInfo &info) : m_info(info) {} //constructor

    // Top level driver - calls every stage below, in order.
    Status do_encoding();

    // Stage 1: open src image / secret file / stego image, validate
    Status open_files();

    // Stage 2: does the cover image have enough capacity to hold
    //          the magic string + secret file size + extension +
    //          the secret data itself?
    Status check_capacity();

    // Helper used by check_capacity(): max bytes hideable in image.
    long get_image_capacity();

    // Helper: size, in bytes, of the secret file.
    long get_file_size();

    // Stage 3: copy the 54-byte BMP header as-is (no data hidden here)
    Status copy_bmp_header();

    // Stage 4: encode magic string into LSBs, right after the header
    Status encode_magic_string();

    // Stage 5: encode the secret file's extension (e.g. ".txt")
    Status encode_secret_file_extn();

    // Stage 6: encode the size (in bytes) of the secret file
    Status encode_secret_file_size();

    // Stage 7: encode the actual secret file data, byte by byte
    Status encode_secret_file_data();

    // Stage 8: copy any leftover image bytes unchanged (unused capacity)
    Status copy_remaining_img_data();

    // ---- low level helpers ----
    Status encode_byte_to_lsb(char data, char *image_buffer);
    Status encode_size_to_lsb(int size, char *image_buffer);
    Status encode_data_to_image(const char *data, int size,
                                 std::ifstream &fptr_src_image,
                                 std::ofstream &fptr_stego_image);
    Status encode_int_to_image(int data, std::ifstream &fptr_src_image,
                                std::ofstream &fptr_stego_image);


};

#endif // ENCODE_H
