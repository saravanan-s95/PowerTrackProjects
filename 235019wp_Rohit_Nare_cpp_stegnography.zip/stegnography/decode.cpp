#include <iostream>
#include <cstring>
#include "decode.h"

Status Decoder::do_decoding()
{
    if (open_files() == Status::FAILURE)
    {
        std::cerr << "ERROR: Unable to open required files\n";
        return Status::FAILURE;
    }

    if (skip_bmp_header() == Status::FAILURE)
    {
        std::cerr << "ERROR: Failed to skip BMP header\n";
        return Status::FAILURE;
    }

    if (decode_and_check_magic_string() == Status::FAILURE)
    {
        std::cerr << "ERROR: Magic string mismatch - this image was "
                     "not steganographed by this tool\n";
        return Status::FAILURE;
    }

    if (decode_secret_file_extn() == Status::FAILURE)
    {
        std::cerr << "ERROR: Failed to decode secret file extension\n";
        return Status::FAILURE;
    }

    if (decode_secret_file_size() == Status::FAILURE)
    {
        std::cerr << "ERROR: Failed to decode secret file size\n";
        return Status::FAILURE;
    }

    // Output filename known only once we've decoded the extension
    m_info.fptr_output.open(m_info.output_fname, std::ios::binary);
    if (!m_info.fptr_output)
    {
        std::cerr << "ERROR: Unable to create output file "
                  << m_info.output_fname << "\n";
        return Status::FAILURE;
    }

    if (decode_secret_file_data() == Status::FAILURE)
    {
        std::cerr << "ERROR: Failed to decode secret file data\n";
        return Status::FAILURE;
    }

    return Status::SUCCESS;
}

Status Decoder::open_files()
{
    m_info.fptr_stego_image.open(m_info.stego_image_fname, std::ios::binary);
    if (!m_info.fptr_stego_image)
    {
        std::cerr << "ERROR: Unable to open stego image file "
                  << m_info.stego_image_fname << "\n";
        return Status::FAILURE;
    }
    return Status::SUCCESS;
}

Status Decoder::skip_bmp_header()
{
    m_info.fptr_stego_image.seekg(BMP_HEADER_SIZE, std::ios::beg);
    return m_info.fptr_stego_image ? Status::SUCCESS : Status::FAILURE;
}

/*
 * decode_byte_from_lsb()
 * ------------------------
 * Reverse of encode_byte_to_lsb(): pulls the LSB out of each of the
 * 8 supplied pixel bytes and reassembles them into one real byte.
 */
char Decoder::decode_byte_from_lsb(char *image_buffer)
{
    char data = 0;
    for (int bit = 0; bit < 8; bit++)
    {
        int bit_value = image_buffer[bit] & 1;
        data = (data << 1) | bit_value;
    }
    return data;
}

Status Decoder::decode_data_from_image(char *data, int size,
                                        std::ifstream &fptr_stego_image)
{
    char image_buffer[8];

    for (int i = 0; i < size; i++)
    {
        fptr_stego_image.read(image_buffer, 8);
        if (!fptr_stego_image)
            return Status::FAILURE;

        data[i] = decode_byte_from_lsb(image_buffer);
    }
    return Status::SUCCESS;
}

int Decoder::decode_int_from_image(std::ifstream &fptr_stego_image)
{
    char buffer[sizeof(int)];
    decode_data_from_image(buffer, sizeof(int), fptr_stego_image);

    int value;
    std::memcpy(&value, buffer, sizeof(int));
    return value;
}

Status Decoder::decode_and_check_magic_string()
{
    int len = MAGIC_STRING.size();
    char buffer[16] = {0};

    if (decode_data_from_image(buffer, len, m_info.fptr_stego_image) == Status::FAILURE)
        return Status::FAILURE;

    buffer[len] = '\0';

    if (MAGIC_STRING != buffer)
        return Status::FAILURE;

    return Status::SUCCESS;
}

Status Decoder::decode_secret_file_extn()
{
    int extn_size = decode_int_from_image(m_info.fptr_stego_image);

    if (extn_size <= 0 || extn_size > 4)
        return Status::FAILURE;

    if (decode_data_from_image(m_info.extn_secret_file, extn_size,
                                m_info.fptr_stego_image) == Status::FAILURE)
        return Status::FAILURE;

    m_info.extn_secret_file[extn_size] = '\0';

    // output_fname was passed in as a base name (e.g. "decoded"); now
    // that we know the real extension, append it.
    m_info.output_fname += m_info.extn_secret_file;

    return Status::SUCCESS;
}

Status Decoder::decode_secret_file_size()
{
    m_info.secret_file_size = decode_int_from_image(m_info.fptr_stego_image);
    return (m_info.secret_file_size > 0) ? Status::SUCCESS : Status::FAILURE;
}

Status Decoder::decode_secret_file_data()
{
    char buffer[1024];
    long remaining = m_info.secret_file_size;

    while (remaining > 0)
    {
        long chunk = (remaining > (long)sizeof(buffer)) ? (long)sizeof(buffer) : remaining;

        if (decode_data_from_image(buffer, (int)chunk, m_info.fptr_stego_image) == Status::FAILURE)
            return Status::FAILURE;

        m_info.fptr_output.write(buffer, chunk);
        if (!m_info.fptr_output)
            return Status::FAILURE;

        remaining -= chunk;
    }
    return Status::SUCCESS;
}
