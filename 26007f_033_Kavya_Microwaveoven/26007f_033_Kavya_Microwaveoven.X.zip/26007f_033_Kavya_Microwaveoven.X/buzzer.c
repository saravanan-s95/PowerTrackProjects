/*
 * File:   buzzer.c
 * Author: Kavya
 */

#include <xc.h>

#define BUZZER_DDR      TRISC1  
#define BUZZER          RC1

void init_buzzer(void)
{
    BUZZER_DDR = 0;  // Configure buzzer pin as digital output
    BUZZER = 0;      // Turn OFF buzzer initially at startup
}

void buzzer_on(void)
{
    BUZZER = 1;      // Drive pin HIGH to turn on buzzer
}

void buzzer_off(void)
{
    BUZZER = 0;      // Pull pin LOW to turn off buzzer
}
