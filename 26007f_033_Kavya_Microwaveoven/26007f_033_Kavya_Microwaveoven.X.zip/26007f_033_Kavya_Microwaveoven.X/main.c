/*
 * File:   main.c
 * Author: Kavya
 * Description : To develop a microwave oven using PIC16F877A microcontroller on PICSIMLAB BOARD
 *  SW1 : Set cooking time / Increment Key
 *  SW2 : Cursor choose field operation
 *  SW3 : START / PAUSE / RESUME key operation while cooking
 *  SW4 : Stop / cancel key
 * Working : When SW1 is pressed, it flashed 00:00 in clcd. On pressing SW2 it allows to choose the field.
 * Pressing SW3 starts the timer.
 * During that cooking time it checks for the temp if temp > 45 it provide a buzzer sound and also display "OVERHEATED! HALT"
 * Created on 31 October, 2026, 2:33 PM
 */

#include <xc.h>
#include "clcd.h"
#include "digital_keypad.h"
#include "adc.h"
#include "timer.h"
#include "ds1307.h"
#include "i2c.h"
#include "eeprom.h"
#include "buzzer.h"

// State Declarations
#define STATE_WELCOME       0
#define STATE_DISPLAY_INFO  1
#define STATE_INPUT_TIME    2
#define STATE_COOKING       3
#define STATE_PAUSED        4
#define STATE_COMPLETED     5

// Configuration macros
#define TEMP_CUTOFF_VAL     45  // Max Temperature Limit in �C

// Global Volatiles handled by main/ISR
unsigned int tick_count = 0;
unsigned char half_sec_flag = 0;
unsigned char count_down_flag = 0;

void display_welcome_screen(void)
{
    clcd_print("  MICROWAVE OVEN ", LINE1(0));
    clcd_print("  WELCOME HOME  ", LINE2(0));
    __delay_ms(2000);
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
}

void main(void)
{
    unsigned char state = STATE_WELCOME;
    unsigned char clock_reg[3]; // Fixed: Must be an array of 3 elements
    unsigned char key, prev_key = ALL_RELEASED;
    unsigned int sec = 0, min = 0;
    unsigned int adc_val;
    unsigned char temperature;
    char temp_str[6];
    char time_input_str[6] = "00:00";
    unsigned char input_idx = 0;
    unsigned char toggle_blink = 0;

    // Peripheral Initializations
    init_clcd();
    init_digital_keypad();
    init_adc();
    init_i2c(100000); // 100kHz I2C Clock
    init_ds1307();
    init_timer0();
    init_buzzer();

    // Enable Global & Peripheral Interrupts
    PEIE = 1;
    GIE = 1;

    // Load Last execution state/mode from EEPROM if valid
    unsigned char last_mode = read_internal_eeprom(0x00);

    while(1)
    {
        // Continuous Real-Time metrics collection
        get_time(clock_reg);
        adc_val = read_adc(2); // Channel 2 for LM35 Temperature sensor
        temperature = (unsigned char)((adc_val * 500) / 1023); // Conversion for LM35 step voltage

        // Fixed to use STATE_DETECT from your digital_keypad.h
        key = read_digital_keypad(STATE_DETECT);

        switch(state)
        {
            case STATE_WELCOME:
                display_welcome_screen();
                state = STATE_DISPLAY_INFO;
                clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                break;

            case STATE_DISPLAY_INFO:
                clcd_print("TEMP: ", LINE1(0));
                display_time(clock_reg); // Renders real time matrix on Line 2

                temp_str[0] = (char)((temperature / 10) + '0');
                temp_str[1] = (char)((temperature % 10) + '0');
                temp_str[2] = 0xDF; // Degree symbol
                temp_str[3] = 'C';
                temp_str[4] = '\0';
                clcd_print(temp_str, LINE1(6));

                // Check if SW1 is pressed to set custom cooking runtime
                if(key == SW1)
                {
                    state = STATE_INPUT_TIME;
                    sec = 0; 
                    min = 0;
                    input_idx = 0;
                    time_input_str[0] = '0';
                    time_input_str[1] = '0';
                    time_input_str[2] = ':';
                    time_input_str[3] = '0';
                    time_input_str[4] = '0';
                    time_input_str[5] = '\0';
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                break;

            case STATE_INPUT_TIME:
                clcd_print("SET TIME (MM:SS)", LINE1(0));
                
                // Blinking cursor visual aid
                if (half_sec_flag)
                {
                    clcd_print(time_input_str, LINE2(5));
                }
                else
                {
                    clcd_print("     ", LINE2(5));
                }
                
                if (key != ALL_RELEASED && key != prev_key)
                {
                    // SW1 changes digit values cycle 0-9
                    if (key == SW1 && input_idx < 5) 
                    {
                        if(input_idx == 2) input_idx++; // Skip the ':' divider character
                        
                        time_input_str[input_idx]++;
                        if (input_idx == 3 && time_input_str[input_idx] > '5') // Max seconds tens place is 5
                        {
                            time_input_str[input_idx] = '0';
                        }
                        else if (time_input_str[input_idx] > '9')
                        {
                            time_input_str[input_idx] = '0';
                        }
                    }
                    // SW2 advances position index
                    else if (key == SW2)
                    {
                        input_idx++;
                        if(input_idx == 2) input_idx++;
                        if(input_idx >= 5) input_idx = 0; // Wrap around
                    }
                    // SW3 confirms time setting execution
                    else if (key == SW3) 
                    {
                        min = (unsigned int)((time_input_str[0] - '0') * 10 + (time_input_str[1] - '0'));
                        sec = (unsigned int)((time_input_str[3] - '0') * 10 + (time_input_str[4] - '0'));

                        if (sec >= 60 || min > 99 || (sec == 0 && min == 0))
                        {
                            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                            clcd_print("INVALID TIME!", LINE1(0));
                            __delay_ms(1500);
                            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                        }
                        else
                        {
                            write_internal_eeprom(0x00, 0x01); // Save configuration log to EEPROM
                            state = STATE_COOKING;
                            count_down_flag = 1;
                            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                        }
                    }
                    // SW4 cancels input state
                    else if (key == SW4)
                    {
                        state = STATE_DISPLAY_INFO;
                        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    }
                }
                break;

            case STATE_COOKING:
                clcd_print("COOKING IN PROGRESS", LINE1(0));
                if (half_sec_flag != toggle_blink)
                {
                    toggle_blink = half_sec_flag;
                    if(sec == 0 && min == 0)
                    {
                        state = STATE_COMPLETED;
                        count_down_flag = 0;
                    }
                    else if (sec == 0)
                    {
                        sec = 59;
                        min--;
                    }
                    else
                    {
                        sec--;
                    }
                } 
                temp_str[0] = (char)((min / 10) + '0');
                temp_str[1] = (char)((min % 10) + '0');
                temp_str[2] = ':';
                temp_str[3] = (char)((sec / 10) + '0');
                temp_str[4] = (char)((sec % 10) + '0');
                temp_str[5] = '\0'; 
                clcd_print(temp_str, LINE2(5));
                if (temperature >= TEMP_CUTOFF_VAL)
                {
                    count_down_flag = 0;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    clcd_print("OVERHEATED! HALT", LINE1(0));
                    buzzer_on();       // <--- ADD THIS LINE: Sound the safety alert
                    __delay_ms(3000);  // Keep ringing for 3 seconds
                    buzzer_off();      // <--- ADD THIS LINE: Turn it off   
                    state = STATE_DISPLAY_INFO;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                if (key == SW3) // Pause Cooking
                {
                    state = STATE_PAUSED;
                    count_down_flag = 0;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                else if (key == SW4) // Cancel cooking entirely
                {
                    state = STATE_DISPLAY_INFO;
                    count_down_flag = 0;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                break;

            case STATE_PAUSED:
                clcd_print("COOKING PAUSED", LINE1(0));
                clcd_print(temp_str, LINE2(5));
                
                if(key == SW3) // Resume execution
                {
                    state = STATE_COOKING;
                    count_down_flag = 1;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                else if(key == SW4) // Cancel
                {
                    state = STATE_DISPLAY_INFO;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                break;

            case STATE_COMPLETED:
                clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                clcd_print("SUCCESSFULLY DONE", LINE1(0));
                
                buzzer_on();       // <--- ADD THIS LINE: Ring when finished
                __delay_ms(2500);  // Ring for 2.5 seconds
                buzzer_off();      // <--- ADD THIS LINE: Turn off
                
                state = STATE_DISPLAY_INFO;
                clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                break;

        }
        
        prev_key = key;
    }
}
