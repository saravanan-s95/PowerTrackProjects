/*
 * File:   digital_keypad.c
 * Author: Kavya
 *
 * Created on 31 October, 2026, 2:33 PM
 */


#include <xc.h>
#include "digital_keypad.h"
#pragma config WDTE = OFF

void init_digital_keypad(void)
{
    DIGITAL_KEYPAD_DDR = (DIGITAL_KEYPAD_DDR | INPUT_LINES); // set as input
}

unsigned char read_digital_keypad(unsigned char mode)
{
    static unsigned char once = 1; 
    if (mode == LEVEL_DETECT)
    {
        return DIGITAL_KEYPAD & INPUT_LINES;
    }
    else
    {
        if (((DIGITAL_KEYPAD & INPUT_LINES) != ALL_RELEASED) && once)
        {
            once = 0;
            
            return DIGITAL_KEYPAD & INPUT_LINES;
        }
        else if ((DIGITAL_KEYPAD & INPUT_LINES) == ALL_RELEASED)
        {
            once = 1;
        }
    }
    return ALL_RELEASED;
}
