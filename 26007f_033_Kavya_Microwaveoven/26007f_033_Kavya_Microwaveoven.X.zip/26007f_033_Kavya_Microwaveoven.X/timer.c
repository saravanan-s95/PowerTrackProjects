/*
 * File:   timer.c
 * Author: Kavya
 *
 * Created on 31 October, 2026, 2:34 PM
 */


#include <xc.h>
#include "timer.h"
#pragma config WDTE = OFF

void init_timer0(void) 
{
    TMR0 = 6; // start ticking from 6 to 256 (250 ticks)
    T0CS = 0; // internal clk pulse selected
    TMR0IF = 0; // interrupt flag set as zero when interrupt occured flaf set to 1 isr func called itself
    TMR0IE = 1; // overflow interrupt is enabled
}