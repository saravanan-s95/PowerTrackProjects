/* 
 * File:   timer.h
 * Author: Kavya
 *
 * Created on 31 October, 2026, 2:29 PM
 */

#ifndef TIMER_H
#define	TIMER_H

#define  LED_DDR  TRISD
#define  LED      PORTD

void init_timer0(void);

#endif	/* TIMER_H */