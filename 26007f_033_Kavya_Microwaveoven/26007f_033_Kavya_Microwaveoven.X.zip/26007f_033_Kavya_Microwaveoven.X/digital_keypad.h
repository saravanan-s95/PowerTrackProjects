/* 
 * File:   digital_keypad.h
 * Author: Kavya
 *
 * Created on 31 October, 2026, 2:29 PM
 */

#ifndef DIGITAL_KEYPAD_H
#define	DIGITAL_KEYPAD_H

#define  INPUT_LINES  0x3F
#define  DIGITAL_KEYPAD_DDR  TRISB
#define  DIGITAL_KEYPAD      PORTB
#define  LEVEL_DETECT        0
#define  LEVEL               0
#define  STATE_DETECT        1
#define  STATE               1

#define  SW1   0x3E
#define  SW2   0x3D
#define  SW3   0x3B
#define  SW4   0x37
#define  SW5   0x2F
#define  SW6   0x1F
#define  ALL_RELEASED  INPUT_LINES

void init_digital_keypad(void);
unsigned char read_digital_keypad(unsigned char mode);

#endif	/* DIGITAL_KEYPAD_H */
