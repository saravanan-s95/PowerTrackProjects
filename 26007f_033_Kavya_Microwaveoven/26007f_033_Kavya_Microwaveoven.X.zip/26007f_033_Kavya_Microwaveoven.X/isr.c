/*
 * File:   isr.c
 * Author: Kavya
 *
 * Created on 31 October, 2026, 2:46 PM
 */

#include <xc.h>
#include "timer.h"

extern unsigned char half_sec_flag;
extern unsigned int tick_count;
extern unsigned char count_down_flag;

void __interrupt() isr(void)
{
    if(TMR0IF == 1) 
    {
        TMR0 = TMR0 + 8; // Compensate for overhead (approx 250 counts)
        
        if (++tick_count >= 1250) // Assuming ~1.25k overflows = 1 Second (Prescaler dependent)
        {
            tick_count = 0;
            half_sec_flag = !half_sec_flag; // Toggle flag every second
            
            if (count_down_flag)
            {
                // Signifies that a second has passed for cooking timer
            }
        }
        TMR0IF = 0; // Clear interrupt flag
    }
}
