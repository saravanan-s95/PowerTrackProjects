/*
 * File:   eeprom.c
 * Author: Kavya
 *
 * Created on 31 October, 2026, 2:34 PM
 */


#include <xc.h>
#include "eeprom.h"

void write_internal_eeprom(unsigned char address, unsigned char data)
{
    unsigned char gie_status;
    
    EEADR = address;     // Load address
    EEDATA = data;       // Load data
    
    EECON1bits.EEPGD = 0;// Select data EEPROM memory
    EECON1bits.WREN = 1; // Enable write cycle
    
    gie_status = GIE;    // Save interrupt status
    GIE = 0;             // Disable interrupts
    
    // Required unlock sequence
    EECON2 = 0x55;
    EECON2 = 0xAA;
    EECON1bits.WR = 1;   // Initiate write
    
    GIE = gie_status;    // Restore interrupts
    while(EECON1bits.WR);// Wait for write complete
    EECON1bits.WREN = 0; // Disable write cycles
}

unsigned char read_internal_eeprom(unsigned char address)
{
    EEADR = address;     // Load address
    EECON1bits.EEPGD = 0;// Select data EEPROM memory
    EECON1bits.RD = 1;   // Initiate read
    return EEDATA;       // Return read data
}
