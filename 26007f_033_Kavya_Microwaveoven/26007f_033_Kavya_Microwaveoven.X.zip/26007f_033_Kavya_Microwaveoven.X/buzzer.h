/* 
 * File:   buzzer.h
 * Author: Kavya
 *
 * Created on 31 October, 2026, 2:33 PM
 */

#ifndef BUZZER_H
#define	BUZZER_H

void init_buzzer(void);
void buzzer_on(void);
void buzzer_off(void);

#endif	/* BUZZER_H */
