/*
 * File:   login.c
 * Author: HP
 *
 * Created on 14 January, 2026, 9:27 PM
 */


#include <xc.h>
#include "main.h"

unsigned char attempt = 0;



int my_strcmp( unsigned char user_pass[])
{
    for( int i = 0; i < 4 ; i++ )
    {
        if(set_pass[i] != user_pass[i])
        {
            return 1;
        }
        
    }
    return 0;
}

unsigned char login_screen(void)
{
    unsigned char user_pass[5]={0};
    unsigned int pass_digit = 0;
    unsigned int wait_count = 0;
    unsigned int blink_dealy = 0;
    unsigned char flag = 0;
    unsigned char wrong_pass_delay = 0;
    
    
   
 /*  
    clcd_print("                ", LINE2(0));
     while ( 1 )
    {
        
        
        
        char key = read_digital_keypad(STATE);
        
        if(pass_digit < 4)
        {
            if(wait_count++ < 60)
            {
               // clcd_print("Enter Password  ", LINE1(0));
                clcd_print("Enter Password: ", LINE1(0));
                if(blink_dealy++ < 5)
                {
                  //display _
                  clcd_putch('_',LINE2(pass_digit));
                 
                 
                }
                else if(blink_dealy < 10)
                {
                    // display space
                    clcd_putch(' ',LINE2(pass_digit));
                }
                 else
                    blink_dealy = 0;
        
            }
            else 
                return 0;
            
        
            if(key == SW1)
            {
                user_pass[pass_digit] = '0';
                clcd_putch('*',LINE2(pass_digit));
                pass_digit++;
                wait_count = 0;
            }
            else if(key == SW2)
            {
                user_pass[pass_digit] = '1';
                clcd_putch('*',LINE2(pass_digit));

                pass_digit++;
                wait_count = 0;
            }
        }
        else if( pass_digit == 4 && flag == 0)
        {
            user_pass[pass_digit] = '\0';
            
            if(my_strcmp(user_pass) == 0)
            {
                flag =1;
                attempt = 0;
                
            }
            else
            {
                attempt++;
                flag = 2;
               
            }
            
           
        }
        
        if( flag == 1)
        {
            
            clcd_print("Correct Password", LINE1(0));
            
            //return 2 for  MENU FUNCTION CALL
                      
            return 2; 
        }
        else if( flag == 2 & attempt == 3)
        {
            //user blocked
            //rest the board
            clcd_print("USER BLOCKED    ", LINE1(0));
            clcd_print("Wait For ", LINE2(0));
            
             TMR0IE = 1; // start the timer
            while(sec1 >= 0 && sec1 <60 )
            {
                clcd_putch(sec1/10+'0', LINE2(10));
                clcd_putch(sec1%10+'0', LINE2(11));
                clcd_print("sec", LINE2(13));
            }
            attempt = 0;
            sec1 = 59;
            TMR0IE = 0; // stop the timer
            
            clcd_print("                ", LINE2(0));
            return 0;
            
            
        }
        else if(flag == 2 )
        {
                        
            if(wrong_pass_delay++ < 20)
            {
             clcd_print("WRONG PASSWORD    ", LINE1(0));
            clcd_print("Attempts left:", LINE2(0));
            clcd_putch('3'-attempt,LINE2(14));
            }
            else 
            {
                flag = 0;
                pass_digit = 0;
                wrong_pass_delay = 0;
                clcd_print("                ", LINE2(0));
            
            }
            
            
        }
    }

    */
    
}
