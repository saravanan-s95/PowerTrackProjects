#include <xc.h>

void init_timer0(void)
{
    /* Setting the internal clock source */
    T0CS = 0;
    
    /* Assinging the prescaler to Watchdog Timer */ // 0 FOR PRESCALING
    PSA = 1;
    
    // SETING FOR THE PRESCALIN VALEUS FOR 1:16
    PS0 = 0;
    PS1 = 0;
    PS2 = 0;

    TMR0 = 6;
    
    /* The timer interrupt is enabled */
  
    TMR0IE = 1;
    
    /*tIMER FALG eNABLE*/
    TMR0IF = 1;
    
}
