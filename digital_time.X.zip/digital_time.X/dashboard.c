/*
 * File:   dashboard.c
 * Author: 25014
 *
 * Created on 31 December, 2025
 */
#include <xc.h>
#include "main.h"

unsigned char clock_reg[3], speed[3] = {0}, date_reg[3];
extern unsigned char sec1;
extern unsigned char delay1;

extern unsigned char daily[9];
extern unsigned char monthly[20];




unsigned char pos = 0;
unsigned int adc_val;
extern char time[9];
extern char date[9];
unsigned char event = 0;

unsigned char event_count = 0;
unsigned int address = 0x00;

void dashboard(unsigned char key) {

    //clcd_print(" TIME     EV  SP", LINE1(0));

    // display time

    // start the timer

    // while (sec1 >= 0 && sec1 < 60)

    {
        /*clcd_putch(sec1/10+'0', LINE2(10));
        clcd_putch(sec1%10+'0', LINE2(11));
        clcd_print("sec", LINE2(13));*/



        if (sec1 < 5) {
            get_time(clock_reg);
            //get_date(date_reg);
            clcd_print(daily, LINE2(0));
            display_time(clock_reg,1);


            // event display ( Gear pos and speed )
        } else if (sec1 < 10) {


            get_time(clock_reg);
            //get_date(date_reg);
            clcd_print(monthly, LINE2(0));
            display_time(clock_reg,1);

            // event display ( Gear pos and speed )
        } else {
            get_time(clock_reg);
            get_date(date_reg);
            display_time(clock_reg,1);
            display_date(date_reg,1);
        }


    }
    if (sec1 == 60)
        sec1 = 0;
    //TMR0IE = 0; // stop the timer

   // clcd_print("                ", LINE2(0));



    //display_event(key);

    //adc_val= read_adc(CHANNEL0) / 10.24;
    //clcd_putch((adc_val/10) + '0', LINE2(14));
    //clcd_putch(adc_val%10 + '0', LINE2(15));

}

void store_event(void) {

    

    if (event_count < 8)
        event_count++;

    for (int i = 0; i < 8; i++) {
        if (i == 2 || i == 5)
            continue;
        write_external_eeprom(address++, time[i]);
    }

    //event write to eeprom
    //write_external_eeprom(address++, event[pos][0]);
    //write_external_eeprom(address++, event[pos][1]);

    //
    write_external_eeprom(address++, (adc_val / 10) + '0');
    write_external_eeprom(address++, adc_val % 10 + '0');

    if (address > 88) {
        address = 0;
    }


}

void display_config_menu(unsigned char key) {

    char *config[ ] = {"SET/VIEW EVENT", "SET TIME /DATE"};
    char *set_event[] = {"SET TTME        ", "SET DATE        "};
    char *alarm_ops[] = {"VIEW EVENT      ", "EDIT THE EVENT "};
    unsigned char key1;// = read_digital_keypad(STATE);
    unsigned char switch_key;
    unsigned char i = 0, j = 0;
    unsigned char blink_pos = 0, blink_delay1 = 0, blink_delay2 = 0;

    
    if (key == SW2) {
        pos++;
        delay1 = 0;

    } else if (key == SW1) {

        pos--;
        delay1 = 0;

        if (pos < 0) {
            pos = 1;
        }

    }
    pos = pos % 2;

    if (event == 0) {

        if (pos == 0) {
            clcd_print("* ", LINE1(0));
            clcd_print("  ", LINE2(0));

        } else {
            clcd_print("* ", LINE2(0));
            clcd_print("  ", LINE1(0));

        }
        clcd_print(config[0], LINE1(2));
        clcd_print(config[1], LINE2(2));

    }

    if (key == SW5 && pos == 1)
    {
        event = 1;

    }
    else if( key == SW5 && pos == 0)
    {
        event = 2;
    }

    if (event == 1)  // timer function
    {


        while (1) 
        {
            key1 = read_digital_keypad(STATE);
            
            
            if (key1 == SW2)
            {
                pos++;
                

            } 
            else if (key1 == SW1)
            {

                pos--;
                

                if (pos < 0) 
                {
                    pos = 1;
                }

            }
            else if (key1 == SW3)
            {
                event = 0;
                break;
            }
                
         
            pos = pos % 2;

            clcd_print(set_event[0], LINE1(0));

            clcd_print(set_event[1], LINE2(0));
           
            if (pos == 0) 
            {
                
                clcd_print("* ", LINE1(0));
                clcd_print("  ", LINE2(0));
                
                if(key1 == SW4) // SW4 to enter the edit menu of time
                {
                    //get_time(clock_reg);
                    update_time();
                }
                }
                

             else {
                clcd_print("* ", LINE2(0));                                      // Need to work on this 
                clcd_print("  ", LINE1(0));
                
                if(key1 == SW4) // SW4 to enter the edit mode of date
                {
                    //get_time(clock_reg);
                    update_date();
                }
                }
                    //clcd_print(" DD : MM : YY  ", LINE1(0));
                    //display_date(date_reg);
                }

            }
    
    else if( event == 2 ) // to edit the events
    {
        while (1) 
        {
            key1 = read_digital_keypad(STATE);
            
            
            if (key1 == SW2)
            {
                pos++;
                

            } 
            else if (key1 == SW1)
            {

                pos--;
                

                if (pos < 0) 
                {
                    pos = 1;
                }

            }
            else if (key1 == SW3)
            {
                event = 0;
                break;
            }
                
         
            pos = pos % 2;

            clcd_print(alarm_ops[0], LINE1(2));

            clcd_print(alarm_ops[1], LINE2(2));
           
            if (pos == 0) 
            {
                
                clcd_print("* ", LINE1(0));
                clcd_print("  ", LINE2(0));
                
                if(key1 == SW4) // SW4 to enter the view menu of time
                {
                    //get_time(clock_reg);
                    view_the_event();
                    event = 0;
                }
                }
                

             else {
                clcd_print("* ", LINE2(0));                                      // Need to work on this 
                clcd_print("  ", LINE1(0));
                
                if(key1 == SW4) // SW4 to enter the edit mode of the alarm
                {
                    //get_time(clock_reg);
                    clcd_print("  EDIT THE EVENTS   ", LINE2(0));
                    edit_the_event();
                }
                }
                    //clcd_print(" DD : MM : YY  ", LINE1(0));
                    //display_date(date_reg);
                }

        
    }
            
}
    

void view_the_event(void)
{
    unsigned char delay1 = 0, delay2  = 0;
    
    while(1)
    {
        if(delay1++ < 10)
        {
            if (delay2++ < 5)
            {
                clcd_print("    EVENTS         ", LINE1(0));
                clcd_print(daily, LINE2(0));
            }
            else
            {
                delay2  = 0 ;
            }
        }
        else if(delay1++ < 20)
        {
            if (delay2++ < 5)
            {
                clcd_print("     EVENTS           ", LINE1(0));
                clcd_print(monthly, LINE2(0));
            }
            else
            {
                delay2  = 0 ;
            }
        }
        else
        {
            break;
        }
    }
}


void edit_the_event(void)
{
    unsigned char  pos  = 0, event  = 0;
    unsigned char key;
     char* event_det[] = {"EDIT THE DAILY    ","EDIT THE MONTHLY"}; 
    
    while(1)
    {
        key  = read_digital_keypad(STATE);
        if (key == SW2) {
        pos++;
       

    } else if (key == SW1) {

        pos--;
        

        if (pos < 0) {
            pos = 1;
        }

    }
    else if(key == SW3)
    {
        return;
    }
    pos = pos % 2;

    if (pos == 0) 
            {
                
                clcd_print("* ", LINE1(0));
                clcd_print("  ", LINE2(0));
                
                if(key == SW4) // SW4 to enter the view menu of time
                {
                    //get_time(clock_reg);
                    clcd_print("EDIT THE DAILY  ", LINE1(0));
                    edit_daily_event();
                    
                }
                }
                

             else {
                clcd_print("* ", LINE2(0));                                      // Need to work on this 
                clcd_print("  ", LINE1(0));
                
                if(key == SW4) // SW4 to enter the edit mode of the alarm
                {
                    //get_time(clock_reg);
                    clcd_print("EDIT THE MONTHLY", LINE2(0));
                     edit_monthly_event();
                    
                }
                
    }
    clcd_print(event_det[0], LINE1(2));
    clcd_print(event_det[1],LINE2(2));
}

}


void edit_daily_event(void)
{
    
    unsigned char switch_key, blink_pos = 0, blink_delay1 = 0, blink_delay2 = 0;
   
    while (1)
    {
        switch_key = read_digital_keypad(STATE);
        if (switch_key == SW2) // changing the edit filed
        {
            blink_pos += 3;
        } else if (switch_key == SW3) // return withouSt saving the data
        {
            return;
        }
        else if(switch_key == SW1) // SW1 to change the time 
        {
           
            
            if (blink_pos == 0) // edit the HH
            {
                                
                    if(daily[1] < '9')
                    {
                        daily[1]++;
                    }
                    else
                    {
                        daily[1] = '0';
                        
                        if( daily[0] > '1')
                        {
                            daily[0] = '0';
                        }
                        else
                        {
                            daily[0]++;
                        }
                    }
                    if(daily[0] == '2' & daily[1] == '4')
                    {
                        daily[1] = daily[0] = '0';
                    }
                    
                    
                
            }
            else if (blink_pos == 3) // edit MM
            {
                if(daily[4] < '9')
                    {
                        daily[4]++;
                    }
                    else
                    {
                        daily[4] = '0';
                        
                        if( daily[3] > '4')
                        {
                            daily[3] = '0';
                        }
                        else
                        {
                            daily[3]++;
                        }
                    }
                    
            }
            else if(blink_pos == 6) // edit the SS
            {
                if(daily[7] < '9')
                    {
                        daily[7]++;
                    }
                    else
                    {
                        daily[7] = '0';
                        
                        if( daily[6] > '4')
                        {
                            daily[6] = '0';
                        }
                        else
                        {
                            daily[6]++;
                        }
                    }
            }
            
        }
        
        

        if (blink_pos == 9)
        {
            blink_pos = 0;
        }
        
        
        
        if (blink_delay1++ < 5) 
        {
            if (blink_delay2++ < 5) 
            {
                clcd_print("__", LINE2(blink_pos));
            } 
            else 
            {
                blink_delay2 = 0;
            }
        } 
        else if (blink_delay1++ < 10)
        {
            if (blink_delay2++ < 5)
            {
                
                clcd_print(daily, LINE2(0));
                
            } else 
            {
                blink_delay2 = 0;
            }
        } 
        else 
        {
            blink_delay1 = 0;
        }

        
    }   
}

void edit_monthly_event(void)
{
    unsigned char switch_key, blink_pos = 0, blink_delay1 = 0, blink_delay2 = 0;
   
    while (1)
    {
        switch_key = read_digital_keypad(STATE);
        
        if (switch_key == SW2) // changing the edit filed
        {
            blink_pos += 3;
        } else if (switch_key == SW3) // return withouSt saving the data
        {
            return;
        }
        else if(switch_key == SW1) // SW1 to change the time 
        {
           
            
            if (blink_pos == 0) // edit the HH
            {
                                
                    if(monthly[1] < '9')
                    {
                        monthly[1]++;
                    }
                    else
                    {
                        monthly[1] = '0';
                        
                        if( monthly[0] > '1')
                        {
                            monthly[0] = '0';
                        }
                        else
                        {
                            monthly[0]++;
                        }
                    }
                    if(monthly[0] == '2' & monthly[1] == '4')
                    {
                        monthly[1] = monthly[0] = '0';
                    }
                    
                    
                
            }
            else if (blink_pos == 3) // edit MM
            {
                if(monthly[4] < '9')
                    {
                        monthly[4]++;
                    }
                    else
                    {
                        monthly[4] = '0';
                        
                        if( monthly[3] > '4')
                        {
                            monthly[3] = '0';
                        }
                        else
                        {
                            monthly[3]++;
                        }
                    }
                    
            }
            else if(blink_pos == 6) // edit the SS
            {
                if(monthly[7] < '9')
                    {
                        monthly[7]++;
                    }
                    else
                    {
                        monthly[7] = '0';
                        
                        if( monthly[6] > '4')
                        {
                            monthly[6] = '0';
                        }
                        else
                        {
                            monthly[6]++;
                        }
                    }
            }
            else if(blink_pos == 9)
            {
                blink_pos = 11;
            }
            
        }
        
        

        if (blink_pos == 9)
        {
            blink_pos = 0;
        }
        
        
        
        if (blink_delay1++ < 5) 
        {
            if (blink_delay2++ < 5) 
            {
                clcd_print("__", LINE2(blink_pos));
            } 
            else 
            {
                blink_delay2 = 0;
            }
        } 
        else if (blink_delay1++ < 10)
        {
            if (blink_delay2++ < 5)
            {
                
                clcd_print(daily, LINE2(0));
                
            } else 
            {
                blink_delay2 = 0;
            }
        } 
        else 
        {
            blink_delay1 = 0;
        }

        if (blink_pos == 9)
        {
            blink_pos = 0;
        }
        
    }   
}