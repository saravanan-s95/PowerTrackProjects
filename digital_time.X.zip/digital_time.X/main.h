/* 
 * File:   main.h
 * Author: 25014
 *
 * Created on 26 November, 2025, 5:53 PM
 */

#ifndef MAIN_H
#define	MAIN_H
#include "adc.h"
#include "digital_keypad.h"
#include "clcd.h"
#include "i2c.h"
#include "ds1307.h"
#include "timer.h"
#include "external_eeprom.h"
#include "uart.h"


unsigned char set_pass[4] = {'0','0','0','0'};

void dashboard(unsigned char key);
void display_config_menu(unsigned char key);
unsigned char login_screen(void);
unsigned char menu_screen(void); 
void view_log(void);
void  clear_log(void);
void download_log(void);
char set_time(void);
void pass_change(void);
int my_strcmp1( unsigned char *,unsigned char *);
void view_the_event(void);
void edit_the_event(void);
void edit_daily_event(void);
void edit_monthly_event(void);

#endif	/* MAIN_H */

