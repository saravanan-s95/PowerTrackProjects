#include <xc.h>
#include "main.h"

char time[9];
char date[11];

void init_ds1307(void) {
    unsigned char dummy;

    dummy = read_ds1307(SEC_ADDR);
    dummy = dummy & 0x7F;
    write_ds1307(SEC_ADDR, dummy); // CH = 0
}

unsigned char read_ds1307(unsigned char addr) {
    unsigned char data;

    i2c_start();
    i2c_write(SLAVE_WRITE);
    i2c_write(addr);
    i2c_rep_start();
    i2c_write(SLAVE_READ);
    data = i2c_read(0);
    i2c_stop();

    return data;
}

void write_ds1307(unsigned char addr, unsigned char data) // SEc_ADDR, data
{
    i2c_start();
    i2c_write(SLAVE_WRITE);
    i2c_write(addr);
    i2c_write(data);
    i2c_stop();
}

void get_time(unsigned char *clock_reg) {
    clock_reg[0] = read_ds1307(HOUR_ADDR); // HH -> BCD 
    clock_reg[1] = read_ds1307(MIN_ADDR); // MM -> BCD 
    clock_reg[2] = read_ds1307(SEC_ADDR); // SS -> BCD 
}

void get_date(unsigned char *date_reg) {
    date_reg[0] = read_ds1307(DATE_ADDR); // HH -> BCD 
    date_reg[1] = read_ds1307(MONTH_ADDR); // MM -> BCD 
    date_reg[2] = read_ds1307(YEAR_ADDR); // SS -> BCD 
}

void display_time(unsigned char *clock_reg, unsigned char row) {
    //BCD Format 
    //clock_reg[0] = HH
    //clock_reg[1] = MM
    //clock_reg[2] = SS

    /* To store the time in HH:MM:SS format */
    //char time[9];  // "HH:MM:SS"
    // HH -> 
    if (row == 1) {
        clcd_print("TIME  ", LINE1(0));
        time[0] = ((clock_reg[0] >> 4) & 0x03) + '0';
        time[1] = (clock_reg[0] & 0x0F) + '0';

        time[2] = ':';
        // MM 
        time[3] = ((clock_reg[1] >> 4) & 0x07) + '0';
        time[4] = (clock_reg[1] & 0x0F) + '0';

        time[5] = ':';
        // SS
        time[6] = ((clock_reg[2] >> 4) & 0x07) + '0';
        time[7] = (clock_reg[2] & 0x0F) + '0';
        time[8] = '\0';


        clcd_print(time, LINE1(6));
    } else {
        // clcd_print("TIME ", LINE1(0));
        time[0] = ((clock_reg[0] >> 4) & 0x03) + '0';
        time[1] = (clock_reg[0] & 0x0F) + '0';

        time[2] = ':';
        // MM 
        time[3] = ((clock_reg[1] >> 4) & 0x07) + '0';
        time[4] = (clock_reg[1] & 0x0F) + '0';

        time[5] = ':';
        // SS
        time[6] = ((clock_reg[2] >> 4) & 0x07) + '0';
        time[7] = (clock_reg[2] & 0x0F) + '0';
        time[8] = '\0';

        clcd_print("  ", LINE2(0));
        clcd_print(time, LINE2(0)); // HH:MM:SS
    }

}

void display_date(unsigned char *date_reg, unsigned char mode)
 {
    //if (mode == 1) 
     {
        clcd_print("DATE ", LINE2(0));
        //day
        date[0] = ((date_reg[0] >> 4) & 0x03) + '0';
        date[1] = (date_reg[0] & 0x0F) + '0';

        date[2] = '-';
        // month 
        date[3] = ((date_reg[1] >> 4) & 0x07) + '0';
        date[4] = (date_reg[1] & 0x0F) + '0';

        date[5] = '-';
        // year
        /* date[6] = '2';
         date[7] = '0';*/
        date[6] = ((date_reg[2] >> 4) & 0x07) + '0';
        date[7] = (date_reg[2] & 0x0F) + '0';
        date[8] = '\0';


        clcd_print(date, LINE2(5)); // HH:MM:SS 
    } 
     /* else if (mode == 2)// For printing in the DD:MM:YY format
    {
        date[0] = ((date_reg[0] >> 4) & 0x03) + '0';
        date[1] = (date_reg[0] & 0x0F) + '0';

        date[2] = '-';
        // month 
        date[3] = ((date_reg[1] >> 4) & 0x07) + '0';
        date[4] = (date_reg[1] & 0x0F) + '0';

        date[5] = '-';
        // year
        //date[6] = '2';
       // date[7] = '0';
        date[6] = ((date_reg[2] >> 4) & 0x07) + '0';
        date[7] = (date_reg[2] & 0x0F) + '0';
        date[8] = '\0';


        clcd_print(date, LINE2(0));

    }*/

}

void update_time(void) 
{
    unsigned char switch_key, blink_pos = 0, blink_delay1 = 0, blink_delay2 = 0;
    unsigned char num, hh, mm, ss;
    while (1)
    {
        switch_key = read_digital_keypad(STATE);
        if (switch_key == SW2) // changing the edit filed
        {
            blink_pos += 3;
        } else if (switch_key == SW3) // return withouSt saving the data
        {
            return;
        }
        else if(switch_key == SW1) // SW1 to change the time 
        {
           
            
            if (blink_pos == 0) // edit the HH
            {
                                
                    if(time[1] < '9')
                    {
                        time[1]++;
                    }
                    else
                    {
                        time[1] = '0';
                        
                        if( time[0] > '1')
                        {
                            time[0] = '0';
                        }
                        else
                        {
                            time[0]++;
                        }
                    }
                    if(time[0] == '2' & time[1] == '4')
                    {
                        time[1] = time[0] = '0';
                    }
                    
                    
                
            }
            else if (blink_pos == 3) // edit MM
            {
                if(time[4] < '9')
                    {
                        time[4]++;
                    }
                    else
                    {
                        time[4] = '0';
                        
                        if( time[3] > '4')
                        {
                            time[3] = '0';
                        }
                        else
                        {
                            time[3]++;
                        }
                    }
                    
            }
            else if(blink_pos == 6) // edit the SS
            {
                if(time[7] < '9')
                    {
                        time[7]++;
                    }
                    else
                    {
                        time[7] = '0';
                        
                        if( time[6] > '4')
                        {
                            time[6] = '0';
                        }
                        else
                        {
                            time[6]++;
                        }
                    }
            }
            
        }
        else if( switch_key == SW4 ) // to save the changes
        {
            hh = ((time[0] - '0') << 4) | (time[1] - '0');
            
            mm = ((time[3] - '0') << 4) | (time[4] - '0');
            
            ss = ((time[6] - '0') << 4) | (time[7] - '0');
            
            write_ds1307(HOUR_ADDR, hh);
            write_ds1307(MIN_ADDR, mm);
            write_ds1307(SEC_ADDR, ss);
            return;
            
        }
        

        if (blink_pos == 9)
        {
            blink_pos = 0;
        }
        
        clcd_print("HH:MM:SS       ", LINE1(0));
        
        if (blink_delay1++ < 5) 
        {
            if (blink_delay2++ < 5) 
            {
                clcd_print("__", LINE2(blink_pos));
            } 
            else 
            {
                blink_delay2 = 0;
            }
        } 
        else if (blink_delay1++ < 10)
        {
            if (blink_delay2++ < 5)
            {
                //display_time(clock_reg,2);
                clcd_print(time, LINE2(0));
                //clcd_print("__", LINE2(blink_pos));
            } else 
            {
                blink_delay2 = 0;
            }
        } 
        else 
        {
            blink_delay1 = 0;
        }

        //display_time(clock_reg,2);

        //update_time();
    }

}

void update_date(void) {
    unsigned char switch_key, blink_pos = 0, blink_delay1 = 0, blink_delay2 = 0,dd,mm,yy;

    while (1)
    {
        switch_key = read_digital_keypad(STATE);
        if (switch_key == SW2) // changing the edit filed
        {
            blink_pos += 3;
        } 
        else if (switch_key == SW3) // return without saving the data
        {
            return;
        }
        else if(switch_key == SW1) // SW1 to change the date need to work on this
        {
           
            
            if (blink_pos == 0) // edit the HH
            {
                                
                    if(date[1] < '9')
                    {
                        date[1]++;
                    }
                    else
                    {
                        date[1] = '0';
                        
                        if( date[0] > '3')
                        {
                            date[0] = '0';
                        }
                        else
                        {
                            date[0]++;
                        }
                    }
                    if(date[0] == '3' & date[1] == '1')
                    {
                        date[1] = date[0] = '0';
                    }
                    
                    
                
            }
            else if (blink_pos == 3) // edit MM
            {
                if(date[4] < '9')
                    {
                        date[4]++;
                    }
                    else
                    {
                        date[4] = '0';
                        
                        if( date[3] > '1')
                        {
                            date[3] = '0';
                        }
                        else
                        {
                            date[3]++;
                        }
                    }
                if(date[3] == '1' & date[4] == '3')
                    {
                        date[3] = date[4] = '0';
                    }
                    
            }
            else if(blink_pos == 6) // edit the SS
            {
                if(date[7] < '9')
                    {
                        date[7]++;
                    }
                    else
                    {
                        date[7] = '0';
                        
                        if( date[6] > '9')
                        {
                            date[6] = '0';
                        }
                        else
                        {
                            date[6]++;
                        }
                    }
            }
            
        }
        else if( switch_key == SW4 ) // to save the changes
        {
            dd = ((date[0] - '0') << 4) | (date[1] - '0');
            
            mm = ((date[3] - '0') << 4) | (date[4] - '0');
            
            yy = ((date[6] - '0') << 4) | (date[7] - '0');
            
            
            
            write_ds1307(DATE_ADDR, dd);
            write_ds1307(MONTH_ADDR, mm);
            write_ds1307(YEAR_ADDR, yy);
            return;
            
        }

        if (blink_pos == 9)
        {
            blink_pos = 0;
        }
        clcd_print("DD:MM:YY       ", LINE1(0));
        
        /*if (blink_delay1++ < 5)
        {
            if (blink_delay2++ < 5) 
            {
                 
                //clcd_print(date, LINE2(0));
                clcd_print("__", LINE2(0));
            }
            else 
            {
                blink_delay2 = 0;
            }
        } 
        else if (blink_delay1++ < 10) 
        {
            if (blink_delay2++ < 5) 
            {
               
                
               // clcd_print("date-of-the-format", LINE2(0));
                clcd_print(date,LINE2(0));
            }
                else 
            {
                blink_delay2 = 0;
            }
        } 
        else 
        {
            blink_delay1 = 0;
        }*/

        if (blink_delay1++ < 5) 
        {
            if (blink_delay2++ < 5) 
            {
                clcd_print("__", LINE2(blink_pos));
            } 
            else 
            {
                blink_delay2 = 0;
            }
        } 
        else if (blink_delay1++ < 10)
        {
            if (blink_delay2++ < 5)
            {
                //display_time(clock_reg,2);
                clcd_print(date, LINE2(0));
                //clcd_print("__", LINE2(blink_pos));
            } else 
            {
                blink_delay2 = 0;
            }
        } 
        else 
        {
            blink_delay1 = 0;
        }
        
    }
}