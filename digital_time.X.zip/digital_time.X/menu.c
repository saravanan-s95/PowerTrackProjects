/*
 * File:   menu.c
 * Author: HP
 *
 * Created on 19 January, 2026, 11:35 PM
 */


#include "main.h"

extern unsigned char event_count;
extern unsigned int address;
static unsigned char log_event [9][10];
extern unsigned char time[9], clock_reg[3], date[10];

unsigned char menu_screen(void) {
    char *menu[] = {
        {" View Log       "},
        {" Clear Log      "},
        {" Download Log    "},
        {" Set Time       "},
        {" Change Pass   "}
    };
    unsigned char key;
    unsigned char i = 0;
    unsigned char scroll = 0;

    while (1) {
        key = read_digital_keypad(STATE);

        if (key == SW2) {
            if (i < 4) {
                i++;
                scroll = 0;

            }
        } else if (key == SW1) {
            if (i > 0) {
                i--;
                scroll = 1;
            }
        }

        if (i == 0) {
            clcd_putch('*', LINE1(0));
            clcd_putch(' ', LINE2(0));
        } else if (i == 3 && scroll == 1) {
            clcd_putch('*', LINE1(0));
            clcd_putch(' ', LINE2(0));

        } else if (scroll == 0) {
            clcd_putch(' ', LINE1(0));
            clcd_putch('*', LINE2(0));
        } else if (scroll == 1) {
            clcd_putch('*', LINE1(0));
            clcd_putch(' ', LINE2(0));
        }

        if (i < 2 && scroll == 0) {
            clcd_print(menu[0], LINE1(1));
            clcd_print(menu[1], LINE2(1));
        } else if (i < 4 && scroll == 0) {
            clcd_print(menu[i - 1], LINE1(1));
            clcd_print(menu[i], LINE2(1));

        } else if (i < 4 && scroll == 1) {
            clcd_print(menu[i], LINE1(1));
            clcd_print(menu[i + 1], LINE2(1));

        } else {
            clcd_print(menu[3], LINE1(1));
            clcd_print(menu[4], LINE2(1));
        }

        if (key == SW4) {
            if (i == 0) {

                view_log();
            } else if (i == 1) {

                clear_log();
            } else if (i == 2) {

                download_log();
            } else if (i == 3) {
                if (set_time() == 0) {
                    clcd_print("                ", LINE1(0));
                    clcd_print("                ", LINE2(0));
                    return 0;
                }

            } else if (i == 4) {
               clcd_print("                ", LINE1(0));
                clcd_print("                ", LINE2(0));
               pass_change();
                   
            }

        } else if (key == SW5) {
            clcd_print("                ", LINE1(0));
            clcd_print("                ", LINE2(0));
            return 0;
        }

    }
}

void view_log(void) {

    char log_read;
    unsigned char i = 0;
    char key;
    //static unsigned char address = 0x00;

    unsigned char addr = 0x00;

    if (event_count == 0) {
        clcd_print("No Event logs   ", LINE1(0));
        clcd_print("                ", LINE2(0));
        for (unsigned int i = 0; i < 20; i++)
            for (unsigned char j = 0; j < 255; j++)
                for (unsigned char k = 0; k < 255; k++);
    } else {


        for (unsigned char i = 0; i < event_count; i++) {
            for (unsigned char j = 0; j < 10; j++) {

                
                {
                    log_event[i][j] = read_external_eeprom(addr++);
                   
                }
            }

        }


        clcd_print("# TIME     EV SP", LINE1(0));

        while (1) {
            key = read_digital_keypad(STATE);

            if (key == SW1) {
                if (i < event_count)
                    i++;
            } else if (key == SW2) {
                if (i > 0)
                    i--;
            } else if (key == SW5) {
                return;
            }



            unsigned char pos = 0;
            for (unsigned char j = 0; j < 16; j++) {
                if (j == 0)
                    clcd_putch(i + '1', LINE2(j));
                else if (j == 1 || j == 10 || j == 13)
                    clcd_putch(' ', LINE2(j));
                else if (j == 4 || j == 7)
                    clcd_putch(':', LINE2(j));
                else
                    clcd_putch(log_event[i][pos++], LINE2(j));


            }
        }
    }
}

void clear_log(void) {
    event_count = 0;
    address = 0x00;
    clcd_print("Log Cleared     ", LINE1(0));
    clcd_print("                ", LINE2(0));
    for (unsigned int i = 0; i < 20; i++)
        for (unsigned char j = 0; j < 255; j++)
            for (unsigned char k = 0; k < 255; k++);
}

void download_log(void) {
    unsigned char addr = 0x00;

    clcd_print("Log Downloaded  ", LINE1(0));
    clcd_print("                ", LINE2(0));
    for (unsigned int i = 0; i < 20; i++)
        for (unsigned char j = 0; j < 255; j++)
            for (unsigned char k = 0; k < 255; k++);

    for (unsigned char i = 0; i < event_count; i++) {
        for (unsigned char j = 0; j < 10; j++) {

            log_event[i][j] = read_external_eeprom(addr++);
        }

    }

    puts("# TIME     EV SP\n\r");

    for (unsigned char i = 0; i < event_count; i++) {
        unsigned char pos = 0;
        for (unsigned char j = 0; j < 16; j++) {
            if (j == 0)
                putchar(i + '1');
            else if (j == 1 || j == 10 || j == 13)
                putchar(' ');
            else if (j == 4 || j == 7)
                putchar(':');
            else
                putchar(log_event[i][pos++]);


        }
        puts("\n\r");
    }
}

char set_time(void) {
    clcd_print("    HH:MM:SS    ", LINE1(0));
    clcd_print("                ", LINE2(0));


    int hr = ((clock_reg[0] & 0xF0) >> 4) * 10 + (clock_reg[0] & 0x0F);

    int min = ((clock_reg[1] & 0xF0) >> 4) * 10 + (clock_reg[1] & 0x0F);

    int sec = ((clock_reg[1] & 0xF0) >> 4) * 10 + (clock_reg[1] & 0x0F);

    char key;
    char select = 0;
    unsigned char blink_delay = 0;



    while (1) {

        key = read_digital_keypad(STATE);

        if (key == SW1) {
            if (select == 0) {
                hr++;
                if (hr == 24)
                    hr = 0;
            } else if (select == 1) {
                min++;
                if (min == 60)
                    min = 00;
            } else if (select == 2) {
                sec++;
                if (sec == 60)
                    sec = 0;

            }
        } else if (key == SW2) {
            select = (++select) % 3;
        } else if (key == SW4) {
            // save time and return to dashboard
            write_ds1307(HOUR_ADDR, ((hr / 10) << 4) | (hr % 10));
            write_ds1307(MIN_ADDR, ((min / 10) << 4) | (min % 10));
            write_ds1307(SEC_ADDR, ((sec / 10) << 4) | (sec % 10));
            return 0;
        } else if (key == SW5) {
            //return to sash board without saving the change in time
            return 0;
        }


        // display the time

        if (blink_delay++ < 25) {
            //display _
            if (select == 0) {
                clcd_putch((hr / 10) + '0', LINE2(4));
                clcd_putch((hr % 10) + '0', LINE2(5));
            } else if (select == 1) {
                clcd_putch((min / 10) + '0', LINE2(7));
                clcd_putch((min % 10) + '0', LINE2(8));
            } else if (select == 2) {
                clcd_putch((sec / 10) + '0', LINE2(10));
                clcd_putch((sec % 10) + '0', LINE2(11));
            }

        } else if (blink_delay < 30) {
            // display space
            if (select == 0) {
                clcd_print("  ", LINE2(4));
                clcd_putch(':', LINE2(6));
                clcd_putch((min / 10) + '0', LINE2(7));
                clcd_putch((min % 10) + '0', LINE2(8));
                clcd_putch(':', LINE2(9));
                clcd_putch((sec / 10) + '0', LINE2(10));
                clcd_putch((sec % 10) + '0', LINE2(11));

            } else if (select == 1) {
                clcd_putch((hr / 10) + '0', LINE2(4));
                clcd_putch((hr % 10) + '0', LINE2(5));
                clcd_putch(':', LINE2(6));
                clcd_print("  ", LINE2(7));
                clcd_putch(':', LINE2(9));
                clcd_putch((sec / 10) + '0', LINE2(10));
                clcd_putch((sec % 10) + '0', LINE2(11));


            } else if (select == 2) {
                clcd_putch((hr / 10) + '0', LINE2(4));
                clcd_putch((hr % 10) + '0', LINE2(5));
                clcd_putch(':', LINE2(6));
                clcd_putch((min / 10) + '0', LINE2(7));
                clcd_putch((min % 10) + '0', LINE2(8));
                clcd_putch(':', LINE2(9));
                clcd_print("  ", LINE2(10));

            }

        } else
            blink_delay = 0;




    }

}

int my_strcmp1(unsigned char new_pass[], unsigned char re_pass[])

{
    for(char i =0 ;i < 4; i++)
    {
        if(new_pass[i] != re_pass[i])
        {
            return 1;
        }
    }
    return 0;
}

void my_strcpy(unsigned char new_pass[])
{
    for(int i = 0; i < 4; i++)
    {
        set_pass[i] = new_pass[i];
    }
}

void pass_change(void) {
    char pass_digit = 0;
    char key;
    unsigned char new_pass[5];
    unsigned char re_pass[5];
    unsigned char blink_delay = 0;

    while (1) {
        key = read_digital_keypad(STATE);
        
        if(key == SW5)
                return ;
        
        if (pass_digit < 4) {
            clcd_print("Enter New Pass  ", LINE1(0));
            
            if (key == SW1) 
            {
                new_pass[pass_digit] = '0';
                clcd_putch('*', LINE2(pass_digit ));
                pass_digit++;

            } else if (key == SW2) {
                new_pass[pass_digit] = '1';
                clcd_putch('*', LINE2(pass_digit ));

                pass_digit++;

            }

        } else if (pass_digit < 8) {
            clcd_print("Re-Enter   Pass  ", LINE1(0));
            
            if (key == SW1) {
            re_pass[pass_digit % 4] = '0';
            clcd_putch('*', LINE2(pass_digit % 4));
            pass_digit++;

        } else if (key == SW2) {
            re_pass[pass_digit % 4] = '1';
            clcd_putch('*', LINE2(pass_digit % 4));

            pass_digit++;

        }
            
            
        } 
        else {
            break;
        }

        if (blink_delay++ < 5) {
            //display _
            clcd_putch('_', LINE2(pass_digit % 4));


        } else if (blink_delay < 10) {
            // display space
            clcd_putch(' ', LINE2(pass_digit % 4));
        } else
            blink_delay = 0;


    }
    new_pass[4]='\0';
    re_pass[4] = '\0';        
    
        
        
    if(my_strcmp1(new_pass,re_pass) == 0)
    {
        clcd_print("Password Changed", LINE1(0));
        clcd_print("                ", LINE2(0));
       
        my_strcpy(new_pass);
    }
    else
    {
        clcd_print("Wrong Password  ", LINE1(0));
        clcd_print("                ", LINE2(0));
    }
    
    for (unsigned int i = 0; i < 20; i++)
            for (unsigned char j = 0; j < 255; j++)
                for (unsigned char k = 0; k < 255; k++);
         
    
    return ;

}
