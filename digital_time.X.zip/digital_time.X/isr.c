#include <xc.h>
#include "main.h"

extern unsigned char sec1;
//extern unsigned char sec2;

void __interrupt() isr(void)
{
    static unsigned int count = 0;
    
    if (TMR0IF == 1)
    {
        /* TMR0 Register valur + 6 (offset count to get 250 ticks) + 2 Inst Cycle */
        TMR0 = TMR0 + 8;
        
        if (++count == 20000)
        {
            sec1++;
            
            count = 0;
        }
        
        TMR0IF = 0;
    }
    
    
    //UART program
    
    char ch;
    if (RCIF == 1)
    {
        if (OERR == 1)
            OERR = 0;
        
        ch = RCREG;
        
        RCIF = 0;
    }
}