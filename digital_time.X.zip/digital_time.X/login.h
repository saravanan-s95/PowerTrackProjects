/*
 * File:   login.c
 * Author: HP
 *
 * Created on 14 January, 2026, 9:27 PM
 */


#include <xc.h>
#include "main.h"

unsigned char attempt = 0;

unsigned char login_screen(void)
{
    
}
