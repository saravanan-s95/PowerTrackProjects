/*
 * File:   main.c
 * Author: 25014
 *
 * Created on 31 December, 2025
 */



#include <xc.h>
#include "main.h"

unsigned char sec1 = 0;
unsigned char delay1 = 0;

unsigned char daily[10] = {"12:00:00 D      "};
unsigned char monthly[22] = {"12:00:00 W        "};

#pragma config WDTE = OFF

void init_config()
{
    init_adc();
    init_clcd();
    init_digital_keypad();
    init_i2c(100000); 
    init_ds1307();
    init_timer0();
    init_i2c(9600);
    init_uart(9600);
   
    TMR0IE = 1; // start the timer
    GIE = 1;
    PEIE = 1;
}   

void main(void) 
{
    init_config();
    
           
    
    unsigned char key, operation = 0, screen = 0;
    unsigned delay = 0;
    
    while(1)
    {
        key = read_digital_keypad(STATE);
        
        if(key == SW4)
        {
            operation = 1;
            
        }
       
        if(operation == 0)
        {
            dashboard(key);
        }
        else if(operation == 1)
        {
            
            display_config_menu(key);
            
            if(delay1++ > 50)
            {
                if(delay++ > 10)
                {
                    operation = 0;
                    delay1 = 0;
                    delay = 0;
                }
            }
        }

           
    }
}
