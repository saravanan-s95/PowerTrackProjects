/*
 * File:   isr.c
 * Author: Dasmini
 *
 * Created on 30 October, 2026, 5:37 PM
 */


#include <xc.h>

extern volatile unsigned int idle_flag, timer_count, blink_phase, blink_timer;
__interrupt() void isr()
{
    
    if(TMR1IF)
    {
        if(timer_count >= 400)
        {
            idle_flag = 1;
            timer_count = 0;
        }
        
        else
            timer_count++;
        
        if(blink_timer >= 40)
        {
            blink_phase = !blink_phase;
            blink_timer = 0;
        }
        else
        {
            blink_timer++;
        }
            
        TMR1 = 3026 + TMR1 + 2;
        TMR1IF = 0;
        //write remaining code
    }
}
