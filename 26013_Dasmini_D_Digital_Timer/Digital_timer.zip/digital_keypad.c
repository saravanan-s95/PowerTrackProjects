/*
 * File:   digital_keypad.c
 * Author: Dasmini
 *
 * Created on 2 November, 2026, 9:50 PM
 */


#include <xc.h>
#include "digital_keypad.h"
void init_digital_keypad(void) {
    TRISB = TRISB | 0x3f;
}

unsigned char read_digital_keypad(unsigned char mode) {
    static unsigned char once = 1;
    
    if (mode == LEVEL_DETECTION)
    {
        return KEYPAD_PORT & INPUT_LINES; //PORTB & 0X3F
    }
    else if (mode == STATE_DETECTION)
    {
        if (((KEYPAD_PORT & INPUT_LINES) != ALL_RELEASED) && once) //portb & 0x3f
       {
        once = 0;
        return KEYPAD_PORT & INPUT_LINES;
        }
    }
    if((KEYPAD_PORT & INPUT_LINES) == ALL_RELEASED)
    {
        once = 1;
    }
 
    return ALL_RELEASED;
}