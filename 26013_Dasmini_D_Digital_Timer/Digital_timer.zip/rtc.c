/*
 * File:   rtc.c
 * Author: Dasmini
 *
 * Created on 1 November, 2026, 7:10 PM
 */


#include <xc.h>
#pragma confid WDTE = OFF

static void init_config(void) {

}

void main(void) {
    init_config();
    while (1) {

    }
    return;
}
