/* 
 * File:   timer.h
 * Author: Dasmini
 *
 * Created on 30 October, 2026, 5:33 PM
 */

#ifndef TIMER_H
#define	TIMER_H

void init_timer1();

#endif	/* TIMER_H */

