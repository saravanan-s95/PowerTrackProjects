/*
 * File:   i2c.c
 * Author: Dasmini
 *
 * Created on 31 October, 2026, 8:27 PM
 */


#include <xc.h>
#include "i2c.h"

extern volatile unsigned int sec, min, hour, date, month, year;

void init_i2c()
{
    TRISC3 = 1;         // config SCL as input
    TRISC4 = 1;         // Config SDA as input
    SMP = 1;            // slew rate for 100khz
    CKE = 0;            // Disable SMBus specific inputs
    
    SSPOV = 0;          // Receive Overflow Indicator bit 
    SSPEN = 1;          // Synchronous Serial Port Enable bit
    
    // configure as master mode 
    SSPCON = (SSPCON & ~((1 << 4) - 1));   
    SSPCON |= 0x08;
    
    SSPCON2 = 0x00;
    
    SSPIF = 0;          //  Synchronous Serial Port Interrupt Flag
    SSPIE = 0;          //  Synchronous Serial Port Interrupt Enable bit
    
    SSPADD = 49;
}

void i2c_start()
{
    SEN = 1;
    while(SEN);
    
}
unsigned char i2c_write(unsigned char data)
{
    SSPIF = 0;
    SSPBUF = data;
    while(SSPIF == 0);
    SSPIF = 0;
    return ACKSTAT;
}

unsigned char i2c_read(unsigned char ack)
{
    unsigned char data;
    RCEN = 1;           // Enables receive bit/ start receiving
    while(RCEN);
    ACKDT = ack;        // 0 -> sends ACK, 1 -> sends NACK
    ACKEN = 1;
    while(ACKEN);
    data = SSPBUF;
    return data;
}

void i2c_rep_start()
{
    RSEN = 1;
    while(RSEN);
}
void i2c_stop()
{
    PEN = 1;
    while(PEN);
}

void read_rtc()
{
    unsigned char data;
    i2c_start();
    i2c_write(0xD0);
    i2c_write(0x00);
    i2c_rep_start();
    i2c_write(0xD1);
    data = i2c_read(0);          // 0 because, we need more bytes to receive
    data = ((data & 0x70) >> 4)*10 + (data & 0x0F);
    sec = data;
    data = i2c_read(0);
    data = ((data & 0x70) >> 4)*10 + (data & 0x0F);
    min = data;
    data = i2c_read(0); 
    data = ((data & 0x30) >> 4)*10 + (data & 0x0F);
    hour = data;
    i2c_read(0);
    data = i2c_read(0);
    data = ((data & 0x30) >> 4)*10 + (data & 0x0F);
    date = data;
    data = i2c_read(0);
    data = ((data & 0x10) >> 4)*10 + (data & 0x0F);
    month = data;
    data = i2c_read(1);                             // 1-> because no more reading required
    data = ((data & 0xF0) >> 4)*10 + (data & 0x0F);
    year = data;
    i2c_stop();
}

void write_rtc(unsigned char h, unsigned char m, unsigned char s)
{
    unsigned char data;
    i2c_start();
    i2c_write(0xD0);
    i2c_write(0x00);
    data = ((s / 10 << 4) | s % 10) ;            
    data &= (1<<7)-1;                           // CH = 0 in the seconds register       
    i2c_write(data);                            // write in seconds register
    data = (m / 10 << 4) | m % 10; 
    i2c_write(data);                            // write in minutes register
    data = ((h / 10) << 4) | (h % 10);          
    data &= ~(1 << 6);                          // writes 6th bit 0 for 24 hour mode
    i2c_write(data);                            // write in hours register
    i2c_stop();
}

void write_rtc_date(unsigned char d, unsigned char m, unsigned char y)
{
    unsigned char data;
    i2c_start();
    i2c_write(0xD0);
    i2c_write(0x04);
    data = (d / 10 << 4) | d % 10; 
    i2c_write(data);
    data = (m / 10 << 4) | m % 10; 
    i2c_write(data);
    data = (y / 10 << 4) | y % 10; 
    i2c_write(data);
    i2c_stop();
}

