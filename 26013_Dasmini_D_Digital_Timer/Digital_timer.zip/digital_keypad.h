/* 
 * File:   digital_keypad.h
 * Author: Dasmini
 *
 * Created on 2 November, 2026, 9:51 PM
 */

#ifndef DIGITAL_KEYPAD_H
#define	DIGITAL_KEYPAD_H

#define LEVEL_DETECTION 0
#define LEVEL           0

#define STATE_DETECTION 1
#define STATE           1

#define KEYPAD_PORT     PORTB
#define KEYPAD_PORT_DDR TRISB

#define INPUT_LINES     0X3F

#define KEY_DOWN        0X3E
#define KEY_UP          0X3D
/*
#define SW3             0X3B
#define SW4             0X37
#define SW5             0X2F
#define SW6             0X1F
 */

#define ALL_RELEASED    INPUT_LINES

unsigned char read_digital_keypad(unsigned char mode);
void init_digital_keypad(void);

#endif	/* DIGITAL_KEYPAD_H */

