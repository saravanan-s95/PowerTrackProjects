/*
 * File:   screens.c
 * Author: Dasmini
 *
 * Created on 3 November, 2026, 3:56 PM
 */


#include <xc.h>
#pragma confid WDTE = OFF

static void init_config(void) {

}

void main(void) {
    init_config();
    while (1) {

    }
    return;
}
