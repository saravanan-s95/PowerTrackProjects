/* 
 * File:   i2c.h
 * Author: Dasmini
 *
 * Created on 31 October, 2026, 8:28 PM
 */

#ifndef I2C_H

void init_i2c();
void i2c_start();
unsigned char i2c_write(unsigned char data);
unsigned char i2c_read(unsigned char ack);
void i2c_rep_start();
void i2c_stop();
void read_rtc();
void write_rtc(unsigned char h, unsigned char m, unsigned char s);
void write_rtc_date(unsigned char d, unsigned char m, unsigned char y);

#endif	/* I2C_H */

