/* 
 * File:   screen.h
 * Author: Dasmini
 *
 * Created on 3 November, 2026, 3:59 PM
 */

#ifndef SCREEN_H
#define	SCREEN_H

#define DEFAULT_SCREEN              1
#define CONFIG_SCREEN               2
#define TIME_DATE_MENU_SCREEN       3
#define SET_VIEW_ALARM              4
#define SET_TIME_SCREEN             5
#define SET_DATE_SCREEN             6
#define SET_ALARM_SCREEN            7
#define VIEW_ALARM_SCREEN           8
#define ALARM_EDIT_DELETE_MENU      9
#define ALARM_EDIT_SCREEN           10
#define ALARM_DELETE_SCREEN         11

#define REPEAT_ONCE                 'O'
#define REPEAT_DAILY                'D'
#define REPEAT_WEEKLY               'W'
#define AM                          4
#define PM                          5
#define STATUS_EMPTY                0
#define STATUS_ACTIVE               1

typedef struct alarm
{
    unsigned char status;           // Active or not
    unsigned char repeat;          // repeat mode
    unsigned char hr;
    unsigned char minute;
    //unsigned char meridian;
    
} Alarm;

extern Alarm alarms[8];

unsigned int default_screen();
unsigned int config_screen();
unsigned int set_date_time();
unsigned int set_view_alarm();
unsigned int set_date();
unsigned int set_time();
unsigned int set_alarm_screen();
unsigned int view_alarm_screen();
unsigned int alarm_edit_delete_menu();
unsigned int alarm_edit_screen();
unsigned int alarm_delete_screen();

#endif	/* SCREEN_H */

