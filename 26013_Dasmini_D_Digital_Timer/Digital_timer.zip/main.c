/*
 * File:   main.c
 * Author: Dasmini
 *
 * Created on 30 October, 2026, 4:16 PM
 */


#include <xc.h>
#include "timer.h"
#include "clcd.h"
#include "i2c.h"
#include "digital_keypad.h"
#include "screen.h"

#pragma config WDTE = OFF

volatile unsigned int sec, min, hour, date, month, year;
volatile unsigned int idle_flag, timer_count, blink_phase, blink_timer, alarm_count, edit_delete_index;
Alarm alarms[8];

static void init_config(void) {
    init_timer1();
    init_clcd();
    init_i2c();
    init_digital_keypad();
    
    PEIE = 1;
    GIE = 1;
}

void main(void) {
    init_config();
    unsigned int screen = DEFAULT_SCREEN;
    unsigned int prev_screen = DEFAULT_SCREEN;
    while (1) {
        read_rtc();
        //display the read time(sec,min, hour) in clcd
        prev_screen = screen;
        if(screen == DEFAULT_SCREEN)
            screen = default_screen();
        else if(screen == CONFIG_SCREEN)
            screen = config_screen();
        else if(screen == TIME_DATE_MENU_SCREEN)
            screen = set_date_time();
        else if(screen == SET_VIEW_ALARM)
            screen = set_view_alarm();
        else if(screen == SET_TIME_SCREEN)
            screen = set_time();
        else if(screen == SET_DATE_SCREEN)
            screen = set_date();
        else if(screen == SET_ALARM_SCREEN)
            screen = set_alarm_screen();
        else if(screen == VIEW_ALARM_SCREEN)
            screen = view_alarm_screen();
        else if(screen == ALARM_EDIT_DELETE_MENU)
            screen = alarm_edit_delete_menu();
        else if(screen == ALARM_EDIT_SCREEN)
            screen = alarm_edit_screen();
        else if(screen == ALARM_DELETE_SCREEN)
            screen = alarm_delete_screen();
        
        if(prev_screen != screen)
        {
            clcd_clear(LINE1(0));
            clcd_clear(LINE2(0));
            timer_count = 0;
            idle_flag = 0;
        }
        
    }
    return;
}
