/* 
 * File:   rtc.h
 * Author: Dasmini
 *
 * Created on 1 November, 2026, 7:10 PM
 */

#ifndef RTC_H
#define	RTC_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* RTC_H */

