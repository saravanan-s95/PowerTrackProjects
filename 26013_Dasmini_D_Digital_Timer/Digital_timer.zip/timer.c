/*
 * File:   timer.c
 * Author: Dasmini
 *
 * Created on 30 October, 2026, 4:30 PM
 */


#include <xc.h>
#include "timer.h"
void init_timer1()
{
    T1CKPS1 = 0;    //prescaler
    T1CKPS0 = 0;    //prescaler
    T1OSCEN = 0;    //tmr1 oscilator
    TMR1CS = 0;     //we are using internal clock
    TMR1ON = 1;
    TMR1 = 3036;
    TMR1IE = 1;
    TMR1IF = 0;
    
}