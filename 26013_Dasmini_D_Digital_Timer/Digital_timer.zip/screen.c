/*
 * File:   screen.c
 * Author: Dasmini
 *
 * Created on 3 November, 2026, 3:59 PM
 */


#include <xc.h>
#include "clcd.h"
#include "screen.h"
#include "digital_keypad.h"
#include "i2c.h"
extern volatile unsigned int sec, min, hour, date, month, year;
extern volatile unsigned int idle_flag, timer_count, blink_phase, alarm_count, edit_delete_index;

void populate_disp_time(unsigned char* disp_time)
{
    unsigned int hour12;
    unsigned char meridiem;
    if(hour < 12)
    {
        meridiem = 'a';
        hour12 = hour;
        if(hour12 == 0)
            hour12 = 12;
    }
    else if(hour >= 12)
    {
        meridiem = 'p';
        hour12 = hour - 12;
        if(hour12 == 0)
            hour12 = 12;
    }
    disp_time[0] = (hour12/10) + '0';
    disp_time[1] = (hour12%10) + '0';
    disp_time[2] = ':';
    disp_time[3] = (min/10) + '0';
    disp_time[4] = (min%10) + '0';
    disp_time[5] = ' ';
    disp_time[6] = meridiem;
    disp_time[7] = 'm';
    disp_time[8] = '\0';
}
void populate_disp_date(unsigned char* date_arr)
{
    date_arr[0] = (date/10) + '0';
    date_arr[1] = (date%10) + '0';
    date_arr[2] = '/';
    date_arr[3] = (month/10) + '0';
    date_arr[4] = (month%10) + '0';
    date_arr[5] = '/';
    date_arr[6] = (year/10) + '0';
    date_arr[7] = (year%10) + '0';
    date_arr[8] = '\0';
    
}

void fill_time_arr(unsigned int h, unsigned int m, unsigned int s, unsigned char *arr)
{
    arr[0] = (h/10) + '0';
    arr[1] = (h%10) + '0';
    arr[2] = ':';
    arr[3] = (m/10) + '0';
    arr[4] = (m%10) + '0';
    arr[5] = ':';
    arr[6] = (s/10) + '0';
    arr[7] = (s%10) + '0';
    arr[8] = '\0';
}

void fill_date_arr(unsigned int d, unsigned int m, unsigned int y, unsigned char *arr)
{
    arr[0] = (d/10) + '0';
    arr[1] = (d%10) + '0';
    arr[2] = ':';
    arr[3] = (m/10) + '0';
    arr[4] = (m%10) + '0';
    arr[5] = ':';
    arr[6] = (y/10) + '0';
    arr[7] = (y%10) + '0';
    arr[8] = '\0';
}

unsigned int is_leap_year(unsigned int y)
{
    if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0))
        return 1;
    return 0;
}

unsigned char convert_to_12hour(unsigned char h, unsigned char* meridiem)
{
    unsigned char hour12;
    if(h < 12)
    {
        *meridiem = 'a';
        hour12 = h;
        if(hour12 == 0)
            hour12 = 12;
    }
    else if(h >= 12)
    {
        *meridiem = 'p';
        hour12 = h - 12;
        if(hour12 == 0)
            hour12 = 12;
    }
    return hour12;
}

void print_slot (unsigned char i)
{
    unsigned char arr[3];
    unsigned char data, meridiem, alarm_num;
    
    clcd_print("Alarm : ", LINE1(0));
    alarm_num = (i+1)+'0';
    clcd_putch(alarm_num, LINE1(8));
    if(alarms[i].status == STATUS_ACTIVE)
        clcd_print("Active",LINE1(10));
    else
    {
        clcd_print("Empty ",LINE1(10));
    }
        
    data = convert_to_12hour(alarms[i].hr, &meridiem);
    arr[0] = (data / 10) + '0';
    arr[1] = (data % 10) + '0';
    arr[2] = '\0';
    clcd_print(arr, LINE2(0));
    clcd_putch(':', LINE2(2));
    data = alarms[i].minute;
    arr[0] = (data / 10) + '0';
    arr[1] = (data % 10) + '0';
    clcd_print(arr, LINE2(3));
    clcd_putch(meridiem, LINE2(6));
    clcd_putch('m', LINE2(7));
   clcd_putch(alarms[i].repeat,LINE2(9));
}

void save_alarm(unsigned char h, unsigned char m, unsigned char meridiem, unsigned char repeat, unsigned char status)
{
    int i;
    if(alarm_count >= 8)
        return;
    if(meridiem == 'p')
    {
        if(h != 12)
            h = 12 + h;
    }
    else if(meridiem == 'a')
    {
        h = (h == 12)? 0 : h;
    }
    for(i = 0; i < 8; i++)
    {
        if(alarms[i].status != STATUS_ACTIVE)
            break;
    }
    alarms[i].hr = h;
    alarms[i].minute = m;
    alarms[i].repeat = repeat;
    alarms[i].status = status;
    alarm_count++;
}

void update_alarm(unsigned char h, unsigned char m, unsigned char meridiem, unsigned char repeat, unsigned char status)
{
    int i;
    if(alarm_count >= 8)
        return;
    if(meridiem == 'p')
    {
        if(h != 12)
            h = 12 + h;
    }
    else if(meridiem == 'a')
    {
        h = (h == 12)? 0 : h;
    }
    alarms[edit_delete_index].hr = h;
    alarms[edit_delete_index].minute = m;
    alarms[edit_delete_index].repeat = repeat;
    alarms[edit_delete_index].status = status;
    
}

unsigned int find_next_alarm()
{
    unsigned char i, h, m, min_diff_index;
    unsigned int min_diff = 0xffff, diff, alarm_time_tot, now_tot;
    now_tot = hour * 60 + min;
    for(i = 0; i < 8; i++)
    {
        if(alarms[i].status == STATUS_ACTIVE)
        {
            h = alarms[i].hr;
            m = alarms[i].minute;
            alarm_time_tot = h * 60 + m;
            diff = (alarm_time_tot - now_tot + 1440) % 1440;
            if(diff < min_diff)
            {
                min_diff = diff;
                min_diff_index = i;
            }
                
        }  
    }
    return min_diff_index;
}

unsigned int default_screen()
{
    unsigned char disp_date[16] = "                ";
    unsigned char disp_time[16] = "                ";
    unsigned char next_event[16] = "                ";
    unsigned char key, h, meridiem;
    unsigned int index;
    
    populate_disp_date(disp_date);
    populate_disp_time(disp_time);
    clcd_print("Date ", LINE1(0));
    clcd_print(disp_date, LINE1(5));
    if(sec % 5 < 2)
    {
        index = find_next_alarm();
        h = convert_to_12hour(alarms[index].hr, &meridiem);
        //clcd_clear(LINE2(0));
        clcd_print("Event : ", LINE2(0));
        next_event[0] = (h / 10) + '0';
        next_event[1] = (h % 10) + '0';
        next_event[2] = ':';
        next_event[3] = (alarms[index].minute / 10) + '0';
        next_event[4] = (alarms[index].minute / 10) + '0';
        next_event[5] = ' ';
        next_event[6] = meridiem;
        next_event[7] = 'm';
        next_event[8] = '\0';
        clcd_print(next_event, LINE2(8));
    }
    else
    {
        clcd_print("Time ", LINE2(0));
        clcd_print(disp_time, LINE2(5));
        clcd_print("  ", LINE2(14));
    }
    
    key = read_digital_keypad(STATE);

        if(key == KEY_UP || key == KEY_DOWN)
        {
            return CONFIG_SCREEN;
        }
        
    
    return DEFAULT_SCREEN;
}

unsigned int config_screen()
{
    static unsigned int selected = 0, count = 0;
    static unsigned char held_key;
    unsigned char key;
    key = read_digital_keypad(LEVEL);
    
    clcd_print("Set date/time", LINE1(2));
    clcd_print("Set/view alarm", LINE2(2));
    if(selected == 0)
    {
        clcd_putch('>', LINE1(0));
        clcd_clear_char(LINE2(0));
    }
    else
    {
        clcd_putch('>', LINE2(0));
        clcd_clear_char(LINE1(0));
    }
    if(key == KEY_UP || key == KEY_DOWN)
    {
        held_key = key;
        count++;
        timer_count = 0;
    }
    if(key == ALL_RELEASED)                 // short press
    {
        if(count > 0 && count < 5)
            selected = !selected;
        count = 0;
    }
    if(count >= 5)              // long press
    {
        count = 0;
        if(held_key == KEY_UP)
        {
            if(selected == 0)
                return TIME_DATE_MENU_SCREEN;
            else
                return SET_VIEW_ALARM;
        }
        else if(held_key == KEY_DOWN)
            return DEFAULT_SCREEN;
        
    }
    
    if(idle_flag == 1)
    {
        idle_flag = 0;
        timer_count = 0;
        return DEFAULT_SCREEN;
    }
    return CONFIG_SCREEN;
}

unsigned int set_date_time()
{
    static unsigned int selected = 0, count = 0;
    static unsigned char held_key;
    unsigned char key;
    key = read_digital_keypad(LEVEL);
    
    clcd_print("Set date", LINE1(2));
    clcd_print("Set time", LINE2(2));
    if(selected == 0)
    {
        clcd_putch('>', LINE1(0));
        clcd_clear_char(LINE2(0));
    }
    else
    {
        clcd_putch('>', LINE2(0));
        clcd_clear_char(LINE1(0));
    }
    if(key == KEY_UP || key == KEY_DOWN)
    {
        held_key = key;
        count++;
    }
    if(key == ALL_RELEASED)                 // short press
    {
        if(count > 0 && count < 5)
            selected = !selected;
        count = 0;
    }
    if(count >= 5)              // long press
    {
        count = 0;
        if(held_key == KEY_UP)
        {
            if(selected == 0)
                return SET_DATE_SCREEN;
            else
                return SET_TIME_SCREEN;
        }
        else if(held_key == KEY_DOWN)
            return CONFIG_SCREEN;
        
    }
    return TIME_DATE_MENU_SCREEN;
}

unsigned int set_view_alarm()
{
    static unsigned int selected = 0, count = 0;
    static unsigned char held_key;
    unsigned char key;
    key = read_digital_keypad(LEVEL);
    
    clcd_print("Set Alarm", LINE1(2));
    clcd_print("View Alarm", LINE2(2));
    if(selected == 0)
    {
        clcd_putch('>', LINE1(0));
        clcd_clear_char(LINE2(0));
    }
    else
    {
        clcd_putch('>', LINE2(0));
        clcd_clear_char(LINE1(0));
    }
    if(key == KEY_UP || key == KEY_DOWN)
    {
        held_key = key;
        count++;
    }
    if(key == ALL_RELEASED)                 // short press
    {
        if(count > 0 && count < 5)
            selected = !selected;
        count = 0;
    }
    if(count >= 5)              // long press
    {
        count = 0;
        if(held_key == KEY_UP)
        {
            if(selected == 0)
                return SET_ALARM_SCREEN;
            else
                return VIEW_ALARM_SCREEN;
        }
        else if(held_key == KEY_DOWN)
            return CONFIG_SCREEN;
        
    }
    return SET_VIEW_ALARM;
}

unsigned int set_date()
{
    unsigned char date_arr[16] = "                "; 
    static unsigned int count = 0, blink_pos = 0;
    static unsigned char held_key;
    unsigned char key;
    static unsigned int d, m, y;
    static unsigned char first = 1;
    
    if (first)
    {
        d = date, m = month, y = year;
        first = 0;
    }
    fill_date_arr(d, m , y, date_arr);
    
    clcd_print("DD:MM:YY", LINE1(0));
    if (blink_phase == 1)
    {
        date_arr[blink_pos]     = ' ';
        date_arr[blink_pos + 1] = ' ';
    }
    clcd_print(date_arr, LINE2(0));
    key = read_digital_keypad(LEVEL);
    if(key == KEY_UP || key == KEY_DOWN)
    {
        held_key = key;
        count++;
    }
    if(key == ALL_RELEASED)                 // short press
    {
        if(count > 0 && count < 5)
        {
            if(held_key == KEY_UP)
            {
                //code to increment the field
                if(blink_pos == 0)         // increment date
                {
                    if(m == 4 || m == 6 || m == 9 || m == 11)
                    {
                        if(d == 30)
                            d = 1;
                        else
                            d++;
                    }
                    else if(m == 2)
                    {
                        //seperate cases for leap and non leap year
                        if(is_leap_year(y))
                        {
                            if(d == 29)
                                d = 1;
                            else
                                d++;
                        }
                        else
                            if(d == 28)
                                d = 1;
                            else
                                d++;
                    }
                    else
                        if(d == 31)
                            d = 1;
                        else
                            d++;
                }
                else if(blink_pos == 3)     // increment month
                {
                    if(m == 12)
                        m = 1;
                    else
                        m++;
                }
                else if(blink_pos == 6)     // increment year
                {
                    if(y == 99)
                        y = 0;
                    else
                        y++;
                }
            }
            else if(held_key == KEY_DOWN)
            {
                if(blink_pos < 6)
                    blink_pos += 3;
                else
                    blink_pos = 0;
            }
            
            // check and correct date regard to month
            if((m == 4 || m == 6 || m == 9 || m == 11) && (d == 31))
                d = 30;
            else if(m == 2)
            {
                unsigned int max = is_leap_year(y) ? 29 : 28;
                if(d > max)
                    d = max;
            }
        }
        count = 0;
    }
    if(count >= 5)              // long press
    {
        count = 0;
        if(held_key == KEY_UP)
        {
            //code if nessasary
            write_rtc_date(d, m, y);
            return CONFIG_SCREEN;
            
        }
        else if(held_key == KEY_DOWN)
        {
            first = 1;
            return TIME_DATE_MENU_SCREEN;
        }
        
    }
    return SET_DATE_SCREEN;
}
unsigned int set_time()
{
    unsigned char time_arr[16] = "                "; 
    static unsigned int count = 0, blink_pos = 0;
    static unsigned char held_key;
    unsigned char key;
    static unsigned int h, m, s;
    static unsigned char first = 1;
    if (first)
    {
        h = hour; m = min; s = sec;
        first = 0;
    }
    fill_time_arr(h, m , s, time_arr);
    
    clcd_print("HH:MM:SS", LINE1(0));
    if (blink_phase == 1)
    {
        time_arr[blink_pos]     = ' ';
        time_arr[blink_pos + 1] = ' ';
    }
    clcd_print(time_arr, LINE2(0));
    key = read_digital_keypad(LEVEL);
    if(key == KEY_UP || key == KEY_DOWN)
    {
        held_key = key;
        count++;
    }
    if(key == ALL_RELEASED)                 // short press
    {
        if(count > 0 && count < 5)
        {
            if(held_key == KEY_UP)
            {
                //code to increment the field
                if(blink_pos == 0)
                {
                    // increment hour
                    if(h == 23)
                        h = 0;
                    else
                        h++;
                }
                else if(blink_pos == 3)
                {
                    // increment minute
                    if(m == 59)
                        m = 0;
                    else
                        m++;
                }
                else if(blink_pos == 6)
                {
                    // increment sec
                    if(s == 59)
                        s = 0;
                    else
                        s++;
                }
            }
            else if(held_key == KEY_DOWN)
            {
                if(blink_pos < 6)
                    blink_pos += 3;
                else
                    blink_pos = 0;
            }
        }
        count = 0;
    }
    if(count >= 5)              // long press
    {
        count = 0;
        if(held_key == KEY_UP)
        {
            //code if nessasary
            write_rtc(h, m, s);
            return CONFIG_SCREEN;
        }
        else if(held_key == KEY_DOWN)
        {
            first = 1;
            return TIME_DATE_MENU_SCREEN;
        }
        
    }
    
    return SET_TIME_SCREEN;
}

unsigned int set_alarm_screen()
{
    unsigned char alarm_time[16] = "                ";
    static unsigned int count = 0, blink_pos = 0;
    static unsigned char held_key;
    unsigned char key;
    static unsigned char h, m, repeat, am_pm, status = STATUS_ACTIVE;
    static unsigned char first = 1, repeat_flag = 0, meridiem_flag = 0;
    if(first)
    {
        h = 12;
        m = 0;
        repeat = REPEAT_ONCE;
        am_pm = 'a';
        first = 0;
    }
    clcd_print("HH:MM", LINE1(0));
    alarm_time[0] = (h / 10) + '0';
    alarm_time[1] = (h % 10) + '0';
    alarm_time[2] = ':';
    alarm_time[3] = (m / 10) + '0';
    alarm_time[4] = (m % 10) + '0';
    alarm_time[6] = am_pm;
    alarm_time[7] = 'm';
    alarm_time[9] = repeat;
    if (blink_phase == 1)
    {
        alarm_time[blink_pos]     = ' ';
        alarm_time[blink_pos + 1] = ' ';
    }
    clcd_print(alarm_time, LINE2(0));
    key = read_digital_keypad(LEVEL);

    if(key == KEY_UP || key == KEY_DOWN)
    {
        held_key = key;
        count++;
    }
    if(key == ALL_RELEASED)                 // short press
    {
        if(count > 0 && count < 5)
        {
            if(held_key == KEY_UP)
            {
                //code to increment the field
                if(blink_pos == 0)
                {
                    // increment hour
                    if(h == 12)
                        h = 1;
                    else
                        h++;
                }
                else if(blink_pos == 3)
                {
                    // increment minute
                    if(m == 59)
                        m = 0;
                    else
                        m++;
                }
                else if(blink_pos == 6)
                {
                    meridiem_flag = !meridiem_flag;
                    if(meridiem_flag == 0)
                        am_pm = 'a';
                    else
                        am_pm = 'p';
                }
                else if(blink_pos == 9)
                {
                    if(repeat_flag == 2)
                        repeat_flag = 0;
                    else
                        repeat_flag++;
                    switch(repeat_flag)
                    {
                        case 0:
                            repeat = REPEAT_ONCE;
                            break;
                        case 1:
                            repeat = REPEAT_DAILY;
                            break;
                        case 2:
                            repeat = REPEAT_WEEKLY;
                            break;
                        default:
                            break;
                     
                    }
                    // display repeat values one by one
                    
                }
            }
            else if(held_key == KEY_DOWN)
            {
                if(blink_pos < 9)
                    blink_pos += 3;
                else
                    blink_pos = 0;
            }
        }
        count = 0;
    }
    if(count >= 5)              // long press
    {
        count = 0;
        if(held_key == KEY_UP)
        {
            //save alarm to the alarms struct array
            save_alarm(h, m, am_pm, repeat, status);
            first = 1;
            return CONFIG_SCREEN;
        }
        else if(held_key == KEY_DOWN)
        {
            first = 1;
            return SET_VIEW_ALARM;
        }
        
    }
    
    return SET_ALARM_SCREEN;
}
unsigned int view_alarm_screen()
{
    static unsigned char alarm_index = 0;
    unsigned char key;
    static unsigned char first = 1;
    static unsigned int count = 0;
    static unsigned char held_key;
    
    if(first)
    {
        alarm_index = 0;
        first = 0;
    }
    print_slot(alarm_index);
    // record keypress and on key press increment alarm_index so that the next slots will display
    key = read_digital_keypad(LEVEL);
    if(key == KEY_UP || key == KEY_DOWN)
    {
        held_key = key;
        count++;
    }
    if(key == ALL_RELEASED)                 // short press
    {
        if(count > 0 && count < 5)
        {
            if(held_key == KEY_UP)
            {
                // display next alarm slot
                if(alarm_index == 7)
                    alarm_index = 0;
                else
                    alarm_index++;
            }
            else if(held_key == KEY_DOWN)
            {
                // display prev alarm slot
                if(alarm_index == 0)
                    alarm_index = 7;
                else
                    alarm_index--;
            }
        }
        count = 0;
    }
    if(count >= 10)              // long press
    {
        count = 0;
        if(held_key == KEY_UP)
        {
            // Enter the alarm edit/delete screen
            first = 1;
            edit_delete_index = alarm_index;
            if(alarms[alarm_index].status = STATUS_ACTIVE)
                return ALARM_EDIT_DELETE_MENU;
        }
        else if(held_key == KEY_DOWN)
        {
            first = 1;
            edit_delete_index = alarm_index;
            return SET_VIEW_ALARM;
        }
        
    }
    
    return VIEW_ALARM_SCREEN;
}

unsigned int alarm_edit_delete_menu()
{
    static unsigned int selected = 0, count = 0;
    static unsigned char held_key;
    unsigned char key;
    key = read_digital_keypad(LEVEL);
    
    clcd_print("Edit Alarm", LINE1(2));
    clcd_print("Delete Alarm", LINE2(2));
    if(selected == 0)
    {
        clcd_putch('>', LINE1(0));
        clcd_clear_char(LINE2(0));
    }
    else
    {
        clcd_putch('>', LINE2(0));
        clcd_clear_char(LINE1(0));
    }
    if(key == KEY_UP || key == KEY_DOWN)
    {
        held_key = key;
        count++;
    }
    if(key == ALL_RELEASED)                 // short press
    {
        if(count > 0 && count < 5)
            selected = !selected;
        count = 0;
    }
    if(count >= 5)              // long press
    {
        count = 0;
        if(held_key == KEY_UP)
        {
            if(selected == 0)
                return ALARM_EDIT_SCREEN;
            else
                return ALARM_DELETE_SCREEN;
        }
        else if(held_key == KEY_DOWN)
            return SET_VIEW_ALARM;
        
    }
    return ALARM_EDIT_DELETE_MENU;
}
unsigned int alarm_edit_screen()
{
    unsigned char alarm_time[16] = "                ";
    static unsigned int count = 0, blink_pos = 0;
    static unsigned char held_key;
    unsigned char key;
    static unsigned char h, m, repeat, am_pm, status = STATUS_ACTIVE;
    static unsigned char first = 1, repeat_flag = 0, meridiem_flag = 0;
    if(first)
    {
        h = alarms[edit_delete_index].hr;
        m = alarms[edit_delete_index].minute;
        repeat = alarms[edit_delete_index].repeat;
        am_pm = (h < 12)? 'a': 'p';
        first = 0;
    }
    clcd_print("HH:MM", LINE1(0));
    alarm_time[0] = (h / 10) + '0';
    alarm_time[1] = (h % 10) + '0';
    alarm_time[2] = ':';
    alarm_time[3] = (m / 10) + '0';
    alarm_time[4] = (m % 10) + '0';
    alarm_time[6] = am_pm;
    alarm_time[7] = 'm';
    alarm_time[9] = repeat;
    if (blink_phase == 1)
    {
        alarm_time[blink_pos]     = ' ';
        alarm_time[blink_pos + 1] = ' ';
    }
    clcd_print(alarm_time, LINE2(0));
    key = read_digital_keypad(LEVEL);

    if(key == KEY_UP || key == KEY_DOWN)
    {
        held_key = key;
        count++;
    }
    if(key == ALL_RELEASED)                 // short press
    {
        if(count > 0 && count < 5)
        {
            if(held_key == KEY_UP)
            {
                //code to increment the field
                if(blink_pos == 0)
                {
                    // increment hour
                    if(h == 12)
                        h = 1;
                    else
                        h++;
                }
                else if(blink_pos == 3)
                {
                    // increment minute
                    if(m == 59)
                        m = 0;
                    else
                        m++;
                }
                else if(blink_pos == 6)
                {
                    meridiem_flag = !meridiem_flag;
                    if(meridiem_flag == 0)
                        am_pm = 'a';
                    else
                        am_pm = 'p';
                }
                else if(blink_pos == 9)
                {
                    if(repeat_flag == 2)
                        repeat_flag = 0;
                    else
                        repeat_flag++;
                    switch(repeat_flag)
                    {
                        case 0:
                            repeat = REPEAT_ONCE;
                            break;
                        case 1:
                            repeat = REPEAT_DAILY;
                            break;
                        case 2:
                            repeat = REPEAT_WEEKLY;
                            break;
                        default:
                            break;
                     
                    }
                    // display repeat values one by one
                    
                }
            }
            else if(held_key == KEY_DOWN)
            {
                if(blink_pos < 9)
                    blink_pos += 3;
                else
                    blink_pos = 0;
            }
        }
        count = 0;
    }
    if(count >= 5)              // long press
    {
        count = 0;
        if(held_key == KEY_UP)
        {
            //save alarm to the alarms struct array
            update_alarm(h, m, am_pm, repeat, status);
            first = 1;
            return VIEW_ALARM_SCREEN;
        }
        else if(held_key == KEY_DOWN)
        {
            first = 1;
            return ALARM_EDIT_DELETE_MENU;
        }
        
    }
    
    return ALARM_EDIT_SCREEN;
}
unsigned int alarm_delete_screen()
{
    alarms[edit_delete_index].status = STATUS_EMPTY;
    return VIEW_ALARM_SCREEN;
}