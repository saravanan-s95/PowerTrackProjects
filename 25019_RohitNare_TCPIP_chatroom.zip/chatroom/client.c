
/*#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>

int main()
{
    // 1. create the TCP/IP socket
    // AF_INET ipv4
    // SOCK_STREAM it will create the TCP/IP socket
    int sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (sock_fd == -1)
    {
        perror("socket");
        return -1;
    }
    // 2. bind the ip address and port number
    struct sockaddr_in server_info;
    // family is the domain name
    server_info.sin_family = AF_INET;
    // taking the port number as 3000 converting into host byte order to network
    server_info.sin_port = htons(3001);
    // 127.0.0.1 loop back address which acts as server by default
    // inet_addr() which converts the string to binary directly
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");

    // send connectio request to server
    if (connect(sock_fd, (struct sockaddr *)&server_info, sizeof(server_info)) == -1)
    {
        perror("connect");
        return -1;
    }
    char buffer[100];
    char option = 'y';

    while (option == 'y')
    {

        printf("Enter the msg send to server : ");
        scanf("%s", buffer);
        // sedning the information to the server
        send(sock_fd, buffer, strlen(buffer), 0);

        printf("Continue(y/n)? :");
        scanf(" %c", &option);
        send(sock_fd, &option, 1, 0);
    }
}
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 6333
#define BUF_SIZE 1024

int sockfd;

void *receive_msg(void *arg)
{
    char buffer[BUF_SIZE];

    while(1)
    {
        memset(buffer, 0, sizeof(buffer));

        int n = recv(sockfd,
                     buffer,
                     sizeof(buffer),
                     0);

        if(n <= 0)
        {
            printf("Disconnected from server\n");
            exit(0);
        }

        printf("%s", buffer);
    }
}

int main()
{
    struct sockaddr_in server_addr;

    sockfd = socket(AF_INET,
                    SOCK_STREAM,
                    0);

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);

    inet_pton(AF_INET,
              "127.0.0.1",
              &server_addr.sin_addr);

    connect(sockfd,
            (struct sockaddr *)&server_addr,
            sizeof(server_addr));

    char username[50];

    printf("Enter username : ");
    scanf("%s", username);

    getchar();

    send(sockfd,
         username,
         strlen(username) + 1,
         0);

    pthread_t recv_thread;

    pthread_create(&recv_thread,
                   NULL,
                   receive_msg,
                   NULL);

    char buffer[BUF_SIZE];

    while(1)
    {
        fgets(buffer,
              sizeof(buffer),
              stdin);

        send(sockfd,
             buffer,
             strlen(buffer),
             0);
    }

    close(sockfd);

    return 0;
}