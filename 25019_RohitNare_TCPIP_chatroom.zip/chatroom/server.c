
/*#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <string.h>

int user count = 0;

int main()
{
    // 1. create the TCP/IP socket
    // AF_INET ipv4
    // SOCK_STREAM it will create the TCP/IP socket
    int sock_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (sock_fd == -1)
    {
        perror("socket");
        return -1;
    }
    // 2. bind the ip address and port number
    struct sockaddr_in server_info;
    struct sockaddr_in client_info;

    // family is the domain name
    server_info.sin_family = AF_INET;
    // taking the port number as 3000 converting into host byte order to network
    server_info.sin_port = htons(3001);
    // 127.0.0.1 loop back address which acts as server by default
    // inet_addr() which converts the string to binary directly
    server_info.sin_addr.s_addr = inet_addr("127.0.0.1");
    bind(sock_fd, (struct sockaddr *)&server_info, sizeof(server_info));

    printf("Waiting for the Client connection\n");
    // 3. fixing the queue size
    listen(sock_fd, 5);
    // 4. accept the client request
    int data_fd = accept(sock_fd, NULL, NULL);
    if (data_fd == -1)
    {
        perror("accept");
        return -1;
    }
    printf("connection is established with the client\n");

    // receiving the data from the client
    char buffer[100] = {'\0'};
    char option = 'y';
    
  while (option == 'y')
     
    {
        printf("Waiting for the Data from the client:\n");
        recv(data_fd, buffer, 100, 0);

        printf("Client message is %s\n", buffer);

        recv(data_fd, &option, 1, 0);
        
        
    }

     

}
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 6333
#define MAX_CLIENTS 100
#define BUF_SIZE 1024

typedef struct
{
    int sockfd;
    char username[50];
} client_t;

client_t clients[MAX_CLIENTS];
int client_count = 0;

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void broadcast(char *msg, int sender_fd)
{
    pthread_mutex_lock(&lock);

    for(int i = 0; i < client_count; i++)
    {
        if(clients[i].sockfd != sender_fd)
        {
            send(clients[i].sockfd, msg, strlen(msg), 0);
        }
    }

    pthread_mutex_unlock(&lock);
}

void remove_client(int sockfd)
{
    pthread_mutex_lock(&lock);

    for(int i = 0; i < client_count; i++)
    {
        if(clients[i].sockfd == sockfd)
        {
            clients[i] = clients[client_count - 1];
            client_count--;
            break;
        }
    }

    pthread_mutex_unlock(&lock);
}

void *client_handler(void *arg)
{
    int sockfd = *(int *)arg;
    free(arg);

    char buffer[BUF_SIZE];
    char username[50];

    memset(buffer, 0, sizeof(buffer));

    recv(sockfd, username, sizeof(username), 0);

    pthread_mutex_lock(&lock);

    strcpy(clients[client_count].username, username);
    clients[client_count].sockfd = sockfd;
    client_count++;

    pthread_mutex_unlock(&lock);

    sprintf(buffer, "%s joined the chat\n", username);
    printf("%s", buffer);

    broadcast(buffer, sockfd);

    while(1)
    {
        memset(buffer, 0, sizeof(buffer));

        int n = recv(sockfd, buffer, sizeof(buffer), 0);

        if(n <= 0)
            break;

        char msg[BUF_SIZE];

        sprintf(msg, "[%s]: %s", username, buffer);

        printf("%s", msg);

        broadcast(msg, sockfd);
    }

    sprintf(buffer, "%s left the chat\n", username);

    printf("%s", buffer);

    broadcast(buffer, sockfd);

    remove_client(sockfd);

    close(sockfd);

    return NULL;
}

int main()
{
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len;

    server_fd = socket(AF_INET, SOCK_STREAM, 0);

    if(server_fd < 0)
    {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    bind(server_fd,
         (struct sockaddr *)&server_addr,
         sizeof(server_addr));

    listen(server_fd, 10);

    printf("Server listening on port %d...\n", PORT);

    while(1)
    {
        addr_len = sizeof(client_addr);

        client_fd = accept(server_fd,
                          (struct sockaddr *)&client_addr,
                          &addr_len);

        printf("Client connected\n");

        int *new_sock = malloc(sizeof(int));
        *new_sock = client_fd;

        pthread_t tid;

        pthread_create(&tid,
                       NULL,
                       client_handler,
                       new_sock);

        pthread_detach(tid);
    }

    close(server_fd);

    return 0;
}