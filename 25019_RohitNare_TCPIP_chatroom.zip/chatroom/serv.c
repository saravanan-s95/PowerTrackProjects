#include "../include/chat.h"
#include "db.h"
#include<stdio.h>


user_t users[MAX_USERS];

int user_count = 0;

pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void send_online_users(int sockfd);
void broadcast_status(char *username, char *status);
void broadcast_message(chat_msg_t *msg);
void private_message(chat_msg_t *msg);
void *client_handler(void *arg);

void send_online_users(int sockfd)
{
    int i;
    char buffer[1024];

    strcpy(buffer, "\n===== ONLINE USERS =====\n");

    pthread_mutex_lock(&lock);

    for(i = 0; i < user_count; i++)
    {
        if(users[i].status)
        {
            strcat(buffer, users[i].username);
            strcat(buffer, "\n");
        }
    }

    pthread_mutex_unlock(&lock);

    strcat(buffer, "========================\n");

    send(sockfd, buffer, strlen(buffer), 0);
}

void broadcast_status(char *username, char *status)
{
    int i;
    char buffer[256];

    sprintf(buffer, "\nUser %s is %s\n", username, status);

    pthread_mutex_lock(&lock);

    for(i = 0; i < user_count; i++)
    {
        if(users[i].status)
        {
            send(users[i].sockfd, buffer, strlen(buffer), 0);
        }
    }

    pthread_mutex_unlock(&lock);
}

void broadcast_message(chat_msg_t *msg)
{
    int i;
    char buffer[1024];

    sprintf(buffer, "\n[GROUP][%s] : %s\n", msg->sender, msg->message);

    pthread_mutex_lock(&lock);

    for(i = 0; i < user_count; i++)
    {
        if(users[i].status)
        {
            send(users[i].sockfd, buffer, strlen(buffer), 0);
        }
    }

    pthread_mutex_unlock(&lock);
}

void private_message(chat_msg_t *msg)
{
    int i;
    char buffer[1024];

    sprintf(buffer, "\n[PRIVATE][%s] : %s\n", msg->sender, msg->message);

    pthread_mutex_lock(&lock);

    for(i = 0; i < user_count; i++)
    {
        if(users[i].status && strcmp(users[i].username, msg->receiver) == 0)
        {
            send(users[i].sockfd, buffer, strlen(buffer), 0);
            break;
        }
    }

    pthread_mutex_unlock(&lock);
}
void *client_handler(void *arg)
{
    int sockfd;
    int index;
    request_t req;
    reply_t reply;
    chat_msg_t msg;

    sockfd = *(int *)arg;
    free(arg);

    if(recv(sockfd, &req, sizeof(req), 0) <= 0)
    {
        close(sockfd);
        pthread_exit(NULL);
    }

    if(req.option == REGISTER)
    {
        if(add_user(users, &user_count, req.username, req.password))
        {
            reply.status = SUCCESS;
            strcpy(reply.message, "Registered successfully");
        }
        else
        {
            reply.status = FAILURE;
            strcpy(reply.message, "Duplicate user-name");
        }

        send(sockfd, &reply, sizeof(reply), 0);

        close(sockfd);

        pthread_exit(NULL);
    }

    if(req.option == LOGIN)
    {
        index = authenticate_user(users, user_count, req.username, req.password);

        if(index == -1)
        {
            reply.status = FAILURE;
            strcpy(reply.message, "user-name not found");
        }
        else if(index == -2)
        {
            reply.status = FAILURE;
            strcpy(reply.message, "Password not matching");
        }
        else
        {
            reply.status = SUCCESS;
            strcpy(reply.message, "Logged in successfully");

            set_online(users, index, sockfd);

            update_database(users, user_count);
        }

        send(sockfd, &reply, sizeof(reply), 0);

        if(reply.status == FAILURE)
        {
            close(sockfd);
            pthread_exit(NULL);
        }

        send_online_users(sockfd);

        broadcast_status(req.username, "ONLINE");
    }

    while(1)
    {
        if(recv(sockfd, &msg, sizeof(msg), 0) <= 0)
        {
            break;
        }

        if(msg.chat_option == SINGLE_CHAT)
        {
            private_message(&msg);
        }
        else if(msg.chat_option == GROUP_CHAT)
        {
            broadcast_message(&msg);
        }
        else if(msg.chat_option == LOGOUT)
        {
            index = find_user(users, user_count, msg.sender);

            if(index >= 0)
            {
                set_offline(users, index);

                update_database(users, user_count);

                broadcast_status(msg.sender, "OFFLINE");
            }

            break;
        }
    }

    close(sockfd);

    pthread_exit(NULL);
}

int main()
{
    int server_fd;
    int client_fd;

    int *new_sock;

    struct sockaddr_in server_addr;
    struct sockaddr_in client_addr;

    socklen_t client_len;

    pthread_t tid;

    user_count = load_database(users);

    server_fd = socket(AF_INET, SOCK_STREAM, 0);

    if(server_fd < 0)
    {
        perror("socket");
        return -1;
    }

    memset(&server_addr, 0, sizeof(server_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(SERVER_PORT);

    if(bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        perror("bind");
        close(server_fd);
        return -1;
    }

    if(listen(server_fd, 10) < 0)
    {
        perror("listen");
        close(server_fd);
        return -1;
    }

    printf("\n====================================\n");
    printf(" TCP/IP CHAT SERVER STARTED\n");
    printf(" PORT : %d\n", SERVER_PORT);
    printf("====================================\n");

    while(1)
    {
        client_len = sizeof(client_addr);

        client_fd = accept(server_fd,
                          (struct sockaddr *)&client_addr,
                          &client_len);

        if(client_fd < 0)
        {
            perror("accept");
            continue;
        }

        printf("Client Connected : %s\n",
               inet_ntoa(client_addr.sin_addr));

        new_sock = malloc(sizeof(int));

        if(new_sock == NULL)
        {
            close(client_fd);
            continue;
        }

        *new_sock = client_fd;

        pthread_create(&tid,
                       NULL,
                       client_handler,
                       new_sock);

        pthread_detach(tid);
    }

    close(server_fd);

    return 0;
}