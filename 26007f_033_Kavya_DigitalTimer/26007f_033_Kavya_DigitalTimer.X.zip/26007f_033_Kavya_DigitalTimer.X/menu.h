/* 
 * File:   menu.h
 * Author: Kavya
 *
 * Created on 26 October, 2026, 2:01 PM
 */

#ifndef MENU_H
#define	MENU_H

#define DEFAULT_SCREEN  0
#define CONFIG_MENU     1
#define SET_TIME_DATE   2
#define ALARM_LIST      3
#define ALARM_EDIT      4

#endif	/* MENU_H */

