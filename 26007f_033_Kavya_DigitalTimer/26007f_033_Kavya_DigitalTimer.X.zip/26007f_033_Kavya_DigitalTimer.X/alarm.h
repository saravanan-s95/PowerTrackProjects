/* 
 * File:   alarm.h
 * Author: Kavya
 *
 * Created on 26 October, 2026, 2:02 PM
 */

#ifndef ALARM_H
#define	ALARM_H

#define MAX_ALARMS          4

// Alarm Activation Modes
#define ALARM_OFF            0
#define ALARM_ONCE          'O'
#define ALARM_DAILY         'D'
#define ALARM_WEEKLY        'W'

typedef struct {
    unsigned char hour;
    unsigned char min;
    unsigned char mode;   // 'O', 'D', 'W'
    unsigned char active; // 1 = Enabled, 0 = Disabled/Deleted
} Alarm_t;

extern Alarm_t alarm_table[MAX_ALARMS]; 

void alarm_list_screen(unsigned char key);
void check_alarms(unsigned char *clock_reg);

#endif	/* ALARM_H */

