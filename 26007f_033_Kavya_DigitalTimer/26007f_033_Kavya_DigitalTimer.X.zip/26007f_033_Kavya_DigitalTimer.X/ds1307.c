/*
 * File:   ds1307.c
 * Author: Kavya
 *
 * Created on 26 October, 2026, 2:35 PM
 */


#include <xc.h>
#include "main.h"
#include "i2c.h"

void init_ds1307(void)
{
    unsigned char dummy;
    
    dummy = read_ds1307(SEC_ADDR);
    dummy = dummy & 0x7F;    
    write_ds1307(SEC_ADDR, dummy);// CH = 0
}

unsigned char read_ds1307(unsigned char addr)
{
    unsigned char data;
    
    i2c_start();
    i2c_write(SLAVE_WRITE);
    i2c_write(addr);
    i2c_rep_start();
    i2c_write(SLAVE_READ);
    data = i2c_read(0);
    i2c_stop();
    
    return data;
}

void write_ds1307(unsigned char addr, unsigned char data) // SEc_ADDR, data
{
    i2c_start();
    i2c_write(SLAVE_WRITE);
    i2c_write(addr);
    i2c_write(data);
    i2c_stop();
}

void get_time(unsigned char *clock_reg)
{
    clock_reg[0] = read_ds1307(HOUR_ADDR); // HH -> BCD 
    clock_reg[1] = read_ds1307(MIN_ADDR); // MM -> BCD 
    clock_reg[2] = read_ds1307(SEC_ADDR); // SS -> BCD 
}
char time[9];  // "HH:MM:SS"

void display_time(unsigned char *clock_reg)
{
    //BCD Format
   
    // HH
    time[0] = ((clock_reg[0] >> 4) & 0x03) + '0';
    time[1] = (clock_reg[0] & 0x0F) + '0';
    
    time[2] = ':';
    // MM 
    time[3] = ((clock_reg[1] >> 4) & 0x07) + '0';
    time[4] = (clock_reg[1] & 0x0F) + '0';
    
    time[5] = ':';
    // SS
    time[6] = ((clock_reg[2] >> 4) & 0x07) + '0';
    time[7] = (clock_reg[2] & 0x0F) + '0';
    time[8] = '\0';

    clcd_print("TIME:", LINE1(0));
    clcd_print(time, LINE1(5)); // HH:MM:SS 
}

void get_date(unsigned char *clock_reg)
{
    clock_reg[3] = read_ds1307(0x04); // date 
    clock_reg[4] = read_ds1307(0x05); // month
    clock_reg[5] = read_ds1307(0x06); // year 
}
char date[9];  // "DD-MM-YY"

void display_date(unsigned char *clock_reg)
{
    //BCD Format
   
    // DD
    date[0] = ((clock_reg[3] >> 4) & 0x0F) + '0';
    date[1] = (clock_reg[3] & 0x0F) + '0';
    
    date[2] = '-';
    // MM 
    date[3] = ((clock_reg[4] >> 4) & 0x01) + '0';
    date[4] = (clock_reg[4] & 0x0F) + '0';
    
    date[5] = '-';
    // YY
    date[6] = ((clock_reg[5] >> 4) & 0x0F) + '0';
    date[7] = (clock_reg[5] & 0x0F) + '0';
    
    date[8] = '\0';

    clcd_print("DATE:", LINE2(0));   
    clcd_print(date, LINE2(5));  
}

