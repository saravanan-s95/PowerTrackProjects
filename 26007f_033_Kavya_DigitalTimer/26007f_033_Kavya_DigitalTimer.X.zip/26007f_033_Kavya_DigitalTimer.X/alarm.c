/*
 * File:   alarm.c
 * Author: Kavya
 *
 * Created on 26 October, 2026, 2:03 PM
 */
#include <xc.h>
#include "main.h"

#define LONG_PRESS_TICKS    10  // ~1.5 seconds under 150ms loop delay

#define ALRM_HR_FIELD     0
#define ALRM_MIN_FIELD    1
#define ALRM_MODE_FIELD   2

// BCD to Decimal Conversion 
static unsigned char bcd_to_dec(unsigned char bcd)
{
    return (unsigned char)((((bcd & 0xF0) >> 4) * 10) + (bcd & 0x0F));
}

static unsigned char dec_to_bcd(unsigned char dec)
{
    return (unsigned char)(((dec / 10) << 4) | (dec % 10));
}

void set_time_date(unsigned char key)
{
    static unsigned char hr, min, sec, day, month, year;
    static unsigned char current_field = HOUR_FIELD;
    static unsigned char initialized = 0;
    
    static unsigned char last_key = ALL_RELEASED;
    static unsigned char hold_count = 0;
    static unsigned char blink_state = 0;
    static unsigned char blink_counter = 0;

    // Read from RTC
    if (initialized == 0)
    {
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        
        hr    = bcd_to_dec(read_ds1307(HOUR_ADDR));
        min   = bcd_to_dec(read_ds1307(MIN_ADDR));
        sec   = bcd_to_dec(read_ds1307(SEC_ADDR));
        day   = bcd_to_dec(read_ds1307(0x04)); // Day register
        month = bcd_to_dec(read_ds1307(0x05)); // Month register
        year  = bcd_to_dec(read_ds1307(0x06)); // Year register

        current_field = HOUR_FIELD;
        last_key = ALL_RELEASED;
        hold_count = 0;
        blink_state = 0;
        blink_counter = 0;
        
        initialized = 1;
        return;
    }

    // 1Hz Blinking Framework Controller
    blink_counter++;
    if (blink_counter >= 3)
    {
        blink_state = !blink_state;
        blink_counter = 0;
    }

    // Active Button Timing Tracker Module
    if (key != ALL_RELEASED)
    {
        if (key == last_key)
        {
            hold_count++;
            
            // --- LONG PRESS ---
            if (hold_count == LONG_PRESS_TICKS)
            {
                if (key == SW1)
                {
                    // Long SW1: SAVE and commit parameters to RTC hardware registers
                    write_ds1307(HOUR_ADDR, dec_to_bcd(hr));
                    write_ds1307(MIN_ADDR, dec_to_bcd(min));
                    write_ds1307(SEC_ADDR, dec_to_bcd(sec));
                    
                    // Force the continuous sequential block tracking alignment
                    write_ds1307(0x04, dec_to_bcd(day));   
                    write_ds1307(0x05, dec_to_bcd(month)); 
                    write_ds1307(0x06, dec_to_bcd(year));  
                    
                    initialized = 0;
                    screen = CONFIG_MENU;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    return;
                }
                else if (key == SW2)
                {
                    // Long SW2: ABORT without saving
                    initialized = 0;
                    screen = CONFIG_MENU;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    return;
                }
            }
        }
        else
        {
            last_key = key;
            hold_count = 1;
        }
    }
    else
    {
        // --- SHORT PRESS  ---
        if (last_key != ALL_RELEASED)
        {
            if (hold_count < LONG_PRESS_TICKS)
            {
                if (last_key == SW2)
                {
                    // Short SW2: Cycle through editing fields circularly
                    current_field = (current_field + 1) % 6;
                }
                else if (last_key == SW1)
                {
                    // Short SW1: Increment value with clean rollovers
                    switch (current_field)
                    {
                        case HOUR_FIELD:  hr = (hr + 1) % 24; break;
                        case MIN_FIELD:   min = (min + 1) % 60; break;
                        case SEC_FIELD:   sec = (sec + 1) % 60; break;
                        case DAY_FIELD:   
                            if (month == 2) {
                                unsigned int full_year = 2000 + year;
                                unsigned char leap = ((full_year % 4 == 0 && full_year % 100 != 0) || (full_year % 400 == 0)) ? 1 : 0;
                                if (day >= (leap ? 29 : 28)) day = 1;
                                else day++;
                            }
                            else if (month == 4 || month == 6 || month == 9 || month == 11) {
                                if (day >= 30) day = 1;
                                else day++;
                            }
                            else {
                                if (day >= 31) day = 1;
                                else day++;
                            }
                            break;
                        case MONTH_FIELD: 
                            if (month >= 12) month = 1;
                            else month++;
                            break;
                        case YEAR_FIELD:  year = (year + 1) % 100; break;
                    }
                }
            }
            last_key = ALL_RELEASED;
            hold_count = 0;
        }
    }

    unsigned char disp_hr    = (current_field == HOUR_FIELD  && blink_state) ? 0xFF : hr;
    unsigned char disp_min   = (current_field == MIN_FIELD   && blink_state) ? 0xFF : min;
    unsigned char disp_sec   = (current_field == SEC_FIELD   && blink_state) ? 0xFF : sec;
    unsigned char disp_day   = (current_field == DAY_FIELD   && blink_state) ? 0xFF : day;
    unsigned char disp_month = (current_field == MONTH_FIELD && blink_state) ? 0xFF : month;
    unsigned char disp_year  = (current_field == YEAR_FIELD  && blink_state) ? 0xFF : year;

    // Line 1 Update Layout (TIME: HH:MM:SS)
    clcd_print("TIME: ", LINE1(0));
    if (disp_hr == 0xFF)    clcd_print("  ", LINE1(6));
    else { clcd_putch((disp_hr / 10) + '0', LINE1(6)); clcd_putch((disp_hr % 10) + '0', LINE1(7)); }
    clcd_putch(':', LINE1(8));
    if (disp_min == 0xFF)   clcd_print("  ", LINE1(9));
    else { clcd_putch((disp_min / 10) + '0', LINE1(9)); clcd_putch((disp_min % 10) + '0', LINE1(10)); }
    clcd_putch(':', LINE1(11));
    if (disp_sec == 0xFF)   clcd_print("  ", LINE1(12));
    else { clcd_putch((disp_sec / 10) + '0', LINE1(12)); clcd_putch((disp_sec % 10) + '0', LINE1(13)); }

    // Line 2 Update Layout (DATE: DD/MM/YY)
    clcd_print("DATE: ", LINE2(0));
    if (disp_day == 0xFF)   clcd_print("  ", LINE2(6));
    else { clcd_putch((disp_day / 10) + '0', LINE2(6)); clcd_putch((disp_day % 10) + '0', LINE2(7)); }
    clcd_putch('/', LINE2(8));
    if (disp_month == 0xFF) clcd_print("  ", LINE2(9));
    else { clcd_putch((disp_month / 10) + '0', LINE2(9)); clcd_putch((disp_month % 10) + '0', LINE2(10)); }
    clcd_putch('/', LINE2(11));
    if (disp_year == 0xFF)  clcd_print("  ", LINE2(12));
    else { clcd_putch((disp_year / 10) + '0', LINE2(12)); clcd_putch((disp_year % 10) + '0', LINE2(13)); }
}

void alarm_list_screen(unsigned char key)
{
    static unsigned char current_index = 0;
    static unsigned char initialized = 0;
    static unsigned char last_key = ALL_RELEASED;
    static unsigned char hold_count = 0;

    if (initialized == 0)
    {
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        current_index = 0;
        last_key = ALL_RELEASED;
        hold_count = 0;
        initialized = 1;
    }

    // --- Key Input State Handler ---
    if (key != ALL_RELEASED)
    {
        if (key == last_key)
        {
            hold_count++;
            if (hold_count == 10) // Long Press Threshold met
            {
                if (key == SW2) // Long SW2: Exit back to Config Menu 
                {
                    initialized = 0;
                    screen = CONFIG_MENU;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    return;
                }
                else if (key == SW1) // Long SW1: Enter Highlighted Alarm Edit Screen 
                {
                    current_alarm_index = current_index; // Pass active slot index
                    initialized = 0;
                    screen = ALARM_EDIT;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    return;
                }
            }
        }
        else
        {
            last_key = key;
            hold_count = 1;
        }
    }
    else
    {
        if (last_key != ALL_RELEASED)
        {
            if (hold_count < 10) // Short Press
            {
                if (last_key == SW1) // Short SW1: Move Up/Next Alarm
                {
                    current_index = (current_index + 1) % MAX_ALARMS;
                }
                else if (last_key == SW2) // Short SW2: Delete the highlighted alarm [Fig10]
                {
                    alarm_table[current_index].active = 0;
                }
            }
            last_key = ALL_RELEASED;
            hold_count = 0;
        }
    }

    char buffer[17];
    
    clcd_print("--- ALARMS ---  ", LINE1(0));
  
    if (alarm_table[current_index].active == 1)
    {
        // Format: "A1: 07:00 Mode:O"
        buffer[0] = 'A';
        buffer[1] = (current_index + 1) + '0';
        buffer[2] = ':';
        buffer[3] = ' ';
        buffer[4] = (alarm_table[current_index].hour / 10) + '0';
        buffer[5] = (alarm_table[current_index].hour % 10) + '0';
        buffer[6] = ':';
        buffer[7] = (alarm_table[current_index].min / 10) + '0';
        buffer[8] = (alarm_table[current_index].min % 10) + '0';
        buffer[9] = ' ';
        buffer[10] = 'M';
        buffer[11] = 'o';
        buffer[12] = 'd';
        buffer[13] = ':';
        buffer[14] = alarm_table[current_index].mode;
        buffer[15] = '\0';
    }
    else
    {
        buffer[0] = 'A';
        buffer[1] = (current_index + 1) + '0';
        buffer[2] = ':';
        buffer[3] = ' ';
        buffer[4] = 'E';
        buffer[5] = 'M';
        buffer[6] = 'P';
        buffer[7] = 'T';
        buffer[8] = 'Y';
        buffer[9] = '\0';
    }
    clcd_print("                ", LINE2(0)); 
    clcd_print(buffer, LINE2(0));
}

void alarm_edit_screen(unsigned char key)
{
    static unsigned char hr, min, mode_char;
    static unsigned char current_field = ALRM_HR_FIELD;
    static unsigned char initialized = 0;
    
    static unsigned char last_key = ALL_RELEASED;
    static unsigned char hold_count = 0;
    static unsigned char blink_state = 0;
    static unsigned char blink_counter = 0;

    //  Read active parameters into local RAM edit variables
    if (initialized == 0)
    {
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
        
        hr        = alarm_table[current_alarm_index].hour;
        min       = alarm_table[current_alarm_index].min;
        mode_char = alarm_table[current_alarm_index].mode;
  
        if (alarm_table[current_alarm_index].active == 0)
        {
            hr = 0; min = 0; mode_char = 'O';
        }

        current_field = ALRM_HR_FIELD;
        last_key = ALL_RELEASED;
        hold_count = 0;
        blink_state = 0;
        blink_counter = 0;
        
        initialized = 1;
        return;
    }

    // 1Hz Blinking Framework Driver (~450ms cycle toggle rate)
    blink_counter++;
    if (blink_counter >= 3)
    {
        blink_state = !blink_state;
        blink_counter = 0;
    }

    if (key != ALL_RELEASED)
    {
        if (key == last_key)
        {
            hold_count++;
            
            // --- LONG PRESS ---
            if (hold_count == 10) // Long Press boundary met (~1.5s hold time)
            {
                if (key == SW1) // Long SW1: SAVE and Return to Config Screen 
                {
                    alarm_table[current_alarm_index].hour   = hr;
                    alarm_table[current_alarm_index].min    = min;
                    alarm_table[current_alarm_index].mode   = mode_char;
                    alarm_table[current_alarm_index].active = 1; // Mark as enabled
                    
                    initialized = 0;
                    screen = CONFIG_MENU;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    return;
                }
                else if (key == SW2) // Long SW2: CANCEL/ABORT changes without saving
                {
                    initialized = 0;
                    screen = CONFIG_MENU;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    return;
                }
            }
        }
        else
        {
            last_key = key;
            hold_count = 1;
        }
    }
    else
    {
        // --- SHORT PRESS ---
        if (last_key != ALL_RELEASED)
        {
            if (hold_count < 10) // Short Press validation
            {
                if (last_key == SW2) // Short SW2: Cycle editing segments circularly
                {
                    current_field = (current_field + 1) % 3;
                }
                else if (last_key == SW1) // Short SW1: Increment field with clean rollovers
                {
                    switch (current_field)
                    {
                        case ALRM_HR_FIELD: 
                            hr = (hr + 1) % 24; 
                            break;
                        case ALRM_MIN_FIELD: 
                            min = (min + 1) % 60; 
                            break;
                        case ALRM_MODE_FIELD:
                            if (mode_char == 'O')      mode_char = 'D'; // Once -> Daily
                            else if (mode_char == 'D') mode_char = 'W'; // Daily -> Weekly
                            else                       mode_char = 'O'; // Weekly -> Once
                            break;
                    }
                }
            }
            last_key = ALL_RELEASED;
            hold_count = 0;
        }
    }

    unsigned char disp_hr   = (current_field == ALRM_HR_FIELD   && blink_state) ? 0xFF : hr;
    unsigned char disp_min  = (current_field == ALRM_MIN_FIELD  && blink_state) ? 0xFF : min;
    unsigned char disp_mode = (current_field == ALRM_MODE_FIELD && blink_state) ? 0xFF : mode_char;

    // Line 1: Title
    char title_buf[17] = "EDIT ALARM A1   ";
    title_buf[12] = (current_alarm_index + 1) + '0';
    clcd_print(title_buf, LINE1(0));

    // Line 2: ("Time: HH:MM Mode:X")
    clcd_print("TIME: ", LINE2(0));
    
    if (disp_hr == 0xFF) clcd_print("  ", LINE2(6));
    else { clcd_putch((disp_hr / 10) + '0', LINE2(6)); clcd_putch((disp_hr % 10) + '0', LINE2(7)); }
    
    clcd_putch(':', LINE2(8));
    
    if (disp_min == 0xFF) clcd_print("  ", LINE2(9));
    else { clcd_putch((disp_min / 10) + '0', LINE2(9)); clcd_putch((disp_min % 10) + '0', LINE2(10)); }
    
    clcd_print(" MODE:", LINE2(11));
    if (disp_mode == 0xFF) clcd_putch(' ', LINE2(16));
    else clcd_putch(disp_mode, LINE2(16));
}
