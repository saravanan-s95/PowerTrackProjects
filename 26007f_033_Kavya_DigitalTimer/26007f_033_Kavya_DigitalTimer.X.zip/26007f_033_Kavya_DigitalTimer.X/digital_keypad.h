/* 
 * File:   digital_keypad.h
 * Author: Kavya
 *
 * Created on 26 October, 2026, 2:02 PM
 */

#ifndef DIGITAL_KEYPAD_H
#define	DIGITAL_KEYPAD_H

#define KEYPAD_PORT_DDR TRISB
#define KEYPAD_PORT     PORTB
#define INPUT_LINES     0x3F
#define LEVEL_DETECT    0
#define LEVEL           0
#define STATE_DETECT    1
#define STATE           1

#define  SW1  0x3E
#define  SW2  0x3D
#define  SW3  0x3B
#define  SW4  0x37
#define  ALL_RELEASED  INPUT_LINES

void init_keypad(void);
unsigned char read_digital_keypad(unsigned char mode);

#endif