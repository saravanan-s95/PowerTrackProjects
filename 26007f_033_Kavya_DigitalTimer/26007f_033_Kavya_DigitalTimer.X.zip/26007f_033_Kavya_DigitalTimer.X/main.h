/* 
 * File:   main.h
 * Author: Kavya
 *
 * Created on 26 October, 2026, 2:01 PM
 */

/* Switches for operation
   Default Screen (Time/Date Display): 
 *   - Press SW1 or SW2 (Short Press): Enters the Config Menu Screen.
   Config Menu Screen (*Set Time/Date, Set/View Alarm) : 
 *   - Short press SW1: UP
 *   - Short press SW2: DOWN, 
 *   - Long press SW1: Enters the selected menu item (either opens Set Time/Date or Set/View Alarms)
 *   - Long press SW2: goes back to the Default Screen.
   Set Time & Date Screen: 
 *   - Short press SW2: we can change Hours ? Minutes ? Seconds ? Day ? Month ? Year
 *   - Short press SW1: Increments the number value,
 *   - Long press SW1: Saves the edited time/date to the RTC
 *   - Long press SW2: returns to config menu without saving
   Set / View Alarms Screen (ALARM_LIST): 
 *   - Enter the Menu: Long-press SW1 
 *   - Short press SW1: UP (A1, A2, A3, A4)
 *   - Short press SW2: Deletes / Clears the highlighted alarm,
 *   - Long press SW2: Exits 
   Edit Alarm(Set / View Alarms Screen (ALARM_LIST):
 *   - Scroll to particular alarm to edit : Long-press SW1(The screen shifts into the editing view! The Hours parameter begins flashing at 1Hz)
 *   - Short press SW2 : assign new numbers
 *   - Long-press SW1 : save
 */
#ifndef MAIN_H
#define	MAIN_H

#include "alarm.h"
#include "clcd.h"
#include "clock.h"
#include "digital_keypad.h"
#include "ds1307.h"
#include "menu.h"
#include "i2c.h"

#define DEFAULT_SCREEN  0
#define CONFIG_MENU     1
#define SET_TIME_DATE   2
#define ALARM_LIST      3
#define ALARM_EDIT      4

// Field indices
#define HOUR_FIELD        0
#define MIN_FIELD         1
#define SEC_FIELD         2
#define DAY_FIELD         3
#define MONTH_FIELD       4
#define YEAR_FIELD        5

#define BUZZER          PORTCbits.RC1
#define BUZZER_DDR      TRISCbits.TRISC1

extern volatile unsigned char screen;
extern unsigned char current_alarm_index;

void init_ds1307(void);
unsigned char clcd_write(unsigned char byte, unsigned char mode);
void get_time(unsigned char *clock_reg);
void display_time(unsigned char *clock_reg);
void get_date(unsigned char *clock_reg);
void display_date(unsigned char *clock_reg);
void display_clock(void);
void menu(unsigned char key);
unsigned char read_digital_keypad(unsigned char mode);
void set_time_date(unsigned char key);
void alarm_list_screen(unsigned char key);
void check_alarms(unsigned char *clock_reg);
void alarm_edit_screen(unsigned char key);

#endif	/* MAIN_H */

