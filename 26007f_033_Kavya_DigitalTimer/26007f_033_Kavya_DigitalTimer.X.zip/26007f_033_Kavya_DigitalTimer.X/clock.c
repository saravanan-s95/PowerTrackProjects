/*
 * File:   clock.c
 * Author: Kavya
 *
 * Created on 26 October, 2026, 2:03 PM
 */


#include <xc.h>
#include "main.h"
#pragma config WDTE = OFF

unsigned char clock_reg[6];

void display_clock(void)
{
    get_time(clock_reg);
    display_time(clock_reg);
    
    get_date(clock_reg);
    display_date(clock_reg);
}

void check_alarms(unsigned char *clock_reg)
{
    // Local tracking arrays to convert raw RTC BCD bytes to Decimal integers
    unsigned char current_hour = (((clock_reg[0] & 0x30) >> 4) * 10) + (clock_reg[0] & 0x0F);
    unsigned char current_min  = (((clock_reg[1] & 0x70) >> 4) * 10) + (clock_reg[1] & 0x0F);
    unsigned char current_sec  = (((clock_reg[2] & 0x70) >> 4) * 10) + (clock_reg[2] & 0x0F);
    
    static unsigned char alarm_ringing = 0;
    unsigned char any_alarm_match = 0;
    
    // Buzzer pin as output 
    BUZZER_DDR = 0; 

    for (unsigned char i = 0; i < MAX_ALARMS; i++)
    {
        if (alarm_table[i].active == 1)
        {
            if (current_hour == alarm_table[i].hour && current_min == alarm_table[i].min)
            {
                any_alarm_match = 1;
                
                // Ring the buzzer for the first 30 seconds 
                if (current_sec < 30)
                {
                    BUZZER = !BUZZER; // Toggle pin to create a beeping sound tone
                }
                else
                {
                    BUZZER = 0; // Turn off buzzer after 30 seconds
                }

                // If the mode is set to 'O' (Once), disable 
                if (alarm_table[i].mode == ALARM_ONCE && current_sec >= 59)
                {
                    alarm_table[i].active = 0; // Prevent repeating tomorrow
                }
            }
        }
    }

    // Turn off the buzzer if no alarm 
    if (!any_alarm_match)
    {
        BUZZER = 0;
    }
}



