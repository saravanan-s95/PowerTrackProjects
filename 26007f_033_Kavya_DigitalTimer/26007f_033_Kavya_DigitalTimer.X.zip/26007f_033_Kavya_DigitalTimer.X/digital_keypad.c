/*
 * File:   digital_keypad.c
 * Author: Kavya
 *
 * Created on 26 October, 2026, 2:34 PM
 */


#include <xc.h>
#include "digital_keypad.h"
#pragma config WDTE = OFF

void init_keypad(void) 
{
    KEYPAD_PORT_DDR = KEYPAD_PORT_DDR | INPUT_LINES;
}

unsigned char read_digital_keypad(unsigned char mode)
{
    static unsigned char once = 1;
    
    if(mode == LEVEL_DETECT)
    {
        return KEYPAD_PORT & INPUT_LINES;
    }
    
    if (mode == STATE_DETECT)
    {
        if (((KEYPAD_PORT & INPUT_LINES) != ALL_RELEASED) && once)
        {
            once = 0;
            
            return KEYPAD_PORT & INPUT_LINES;
        }
        else if ((KEYPAD_PORT & INPUT_LINES) == ALL_RELEASED)
        {
            once = 1;
        }
    }
    return ALL_RELEASED;
}
