/*
 * File:   main.c
 * Author: Kavya
 * Description : To create a Digital Alarm Clock to Display the current time and date, Allow the user to change the time and date,
 *               Allow the user to create, view, edit, and delete alarms.
 * To Do : Initialize the LCD, keypad and RTC. Display the current time and date.
 *         Default screen : Refresh time/date, implement the next-alarm display interval, and enter Config Mode on UP or DOWN.
 *         Config Mode: Implement menu navigation, long-press selection, logout and the 5-second idle timeout.
 *         Set: Implement field selection, incrementing, rollover, blinking and writing values to the RTC.
 *         Create the alarm array, display alarms one by one, navigate through them and delete an alarm.
 *         Edit alarm time, select once/daily/weekly, configure the weekday when required, and save changes.
 *         Compare the RTC time with enabled alarms, trigger the appropriate event and prevent one-time alarms from repeating. 
 * Created on 26 October, 2026, 2:35 PM
 */


#include <xc.h>
#include "main.h"
#include "i2c.h"
#pragma config WDTE = OFF

#define  _XTAL_FREQ  20000000UL

volatile unsigned char screen = DEFAULT_SCREEN;

unsigned char menu_pos = 0;
unsigned char key;
unsigned char previous_key = ALL_RELEASED;
Alarm_t alarm_table[MAX_ALARMS];
unsigned char current_alarm_index = 0;

static void init_config(void) {
    init_clcd();
    init_i2c(100000);
    init_keypad();
    init_ds1307();
}

void main(void) {
    unsigned char clock_reg[6];
    static unsigned int default_screen_tick = 0;
    init_config();
    alarm_table[0].hour = 6;  alarm_table[0].min =  39; alarm_table[0].mode = ALARM_ONCE;  alarm_table[0].active = 1;
    alarm_table[1].hour = 12; alarm_table[1].min = 30; alarm_table[1].mode = ALARM_DAILY; alarm_table[1].active = 1;
    alarm_table[2].hour = 18; alarm_table[2].min = 45; alarm_table[2].mode = ALARM_WEEKLY;alarm_table[2].active = 0; // Disabled
    alarm_table[3].hour = 0;  alarm_table[3].min =  0; alarm_table[3].mode = ALARM_OFF;   alarm_table[3].active = 0;
    while (1) 
    {
        key = read_digital_keypad(STATE);
        switch(screen)
        {
            case DEFAULT_SCREEN:
                // Display time and date
                get_time(clock_reg);
                get_date(clock_reg);
                check_alarms(clock_reg); // alarm
                display_time(clock_reg);
                default_screen_tick++;
                if (default_screen_tick <= 34) // First 5 seconds (~34 * 150ms = 5.1s)
                {
                    display_date(clock_reg); // Shows Date on Line 2 [Fig1]
                }
                else if (default_screen_tick <= 47) // 2 seconds display window
                {
                    // first scheduled active alarm slot configuration
                    if (alarm_table[0].active == 1)
                    {
                        char alb[17] = "Alrm: 00:00    ";
                        alb[6]  = (alarm_table[0].hour / 10) + '0';
                        alb[7]  = (alarm_table[0].hour % 10) + '0';
                        alb[9]  = (alarm_table[0].min / 10) + '0';
                        alb[10] = (alarm_table[0].min % 10) + '0';
                        alb[12] = alarm_table[0].mode; // 'O', 'D', 'W' [Fig2, Fig3, Fig4]
                        clcd_print(alb, LINE2(0));
                    }
                    else
                    {
                        clcd_print("Alrm: NONE     ", LINE2(0));
                    }
                }
                else
                {
                    // Reset back to 0 
                    default_screen_tick = 0;
                }
                // Check for UP or DOWN
                if (key == SW1 || key == SW2) // press sw1 or sw2 to enter into config screen
                {
                    default_screen_tick = 0;
                    screen = CONFIG_MENU;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                }
                break;

            case CONFIG_MENU:
                // Display menu
                menu(read_digital_keypad(LEVEL));
                break;

            case SET_TIME_DATE:
                // Edit clock time
                set_time_date(read_digital_keypad(LEVEL));
                break;

            case ALARM_LIST:
                alarm_list_screen(read_digital_keypad(LEVEL));
                break;

            case ALARM_EDIT:
                // Create or edit an alarm
                alarm_edit_screen(read_digital_keypad(LEVEL));
                break;
        }
        __delay_ms(150);
    }
    return;
}
