/*
 * File:   menu.c
 * Author: Kavya
 *
 * Created on 26 October, 2026, 2:35 PM
 */

#include <xc.h>
#include "main.h"

#define MENU_COUNT          2

// 150ms loop delay adjustment:
#define LONG_PRESS_TICKS    10  // 10 * 150ms = ~1.5 seconds of sustained hold 
#define IDLE_TIMEOUT_TICKS  34  // 34 * 150ms = ~5.1 seconds of total inactivity

void menu(unsigned char key)
{
    static const char *menu_items[MENU_COUNT] = {"Set Time/Date", "Set/View Alarm"};

    static unsigned char selected_row = 0;
    static unsigned char initialized = 0;
    static unsigned char redraw = 1;
    
    static unsigned char last_key = ALL_RELEASED;
    static unsigned char hold_count = 0;
    static unsigned char idle_count = 0;

    // Reset components on state re-entry 
    if (initialized == 0)
    {
        clcd_write(CLEAR_DISP_SCREEN, INST_MODE);

        selected_row = 0;
        redraw = 1;
        last_key = ALL_RELEASED;
        hold_count = 0;
        idle_count = 0;

        initialized = 1;
        return;
    }

    // 1. Idle Timeout Tracking Module
    if (key != ALL_RELEASED)
    {
        idle_count = 0; // Clears instantly on any button state change
    }
    else
    {
        idle_count++;
        if (idle_count >= IDLE_TIMEOUT_TICKS)
        {
            screen = DEFAULT_SCREEN;
            initialized = 0;
            clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
            return;
        }
    }

    // 2. Active Button Processing Framework
    if (key != ALL_RELEASED)
    {
        if (key == last_key)
        {
            hold_count++;
            
            // Evaluated actively BEFORE the user lets go of the switch
            if (hold_count == LONG_PRESS_TICKS)
            {
                if (key == SW1)
                {
                    // Long SW1: Open Selection
                    screen = (selected_row == 0) ? SET_TIME_DATE : ALARM_LIST;
                    initialized = 0;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    return;
                }
                else if (key == SW2)
                {
                    // Long SW2: Jump directly back to baseline clock display screen
                    screen = DEFAULT_SCREEN;
                    initialized = 0;
                    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
                    return;
                }
            }
        }
        else
        {
            // Initial capture registration 
            last_key = key;
            hold_count = 1;
        }
    }
    else 
    {
        // 3. Clean Release Phase Handler (Short Press Router)
        if (last_key != ALL_RELEASED)
        {
            if (hold_count < LONG_PRESS_TICKS)
            {
                if (last_key == SW1)
                {
                    // Short SW1: Selection shifts up
                    if (selected_row > 0)
                    {
                        selected_row--;
                        redraw = 1;
                    }
                }
                else if (last_key == SW2)
                {
                    // Short SW2: Selection shifts down
                    if (selected_row < MENU_COUNT - 1)
                    {
                        selected_row++;
                        redraw = 1;
                    }
                }
            }
            
            // Clean registers upon physical release structural drop
            last_key = ALL_RELEASED;
            hold_count = 0;
        }
    }

    // 4. Interface Rendering Update Logic (FIXED INDEXES)
    if (redraw)
    {
        clcd_print("                ", LINE1(0));
        clcd_print("                ", LINE2(0));

        // Fixed: Explicitly index arrays [0] and [1] to output string text properly
        clcd_print(menu_items[0], LINE1(1));
        clcd_print(menu_items[1], LINE2(1));

        if (selected_row == 0)
        {
            clcd_putch('*', LINE1(0));
        }
        else
        {
            clcd_putch('*', LINE2(0));
        }

        redraw = 0;
    }
}
