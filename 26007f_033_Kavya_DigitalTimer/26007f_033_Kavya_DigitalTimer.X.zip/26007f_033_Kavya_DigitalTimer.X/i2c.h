/* 
 * File:   i2c.h
 * Author: Kavya
 *
 * Created on 26 October, 2026, 3:41 PM
 */
#ifndef I2C_H
#define I2C_H

void init_i2c(unsigned long baud);
void i2c_start(void);
void i2c_rep_start(void);
void i2c_stop(void);
void i2c_write(unsigned char data);
unsigned char i2c_read(unsigned char ack); 

#endif