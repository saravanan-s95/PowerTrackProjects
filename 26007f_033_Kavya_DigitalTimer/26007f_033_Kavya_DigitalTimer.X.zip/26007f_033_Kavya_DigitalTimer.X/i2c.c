/*
 * File:   i2c.c
 * Author: Kavya
 *
 * Created on 26 October, 2026, 3:41 PM
 */
#include <xc.h>
#include "i2c.h"

#define _XTAL_FREQ 20000000UL

void init_i2c(unsigned long baud)
{
    TRISC3 = 1;  // SCL
    TRISC4 = 1;  // SDA

    SSPCON = 0x28;
    SSPCON2 = 0x00;
    SSPSTAT = 0x00;

    SSPADD = (_XTAL_FREQ / (4UL * baud)) - 1;
}

void i2c_start(void)
{
    SEN = 1;
    while (SEN);
}

void i2c_rep_start(void)
{
    RSEN = 1;
    while (RSEN);
}

void i2c_stop(void)
{
    PEN = 1;
    while (PEN);
}

void i2c_write(unsigned char data)
{
    SSPBUF = data;
    while (BF);
    while (SSPIF == 0);
    SSPIF = 0;
}

unsigned char i2c_read(unsigned char ack)
{
    unsigned char data;

    RCEN = 1;
    while (RCEN);

    data = SSPBUF;

    ACKDT = (ack == 0) ? 1 : 0;
    ACKEN = 1;
    while (ACKEN);

    return data;
}
