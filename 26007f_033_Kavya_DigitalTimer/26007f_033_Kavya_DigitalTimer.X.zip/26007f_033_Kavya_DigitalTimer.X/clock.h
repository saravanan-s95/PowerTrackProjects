/* 
 * File:   clock.h
 * Author: Kavya
 *
 * Created on 26 October, 2026, 2:02 PM
 */

#ifndef CLOCK_H
#define	CLOCK_H

void display_clock(void);

#endif	/* CLOCK_H */

