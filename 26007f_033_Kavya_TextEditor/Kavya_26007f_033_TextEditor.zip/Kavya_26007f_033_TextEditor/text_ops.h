#ifndef TEXT_OPS_H
#define TEXT_OPS_H

#include "text_editor.h"
#include <stddef.h>

int text_insert(TextEditor *ed, const char *text);

size_t text_delete(TextEditor *ed, size_t count);

int text_newline(TextEditor *ed);

int text_backspace(TextEditor *ed);

int text_delete_line(TextEditor *ed);

void text_copy(TextEditor *ed, size_t count);

int text_cut(TextEditor *ed, size_t count);

int text_paste(TextEditor *ed);

#endif
