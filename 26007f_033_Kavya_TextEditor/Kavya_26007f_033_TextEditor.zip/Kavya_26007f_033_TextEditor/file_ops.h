#ifndef FILE_OPS_H
#define FILE_OPS_H

#include "text_editor.h"

int file_open(TextEditor *ed, const char *filename);
int file_save(TextEditor *ed, const char *filename);

#endif
