/* Name : Kavya.M
   Date : 18.10.2026
   Description : This project implements a console-based text editor written in C that provides essential text editing capabilities.
   Operation : Commands:
    insert <text>       Insert text
    delete <count>      Delete characters
    newline             Create a new line
    backspace           Delete character on the left
    del-line            Delete current line
    up/down/left/right  Move cursor
    home/end            Start/end of current line
    top/bottom          Start/end of document
    goto <line> <col>   Move cursor to position
    copy <count>        Copy characters
    cut <count>         Cut characters
    paste               Paste copied text
    find <text>         Search text
    replace <old>|<new> Replace text
    open <filename>     Open file
    save [filename]     Save file
    close               Clear document
    print               Display document
    undo / redo         Undo or redo
    help                Display commands
    exit                Quit editor how to work on it
*/
#include "text_editor.h"
#include "text_ops.h"
#include "cursor_nav.h"
#include "file_ops.h"
#include "display_search.h"
#include "redo_undo.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define INPUT_SIZE 2048

static void trim_newline(char *s)
{
    size_t n = strlen(s);

    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r'))
    {
        s[--n] = '\0';
    }
}

static void print_help(void)
{
    puts("\nCommands:");
    puts("insert <text>       Insert text");
    puts("delete <count>      Delete characters");
    puts("newline             Create a new line");
    puts("backspace           Delete character on the left");
    puts("del-line            Delete current line");
    puts("up/down/left/right  Move cursor");
    puts("home/end            Start/end of current line");
    puts("top/bottom          Start/end of document");
    puts("goto <line> <col>   Move cursor to position");
    puts("copy <count>        Copy characters");
    puts("cut <count>         Cut characters");
    puts("paste               Paste copied text");
    puts("find <text>         Search text");
    puts("replace <old>|<new> Replace text");
    puts("open <filename>     Open file");
    puts("save [filename]     Save file");
    puts("close               Clear document");
    puts("print               Display document");
    puts("undo / redo         Undo or redo");
    puts("help                Display commands");
    puts("exit                Quit editor");
}

int main(void)
{
    TextEditor ed;

    SnapshotStack undo = {0};
    SnapshotStack redo = {0};

    char input[INPUT_SIZE];

    editor_init(&ed);

    if (!ed.head)
    {
        fputs("Out of memory.\n", stderr);
        return 1;
    }

    puts("========== C TEXT EDITOR ==========");
    puts("Type 'help' to see commands.");

    display_text(&ed);

    while (1)
    {
        printf("\ntext-editor> ");

        if (!fgets(input, sizeof(input), stdin))
            break;

        trim_newline(input);

        if (!input[0])
            continue;

        char *command = input;

        while (isspace((unsigned char)*command))
            command++;

        char *arg = command;

        while (*arg && !isspace((unsigned char)*arg))
            arg++;

        if (*arg)
        {
            *arg++ = '\0';

            while (isspace((unsigned char)*arg))
                arg++;
        }

        if (strcmp(command, "help") == 0)
        {
            print_help();
        }
        else if (strcmp(command, "print") == 0)
        {
            display_text(&ed);
        }
        else if (strcmp(command, "insert") == 0)
        {
            if (undo_save(&ed, &undo))
            {
                if (text_insert(&ed, arg))
                {
                    redo_clear(&redo);
                    puts("Text inserted.");
                }
                else
                {
                    undo_discard_latest(&undo);
                    puts("Insert failed.");
                }
            }
        }
        else if (strcmp(command, "delete") == 0)
        {
            char *end;
            unsigned long n = strtoul(arg, &end, 10);

            if (arg == end || *end || n == 0)
            {
                puts("Usage: delete <positive_count>");
            }
            else if (undo_save(&ed, &undo))
            {
                size_t deleted = text_delete(&ed, (size_t)n);

                if (deleted)
                {
                    redo_clear(&redo);
                    printf("Deleted %zu character(s).\n",
                           deleted);
                }
                else
                {
                    undo_discard_latest(&undo);
                    puts("Nothing to delete.");
                }
            }
        }
        else if (strcmp(command, "newline") == 0)
        {
            if (undo_save(&ed, &undo))
            {
                if (text_newline(&ed))
                {
                    redo_clear(&redo);
                    puts("New line inserted.");
                }
                else
                {
                    undo_discard_latest(&undo);
                    puts("Could not insert new line.");
                }
            }
        }
        else if (strcmp(command, "backspace") == 0)
        {
            if (ed.cursor_col == 0)
            {
                puts("Nothing to backspace.");
            }
            else if (undo_save(&ed, &undo))
            {
                if (text_backspace(&ed))
                {
                    redo_clear(&redo);
                    puts("Character deleted.");
                }
            }
        }
        else if (strcmp(command, "del-line") == 0)
        {
            if (undo_save(&ed, &undo))
            {
                if (text_delete_line(&ed))
                {
                    redo_clear(&redo);
                    puts("Line deleted.");
                }
                else
                {
                    undo_discard_latest(&undo);
                }
            }
        }
        else if (strcmp(command, "left") == 0)
        {
            cursor_left(&ed);
        }
        else if (strcmp(command, "right") == 0)
        {
            cursor_right(&ed);
        }
        else if (strcmp(command, "up") == 0)
        {
            cursor_up(&ed);
        }
        else if (strcmp(command, "down") == 0)
        {
            cursor_down(&ed);
        }
        else if (strcmp(command, "home") == 0)
        {
            cursor_home(&ed);
        }
        else if (strcmp(command, "end") == 0)
        {
            cursor_end(&ed);
        }
        else if (strcmp(command, "top") == 0)
        {
            editor_set_cursor(&ed, 1, 0);
        }
        else if (strcmp(command, "bottom") == 0)
        {
            cursor_bottom(&ed);
        }
        else if (strcmp(command, "goto") == 0)
        {
            size_t line;
            size_t col;

            if (sscanf(arg, "%zu %zu", &line, &col) != 2 ||
                line == 0 || !line_at(&ed, line))
            {
                puts("Usage: goto <valid_line> <column>");
            }
            else
            {
                editor_set_cursor(&ed, line, col);
            }
        }
        else if (strcmp(command, "copy") == 0 || strcmp(command, "cut") == 0)
        {
            char *end;
            unsigned long n = strtoul(arg, &end, 10);

            if (arg == end || *end || n == 0)
            {
                puts("Usage: copy/cut <positive_count>");
            }
            else if (strcmp(command, "copy") == 0)
            {
                text_copy(&ed, (size_t)n);
            }
            else if (undo_save(&ed, &undo))
            {
                if (text_cut(&ed, (size_t)n))
                {
                    redo_clear(&redo);
                }
                else
                {
                    undo_discard_latest(&undo);
                }
            }
        }
        else if (strcmp(command, "paste") == 0)
        {
            if (undo_save(&ed, &undo))
            {
                if (text_paste(&ed))
                {
                    redo_clear(&redo);
                    puts("Text pasted.");
                }
                else
                {
                    undo_discard_latest(&undo);
                    puts("Paste failed.");
                }
            }
        }
        else if (strcmp(command, "find") == 0)
        {
            display_find(&ed, arg);
        }
        else if (strcmp(command, "replace") == 0)
        {
            char *sep = strchr(arg, '|');

            if (!sep)
            {
                puts("Usage: replace <old>|<new>");
            }
            else
            {
                *sep++ = '\0';

                if (!*arg)
                {
                    puts("Old text cannot be empty.");
                }
                else if (undo_save(&ed, &undo))
                {
                    size_t n =
                        display_replace(&ed, arg, sep);

                    if (n)
                        redo_clear(&redo);
                    else
                        undo_discard_latest(&undo);
                }
            }
        }
        else if (strcmp(command, "open") == 0)
        {
            if (!*arg)
            {
                puts("Usage: open <filename>");
            }
            else if (undo_save(&ed, &undo))
            {
                if (file_open(&ed, arg))
                {
                    redo_clear(&redo);
                }
                else
                {
                    undo_discard_latest(&undo);
                }
            }
        }
        else if (strcmp(command, "save") == 0)
        {
            const char *name = *arg ? arg : ed.filename;

            if (!*name)
                puts("Usage: save <filename>");
            else
                file_save(&ed, name);
        }
        else if (strcmp(command, "close") == 0)
        {
            if (undo_save(&ed, &undo))
            {
                if (editor_load_text(&ed, ""))
                {
                    ed.filename[0] = '\0';
                    redo_clear(&redo);
                    puts("Document cleared.");
                }
            }
        }
        else if (strcmp(command, "undo") == 0)
        {
            undo_perform(&ed, &undo, &redo);
        }
        else if (strcmp(command, "redo") == 0)
        {
            redo_perform(&ed, &undo, &redo);
        }
        else if (strcmp(command, "exit") == 0 ||
                 strcmp(command, "quit") == 0)
        {
            break;
        }
        else
        {
            printf("Unknown command '%s'. Type 'help'.\n",
                   command);
        }
    }

    editor_destroy(&ed);

    undo_stack_destroy(&undo);
    undo_stack_destroy(&redo);

    puts("Goodbye.");

    return 0;
}
