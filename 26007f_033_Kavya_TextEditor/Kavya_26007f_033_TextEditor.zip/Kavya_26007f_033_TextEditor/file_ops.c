#include "file_ops.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int file_save(TextEditor *ed, const char *filename)
{
    FILE *fp = fopen(filename, "w");

    if (!fp)
    {
        perror("Could not save file");
        return 0;
    }

    for (Line *p = ed->head; p; p = p->next)
    {
        if (fputs(p->text, fp) == EOF ||
            (p->next && fputc('\n', fp) == EOF))
        {
            fclose(fp);
            puts("Error writing file.");
            return 0;
        }
    }

    if (fclose(fp) != 0)
    {
        puts("Error closing file.");
        return 0;
    }

    strncpy(ed->filename, filename, sizeof(ed->filename) - 1);

    ed->filename[sizeof(ed->filename) - 1] = '\0';

    printf("Saved to '%s'.\n", filename);

    return 1;
}

int file_open(TextEditor *ed, const char *filename)
{
    FILE *fp = fopen(filename, "rb");

    if (!fp)
    {
        perror("Could not open file");
        return 0;
    }

    size_t cap = 1024;
    size_t size = 0;

    char *buf = malloc(cap);

    if (!buf)
    {
        fclose(fp);
        return 0;
    }

    int ch;

    while ((ch = fgetc(fp)) != EOF)
    {
        if (size + 2 > cap)
        {
            cap *= 2;

            char *tmp = realloc(buf, cap);

            if (!tmp)
            {
                free(buf);
                fclose(fp);
                return 0;
            }

            buf = tmp;
        }

        /* Ignore carriage returns from Windows line endings. */
        if (ch != '\r')
            buf[size++] = (char)ch;
    }

    if (ferror(fp))
    {
        free(buf);
        fclose(fp);
        return 0;
    }

    fclose(fp);

    buf[size] = '\0';

    int ok = editor_load_text(ed, buf);

    free(buf);

    if (!ok)
    {
        puts("Could not load file.");
        return 0;
    }

    strncpy(ed->filename, filename, sizeof(ed->filename) - 1);

    ed->filename[sizeof(ed->filename) - 1] = '\0';

    printf("Opened '%s'.\n", filename);

    return 1;
}
