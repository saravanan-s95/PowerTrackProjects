#include "text_ops.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CLIPBOARD_SIZE 2048

static char clipboard[CLIPBOARD_SIZE] = "";

int text_insert(TextEditor *ed, const char *text)
{
    size_t old = line_length(ed->cursor);
    size_t add = strlen(text);

    char *s = malloc(old + add + 1);

    if (!s)
        return 0;

    memcpy(s, ed->cursor->text, ed->cursor_col);

    memcpy(s + ed->cursor_col, text, add);

    memcpy(s + ed->cursor_col + add, ed->cursor->text + ed->cursor_col, old - ed->cursor_col + 1);

    free(ed->cursor->text);

    ed->cursor->text = s;
    ed->cursor_col += add;

    return 1;
}

size_t text_delete(TextEditor *ed, size_t count)
{
    size_t len = line_length(ed->cursor);

    if (ed->cursor_col >= len)
        return 0;

    size_t available = len - ed->cursor_col;

    if (count > available)
        count = available;

    memmove(ed->cursor->text + ed->cursor_col, ed->cursor->text + ed->cursor_col + count, len - ed->cursor_col - count + 1);

    return count;
}

int text_newline(TextEditor *ed)
{
    char *right = string_duplicate(ed->cursor->text + ed->cursor_col);

    if (!right)
        return 0;

    Line *n = line_create(right);
    free(right);

    if (!n)
        return 0;

    ed->cursor->text[ed->cursor_col] = '\0';

    n->prev = ed->cursor;
    n->next = ed->cursor->next;

    if (n->next)
        n->next->prev = n;
    else
        ed->tail = n;

    ed->cursor->next = n;
    ed->cursor = n;

    ed->cursor_line++;
    ed->cursor_col = 0;

    return 1;
}

int text_backspace(TextEditor *ed)
{
    if (ed->cursor_col == 0)
        return 0;

    size_t len = line_length(ed->cursor);

    memmove(ed->cursor->text + ed->cursor_col - 1, ed->cursor->text + ed->cursor_col, len - ed->cursor_col + 1);

    ed->cursor_col--;

    return 1;
}

int text_delete_line(TextEditor *ed)
{
    if (ed->head == ed->tail)
    {
        ed->cursor->text[0] = '\0';
        ed->cursor_col = 0;
        return 1;
    }

    Line *v = ed->cursor;

    size_t new_line = v->next ? ed->cursor_line : ed->cursor_line - 1;

    Line *target = v->next ? v->next : v->prev;

    if (v->prev)
        v->prev->next = v->next;
    else
        ed->head = v->next;

    if (v->next)
        v->next->prev = v->prev;
    else
        ed->tail = v->prev;

    free(v->text);
    free(v);

    ed->cursor = target;
    ed->cursor_line = new_line;
    ed->cursor_col = 0;

    return 1;
}

void text_copy(TextEditor *ed, size_t count)
{
    size_t available = line_length(ed->cursor) - ed->cursor_col;

    if (count > available)
        count = available;

    if (count >= CLIPBOARD_SIZE)
        count = CLIPBOARD_SIZE - 1;

    memcpy(clipboard, ed->cursor->text + ed->cursor_col, count);

    clipboard[count] = '\0';

    printf("Copied %zu character(s).\n", count);
}

int text_cut(TextEditor *ed, size_t count)
{
    text_copy(ed, count);

    size_t n = text_delete(ed, count);

    if (n)
        puts("Text cut.");

    return n > 0;
}

int text_paste(TextEditor *ed)
{
    return text_insert(ed, clipboard);
}
