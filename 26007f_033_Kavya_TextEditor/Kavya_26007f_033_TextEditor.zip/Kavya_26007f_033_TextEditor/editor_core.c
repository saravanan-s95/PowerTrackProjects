#include "text_editor.h"
#include <stdlib.h>
#include <string.h>

char *string_duplicate(const char *s)
{
    size_t n = strlen(s) + 1;
    char *copy = malloc(n);

    if (copy)
        memcpy(copy, s, n);

    return copy;
}

Line *line_create(const char *text)
{
    Line *line = malloc(sizeof(*line));

    if (!line)
        return NULL;

    line->text = string_duplicate(text ? text : "");

    if (!line->text)
    {
        free(line);
        return NULL;
    }

    line->prev = NULL;
    line->next = NULL;

    return line;
}

size_t line_length(const Line *line)
{
    if (line && line->text)
        return strlen(line->text);

    return 0;
}

Line *line_at(TextEditor *ed, size_t number)
{
    Line *p = ed->head;
    size_t i = 1;

    while (p && i < number)
    {
        p = p->next;
        i++;
    }

    return p;
}

void editor_init(TextEditor *ed)
{
    memset(ed, 0, sizeof(*ed));

    ed->head = line_create("");
    ed->tail = ed->head;
    ed->cursor = ed->head;
    ed->cursor_line = 1;
    ed->cursor_col = 0;
}

void editor_clear(TextEditor *ed)
{
    Line *p = ed->head;

    while (p)
    {
        Line *next = p->next;

        free(p->text);
        free(p);

        p = next;
    }

    ed->head = NULL;
    ed->tail = NULL;
    ed->cursor = NULL;
}

void editor_destroy(TextEditor *ed)
{
    editor_clear(ed);
}

void editor_set_cursor(TextEditor *ed,
                       size_t line_number,
                       size_t column)
{
    Line *line = line_at(ed, line_number);

    if (!line)
        return;

    ed->cursor = line;
    ed->cursor_line = line_number;

    size_t len = line_length(line);

    ed->cursor_col = (column > len) ? len : column;
}

char *editor_serialize(const TextEditor *ed)
{
    size_t total = 1;

    for (Line *p = ed->head; p; p = p->next)
        total += strlen(p->text) + 1;

    char *result = malloc(total);

    if (!result)
        return NULL;

    size_t used = 0;

    for (Line *p = ed->head; p; p = p->next)
    {
        size_t n = strlen(p->text);

        memcpy(result + used, p->text, n);
        used += n;

        if (p->next)
            result[used++] = '\n';
    }

    result[used] = '\0';

    return result;
}

int editor_load_text(TextEditor *ed, const char *content)
{
    editor_clear(ed);

    const char *start = content;
    const char *p = content;

    for (;;)
    {
        if (*p == '\n' || *p == '\0')
        {
            size_t n = (size_t)(p - start);

            char *piece = malloc(n + 1);

            if (!piece)
                return 0;

            memcpy(piece, start, n);
            piece[n] = '\0';

            Line *node = line_create(piece);
            free(piece);

            if (!node)
                return 0;

            node->prev = ed->tail;

            if (ed->tail)
                ed->tail->next = node;
            else
                ed->head = node;

            ed->tail = node;

            if (*p == '\0')
                break;

            start = p + 1;
        }

        p++;
    }

    ed->cursor = ed->head;
    ed->cursor_line = 1;
    ed->cursor_col = 0;

    return 1;
}
