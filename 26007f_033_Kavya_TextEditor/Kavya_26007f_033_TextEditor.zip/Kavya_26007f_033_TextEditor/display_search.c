#include "display_search.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void display_text(const TextEditor *ed)
{
    size_t n = 1;

    puts("\n-------------- DOCUMENT --------------");

    for(Line *p = ed->head; p; p = p->next, n++)
    {
        printf("%4zu | %s\n", n, p->text);
    }

    puts("--------------------------------------");

    printf("Cursor: line %zu, column %zu\n", ed->cursor_line, ed->cursor_col);
}

void display_find(const TextEditor *ed, const char *needle)
{
    if (!*needle)
    {
        puts("Search text cannot be empty.");
        return;
    }

    size_t line_no = 1;
    size_t matches = 0;

    for (Line *p = ed->head; p; p = p->next, line_no++)
    {
        char *scan = p->text;

        while ((scan = strstr(scan, needle)) != NULL)
        {
            printf("Found at line %zu, column %zu\n", line_no, (size_t)(scan - p->text));
            matches++;
            scan++;
        }
    }

    printf("Search complete: %zu match(es).\n", matches);
}

size_t display_replace(TextEditor *ed, const char *old_text, const char *new_text)
{
    if (!*old_text)
    {
        puts("Old text cannot be empty.");
        return 0;
    }

    if (strcmp(old_text, new_text) == 0)
    {
        puts("Old and new text are identical.");
        return 0;
    }

    size_t count = 0;
    size_t old_len = strlen(old_text);
    size_t new_len = strlen(new_text);

    for (Line *line = ed->head; line; line = line->next)
    {
        char *scan = line->text;

        while ((scan = strstr(scan, old_text)) != NULL)
        {
            size_t prefix = (size_t)(scan - line->text);
            size_t suffix = strlen(scan + old_len);

            char *updated = malloc(prefix + new_len + suffix + 1);

            if (!updated)
            {
                puts("Replace stopped: out of memory.");
                return count;
            }

            memcpy(updated, line->text, prefix);

            memcpy(updated + prefix, new_text, new_len);

            memcpy(updated + prefix + new_len, scan + old_len, suffix + 1);

            free(line->text);
            line->text = updated;

            count++;

            /* Continue after the inserted replacement. */
            scan = line->text + prefix + new_len;
        }
    }

    printf("Replaced %zu occurrence(s).\n", count);

    return count;
}
