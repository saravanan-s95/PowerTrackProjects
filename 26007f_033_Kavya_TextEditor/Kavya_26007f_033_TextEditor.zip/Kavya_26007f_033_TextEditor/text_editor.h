#ifndef TEXT_EDITOR_H
#define TEXT_EDITOR_H

#include <stddef.h>

typedef struct Line
{
    char *text;
    struct Line *prev;
    struct Line *next;
} Line;

typedef struct
{
    Line *head;
    Line *tail;
    Line *cursor;
    size_t cursor_line;
    size_t cursor_col;
    char filename[512];
} TextEditor;

typedef struct
{
    char **items;
    size_t size;
    size_t capacity;
} SnapshotStack;

Line *line_create(const char *text);
char *string_duplicate(const char *s);
size_t line_length(const Line *line);
Line *line_at(TextEditor *ed, size_t number);

void editor_init(TextEditor *ed);
void editor_clear(TextEditor *ed);
void editor_destroy(TextEditor *ed);
void editor_set_cursor(TextEditor *ed, size_t line_number, size_t column);

char *editor_serialize(const TextEditor *ed);
int editor_load_text(TextEditor *ed, const char *content);

#endif
