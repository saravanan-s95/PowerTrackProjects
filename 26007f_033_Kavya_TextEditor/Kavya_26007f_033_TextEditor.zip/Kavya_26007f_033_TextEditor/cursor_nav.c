#include "cursor_nav.h"
#include <stdio.h>

void cursor_left(TextEditor *ed)
{
    if (ed->cursor_col > 0)
    {
        ed->cursor_col--;
    }
    else if (ed->cursor->prev)
    {
        ed->cursor = ed->cursor->prev;
        ed->cursor_line--;
        ed->cursor_col = line_length(ed->cursor);
    }

    printf("Cursor: line %zu, column %zu\n", ed->cursor_line, ed->cursor_col);
}

void cursor_right(TextEditor *ed)
{
    if (ed->cursor_col < line_length(ed->cursor))
    {
        ed->cursor_col++;
    }
    else if (ed->cursor->next)
    {
        ed->cursor = ed->cursor->next;
        ed->cursor_line++;
        ed->cursor_col = 0;
    }

    printf("Cursor: line %zu, column %zu\n", ed->cursor_line, ed->cursor_col);
}

void cursor_up(TextEditor *ed)
{
    if (ed->cursor_line > 1)
    {
        editor_set_cursor(ed, ed->cursor_line - 1, ed->cursor_col);
    }

    printf("Cursor: line %zu, column %zu\n", ed->cursor_line, ed->cursor_col);
}

void cursor_down(TextEditor *ed)
{
    if (ed->cursor->next)
    {
        editor_set_cursor(ed, ed->cursor_line + 1, ed->cursor_col);
    }

    printf("Cursor: line %zu, column %zu\n", ed->cursor_line, ed->cursor_col);
}

void cursor_home(TextEditor *ed)
{
    ed->cursor_col = 0;
}

void cursor_end(TextEditor *ed)
{
    ed->cursor_col = line_length(ed->cursor);
}

void cursor_bottom(TextEditor *ed)
{
    size_t n = 1;

    for(Line *p = ed->head; p && p->next; p = p->next)
        n++;

    editor_set_cursor(ed, n, 0);
}
