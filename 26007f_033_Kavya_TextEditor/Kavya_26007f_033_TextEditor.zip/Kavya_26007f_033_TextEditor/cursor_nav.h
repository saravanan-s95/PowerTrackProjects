#ifndef CURSOR_NAV_H
#define CURSOR_NAV_H

#include "text_editor.h"

void cursor_left(TextEditor *ed);
void cursor_right(TextEditor *ed);
void cursor_up(TextEditor *ed);
void cursor_down(TextEditor *ed);
void cursor_home(TextEditor *ed);
void cursor_end(TextEditor *ed);
void cursor_bottom(TextEditor *ed);

#endif
