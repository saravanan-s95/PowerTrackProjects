#ifndef DISPLAY_SEARCH_H
#define DISPLAY_SEARCH_H

#include "text_editor.h"
#include <stddef.h>

void display_text(const TextEditor *ed);

void display_find(const TextEditor *ed, const char *needle);

size_t display_replace(TextEditor *ed, const char *old_text, const char *new_text);

#endif
