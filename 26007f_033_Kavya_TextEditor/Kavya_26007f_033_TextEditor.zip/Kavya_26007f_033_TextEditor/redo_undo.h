#ifndef REDO_UNDO_H
#define REDO_UNDO_H

#include "text_editor.h"

int undo_save(const TextEditor *ed, SnapshotStack *stack);

void undo_discard_latest(SnapshotStack *stack);

void redo_clear(SnapshotStack *stack);

int undo_perform(TextEditor *ed, SnapshotStack *undo, SnapshotStack *redo);

int redo_perform(TextEditor *ed, SnapshotStack *undo, SnapshotStack *redo);

void undo_stack_destroy(SnapshotStack *stack);

#endif
