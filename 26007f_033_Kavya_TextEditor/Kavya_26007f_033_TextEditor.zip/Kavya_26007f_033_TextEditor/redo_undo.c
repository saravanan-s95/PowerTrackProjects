#include "redo_undo.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int stack_push(SnapshotStack *s, const char *text)
{
    if (s->size == s->capacity)
    {
        size_t cap = s->capacity ? s->capacity * 2 : 8;

        char **tmp = realloc(s->items, cap * sizeof(*tmp));

        if (!tmp)
            return 0;

        s->items = tmp;
        s->capacity = cap;
    }

    s->items[s->size] = string_duplicate(text);

    if (!s->items[s->size])
        return 0;

    s->size++;

    return 1;
}

static char *stack_pop(SnapshotStack *s)
{
    if (!s->size)
        return NULL;

    return s->items[--s->size];
}

int undo_save(const TextEditor *ed, SnapshotStack *stack)
{
    char *snapshot = editor_serialize(ed);

    if (!snapshot)
        return 0;

    int ok = stack_push(stack, snapshot);

    free(snapshot);

    return ok;
}

void undo_discard_latest(SnapshotStack *stack)
{
    if (stack->size)
        free(stack->items[--stack->size]);
}

void redo_clear(SnapshotStack *stack)
{
    while (stack->size)
        free(stack->items[--stack->size]);
}

void undo_stack_destroy(SnapshotStack *stack)
{
    redo_clear(stack);

    free(stack->items);

    stack->items = NULL;
    stack->capacity = 0;
}

static int restore(TextEditor *ed, SnapshotStack *from, SnapshotStack *to, const char *empty_message)
{
    if (!from->size)
    {
        puts(empty_message);
        return 0;
    }

    char *current = editor_serialize(ed);
    char *target = stack_pop(from);

    if (!current || !target || !stack_push(to, current))
    {
        free(current);
        free(target);

        puts("Undo/redo failed: out of memory.");

        return 0;
    }

    int ok = editor_load_text(ed, target);

    free(current);
    free(target);

    return ok;
}

int undo_perform(TextEditor *ed, SnapshotStack *undo, SnapshotStack *redo)
{
    if (restore(ed, undo, redo, "Nothing to undo."))
    {
        puts("Undo successful.");
        return 1;
    }

    return 0;
}

int redo_perform(TextEditor *ed, SnapshotStack *undo, SnapshotStack *redo)
{
    if (restore(ed, redo, undo, "Nothing to redo."))
    {
        puts("Redo successful.");
        return 1;
    }

    return 0;
}
