#include "StegoEngine.h"
#include <iostream>

bool StegoEngine::encode(BmpReader& bmp, const std::string& secretMessage, const std::string& outputFilename)
{
    if (!bmp.isValid())
        return false;

    std::vector<uint8_t>& pixels = bmp.getPixelData();
    std::string messageWithDelimiter = secretMessage + '\0';
    size_t requiredBits = messageWithDelimiter.size() * 8;

    if (pixels.size() < requiredBits)
    {
        std::cerr << "Error: Image is too small to store the message.\n";
        return false;
    }
    size_t pixelIndex = 0;
    for (char ch : messageWithDelimiter)
    {
        for (int i = 0; i < 8; ++i)
        {
            uint8_t bit = (ch >> i) & 1;
            pixels[pixelIndex] = (pixels[pixelIndex] & 0xFE) | bit;
            pixelIndex++;
        }
    }
    return bmp.writeBMP(outputFilename);
}

std::string StegoEngine::decode(BmpReader& bmp)
{
    if (!bmp.isValid())
        return "";

    const std::vector<uint8_t>& pixels = bmp.getPixelData();
    std::string extractedMessage = "";
    char currentByte = 0;
    size_t pixelIndex = 0;

    while (pixelIndex < pixels.size())
    {
        currentByte = 0;
        for (int i = 0; i < 8; ++i)
        {
            if (pixelIndex >= pixels.size())
                break;

            uint8_t bit = pixels[pixelIndex] & 1;
            currentByte |= (bit << i);
            pixelIndex++;
        }
        if (currentByte == '\0')
        {
            break;
        }
        extractedMessage += currentByte;
    }
    return extractedMessage;
}

