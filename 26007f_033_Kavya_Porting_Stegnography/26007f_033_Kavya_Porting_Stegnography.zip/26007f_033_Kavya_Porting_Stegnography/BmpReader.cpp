#include "BmpReader.h"
#include <fstream>
#include <iostream>

BmpReader::BmpReader() : isLoaded(false)
{
}

bool BmpReader::readBMP(const std::string& filename)
{
    std::ifstream file(filename, std::ios::binary);
    if (!file)
    {
        std::cerr << "Error: Could not open input file " << filename << "\n";
        return false;
    }

    file.read(reinterpret_cast<char*>(&header), sizeof(BMPHeader));
    if (header.type != 0x4D42 || header.bitsPerPixel != 24)
    {
        std::cerr << "Error: Invalid format. Must be an uncompressed 24-bit BMP file.\n";
        return false;
    }

    pixelData.resize(header.imageSize ? header.imageSize : (header.size - header.offset));
    file.seekg(header.offset, std::ios::beg);
    file.read(reinterpret_cast<char*>(pixelData.data()), pixelData.size());

    isLoaded = true;
    return true;
}

bool BmpReader::writeBMP(const std::string& filename)
{
    if(!isLoaded)
        return false;

    std::ofstream file(filename, std::ios::binary);
    if(!file)
    {
        std::cerr << "Error: Could not write output file " << filename << "\n";
        return false;
    }
    file.write(reinterpret_cast<const char*>(&header), sizeof(BMPHeader));

    int paddingSize = header.offset - sizeof(BMPHeader);
    if (paddingSize > 0)
    {
        std::vector<char> padding(paddingSize, 0);
        file.write(padding.data(), paddingSize);
    }

    file.write(reinterpret_cast<const char*>(pixelData.data()), pixelData.size());
    return true;
}

std::vector<uint8_t>& BmpReader::getPixelData()
{
    return pixelData;
}
const BMPHeader& BmpReader::getHeader() const
{
    return header;
}
bool BmpReader::isValid() const
{
    return isLoaded;
}
