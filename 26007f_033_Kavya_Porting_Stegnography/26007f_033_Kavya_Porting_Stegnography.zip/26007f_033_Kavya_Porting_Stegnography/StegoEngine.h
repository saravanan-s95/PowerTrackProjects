#ifndef STEGOENGINE_H
#define STEGOENGINE_H

#include "BmpReader.h"
#include <string>

class StegoEngine
{
public:
    static bool encode(BmpReader& bmp, const std::string& secretMessage, const std::string& outputFilename);
    static std::string decode(BmpReader& bmp);
};

#endif
