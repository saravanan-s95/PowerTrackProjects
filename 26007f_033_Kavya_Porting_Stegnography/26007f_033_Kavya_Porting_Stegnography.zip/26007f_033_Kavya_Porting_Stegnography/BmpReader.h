#ifndef BMPREADER_H
#define BMPREADER_H

#include <vector>
#include <string>
#include <cstdint>

#pragma pack(push, 1)

struct BMPHeader {
    uint16_t type;             // Magic identifier: "BM" (0x4D42)
    uint32_t size;             // File size in bytes
    uint16_t reserved1;
    uint16_t reserved2;
    uint32_t offset;           // Offset to image data
    uint32_t dibHeaderSize;    // Size of DIB header
    int32_t  width;            // Width of image
    int32_t  height;           // Height of image
    uint16_t planes;           // Number of color planes
    uint16_t bitsPerPixel;     // Bits per pixel (must be 24 for this setup)
    uint32_t compression;      // Compression type (0 = uncompressed)
    uint32_t imageSize;        // Size of raw bitmap data
    int32_t  xPixelsPerMeter;
    int32_t  yPixelsPerMeter;
    uint32_t colorsInPalette;
    uint32_t importantColors;
};
#pragma pack(pop)

class BmpReader
{
private:
    BMPHeader header;
    std::vector<uint8_t> pixelData;
    bool isLoaded;

public:
    BmpReader();
    bool readBMP(const std::string& filename);
    bool writeBMP(const std::string& filename);

    std::vector<uint8_t>& getPixelData();
    const BMPHeader& getHeader() const;
    bool isValid() const;
};

#endif
