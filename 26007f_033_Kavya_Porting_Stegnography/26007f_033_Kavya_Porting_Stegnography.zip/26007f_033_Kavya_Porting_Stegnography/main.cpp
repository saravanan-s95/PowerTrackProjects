#include <iostream>
#include <string>
#include "BmpReader.h"
#include "StegoEngine.h"

int main()
{
    bool running = true;

    while (running)
    {
        std::cout << "\n--- C++ Image Steganography Tool ---\n";
        std::cout << "1. Encode Message inside Image\n";
        std::cout << "2. Decode Message from Image\n";
        std::cout << "3. Exit Program\n";
        std::cout << "Choose an option: ";

        int choice;
        std::cin >> choice;
        std::cin.ignore();

        if (choice == 1)
        {
            std::string inputImg, outputImg, message;
            std::cout << "Enter source BMP image path: ";
            std::getline(std::cin, inputImg);
            std::cout << "Enter secret message to hide: ";
            std::getline(std::cin, message);
            std::cout << "Enter output destination BMP path: ";
            std::getline(std::cin, outputImg);

            BmpReader image;
            if (image.readBMP(inputImg))
            {
                if (StegoEngine::encode(image, message, outputImg))
                {
                    std::cout << "Success! Message securely embedded in " << outputImg << "\n";
                }
            }
        }
        else if (choice == 2)
        {
            std::string inputImg;
            std::cout << "Enter stego BMP image path to extract from: ";
            std::getline(std::cin, inputImg);

            BmpReader image;
            if (image.readBMP(inputImg))
            {
                std::string message = StegoEngine::decode(image);
                std::cout << "Extracted Message:\n[ " << message << " ]\n";
            }
        }
        else if (choice == 3)
        {
            std::cout << "Exiting program. Goodbye!\n";
            running = false;
        }
        else
        {
            std::cout << "Invalid selection. Please try again.\n";
        }
    }
    return 0;
}
