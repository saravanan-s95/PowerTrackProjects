#include <stdio.h>
#include <stdlib.h>
#include "rbt.h"

/* NULL nodes are treated as black */
int is_red(tree_t *node)
{
    return node != NULL && node->color == RED;
}

/* Search for a node */
tree_t *find_node(tree_t *root, data_t item)
{
    while (root != NULL)
    {
        if (item == root->data)
            return root;

        if (item < root->data)
            root = root->left;
        else
            root = root->right;
    }

    return NULL;
}

/* Find minimum node */
tree_t *minimum_node(tree_t *root)
{
    if (root == NULL)
        return NULL;

    while (root->left != NULL)
        root = root->left;

    return root;
}

/* Find maximum node */
tree_t *maximum_node(tree_t *root)
{
    if (root == NULL)
        return NULL;

    while (root->right != NULL)
        root = root->right;

    return root;
}

/* Left rotation */
void left_rotate(tree_t **root, tree_t *x)
{
    tree_t *y = x->right;

    if (y == NULL)
        return;

    x->right = y->left;

    if (y->left != NULL)
        y->left->parent = x;

    y->parent = x->parent;

    if (x->parent == NULL)
        *root = y;
    else if (x == x->parent->left)
        x->parent->left = y;
    else
        x->parent->right = y;

    y->left = x;
    x->parent = y;
}

/* Right rotation */
void right_rotate(tree_t **root, tree_t *y)
{
    tree_t *x = y->left;

    if (x == NULL)
        return;

    y->left = x->right;

    if (x->right != NULL)
        x->right->parent = y;

    x->parent = y->parent;

    if (y->parent == NULL)
        *root = x;
    else if (y == y->parent->left)
        y->parent->left = x;
    else
        y->parent->right = x;

    x->right = y;
    y->parent = x;
}

/* Restore red-black properties after insertion */
void insert_fixup(tree_t **root, tree_t *z)
{
    while (z->parent != NULL &&
           z->parent->color == RED)
    {
        tree_t *p = z->parent;
        tree_t *g = p->parent;

        if (p == g->left)
        {
            tree_t *u = g->right;

            /* Case 1: uncle is red */
            if (is_red(u))
            {
                p->color = BLACK;
                u->color = BLACK;
                g->color = RED;
                z = g;
            }
            else
            {
                /* Case 2: triangle */
                if (z == p->right)
                {
                    z = p;
                    left_rotate(root, z);
                    p = z->parent;
                    g = p->parent;
                }

                /* Case 3: line */
                p->color = BLACK;
                g->color = RED;
                right_rotate(root, g);
            }
        }
        else
        {
            tree_t *u = g->left;

            /* Mirror case 1 */
            if (is_red(u))
            {
                p->color = BLACK;
                u->color = BLACK;
                g->color = RED;
                z = g;
            }
            else
            {
                /* Mirror case 2 */
                if (z == p->left)
                {
                    z = p;
                    right_rotate(root, z);
                    p = z->parent;
                    g = p->parent;
                }

                /* Mirror case 3 */
                p->color = BLACK;
                g->color = RED;
                left_rotate(root, g);
            }
        }
    }

    if (*root != NULL)
        (*root)->color = BLACK;
}

/* Replace subtree u with subtree v */
void transplant(tree_t **root, tree_t *u, tree_t *v)
{
    if (u->parent == NULL)
        *root = v;
    else if (u == u->parent->left)
        u->parent->left = v;
    else
        u->parent->right = v;

    if (v != NULL)
        v->parent = u->parent;
}

/* Restore red-black properties after deletion.
   parent is passed separately when x is NULL. */
void delete_fixup(tree_t **root, tree_t *x, tree_t *parent)
{
    while (x != *root && !is_red(x))
    {
        if (parent == NULL)
            break;

        if (x == parent->left)
        {
            tree_t *w = parent->right;

            /* Case 1: sibling is red */
            if (is_red(w))
            {
                w->color = BLACK;
                parent->color = RED;

                left_rotate(root, parent);
                w = parent->right;
            }

            if (w == NULL)
            {
                x = parent;
                parent = x->parent;
                continue;
            }

            /* Case 2: both sibling children are black */
            if (!is_red(w->left) && !is_red(w->right))
            {
                w->color = RED;
                x = parent;
                parent = x->parent;
            }
            else
            {
                /* Case 3: far child is black */
                if (!is_red(w->right))
                {
                    if (w->left != NULL)
                        w->left->color = BLACK;

                    w->color = RED;
                    right_rotate(root, w);
                    w = parent->right;
                }

                /* Case 4: far child is red */
                w->color = parent->color;
                parent->color = BLACK;

                if (w->right != NULL)
                    w->right->color = BLACK;

                left_rotate(root, parent);

                x = *root;
                parent = NULL;
            }
        }
        else
        {
            /* Mirror cases: sibling is on the left */
            tree_t *w = parent->left;

            if (is_red(w))
            {
                w->color = BLACK;
                parent->color = RED;

                right_rotate(root, parent);
                w = parent->left;
            }

            if (w == NULL)
            {
                x = parent;
                parent = x->parent;
                continue;
            }

            if (!is_red(w->right) && !is_red(w->left))
            {
                w->color = RED;
                x = parent;
                parent = x->parent;
            }
            else
            {
                if (!is_red(w->left))
                {
                    if (w->right != NULL)
                        w->right->color = BLACK;

                    w->color = RED;
                    left_rotate(root, w);
                    w = parent->left;
                }

                w->color = parent->color;
                parent->color = BLACK;

                if (w->left != NULL)
                    w->left->color = BLACK;

                right_rotate(root, parent);

                x = *root;
                parent = NULL;
            }
        }
    }

    if (x != NULL)
        x->color = BLACK;

    if (*root != NULL)
        (*root)->color = BLACK;
}

/* Display elements in sorted order with their colors */
void inorder(tree_t *root)
{
    if (root == NULL)
        return;

    inorder(root->left);

    printf("%d(%c) ", root->data, root->color == RED ? 'R' : 'B');

    inorder(root->right);
}

/* Free all allocated nodes */
void destroy_tree(tree_t *root)
{
    if (root == NULL)
        return;

    destroy_tree(root->left);
    destroy_tree(root->right);

    free(root);
}

