#include <stdlib.h>
#include "rbt.h"

int find_minimum(tree_t **root, data_t *min)
{
    if (root == NULL || *root == NULL || min == NULL)
        return FAILURE;

    tree_t *node = minimum_node(*root);

    *min = node->data;

    return SUCCESS;
}

