#include <stdlib.h>
#include "rbt.h"

int search(tree_t **root, data_t item)
{
    if (root == NULL || *root == NULL)
        return FAILURE;

    if (find_node(*root, item) != NULL)
        return SUCCESS;

    return FAILURE;
}

