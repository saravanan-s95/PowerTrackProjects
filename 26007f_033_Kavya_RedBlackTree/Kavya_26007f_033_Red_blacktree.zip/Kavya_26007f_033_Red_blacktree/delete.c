#include <stdlib.h>
#include "rbt.h"

int delete(tree_t **root, data_t item)
{
    if (root == NULL || *root == NULL)
        return FAILURE;

    tree_t *z = find_node(*root, item);

    if (z == NULL)
        return FAILURE;

    tree_t *y = z;
    tree_t *x = NULL;
    tree_t *x_parent = NULL;

    color_t original_color = y->color;

    if (z->left == NULL)
    {
        x = z->right;
        x_parent = z->parent;

        transplant(root, z, z->right);

        if (x != NULL)
            x_parent = x->parent;
    }
    else if (z->right == NULL)
    {
        x = z->left;
        x_parent = z->parent;

        transplant(root, z, z->left);

        if (x != NULL)
            x_parent = x->parent;
    }
    else
    {
        // Use the inorder successor
        y = minimum_node(z->right);
        original_color = y->color;
        x = y->right;

        if (y->parent == z)
        {
            x_parent = y;

            if (x != NULL)
                x->parent = y;
        }
        else
        {
            x_parent = y->parent;

            transplant(root, y, y->right);

            y->right = z->right;
            y->right->parent = y;
        }

        transplant(root, z, y);

        y->left = z->left;
        y->left->parent = y;
        y->color = z->color;
    }

    free(z);

    if (original_color == BLACK)
    {
        delete_fixup(root, x, x != NULL ? x->parent : x_parent);
    }

    return SUCCESS;
}

