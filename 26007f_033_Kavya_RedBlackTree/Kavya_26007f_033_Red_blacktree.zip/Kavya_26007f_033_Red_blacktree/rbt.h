#ifndef RBT_H
#define RBT_H

typedef int data_t;

#define SUCCESS 0
#define FAILURE 1

typedef enum
{
    RED,
    BLACK
} color_t;

typedef struct node
{
    data_t data;
    color_t color;
    struct node *left;
    struct node *right;
    struct node *parent;
} tree_t;

/* Main operations */
int insert(tree_t **root, data_t item);
int delete(tree_t **root, data_t item);
int search(tree_t **root, data_t item);

int find_minimum(tree_t **root, data_t *min);
int find_maximum(tree_t **root, data_t *max);

int delete_minimum(tree_t **root);
int delete_maximum(tree_t **root);

/* Shared helper functions */
tree_t *find_node(tree_t *root, data_t item);
tree_t *minimum_node(tree_t *root);
tree_t *maximum_node(tree_t *root);

int is_red(tree_t *node);

void left_rotate(tree_t **root, tree_t *node);
void right_rotate(tree_t **root, tree_t *node);

void insert_fixup(tree_t **root, tree_t *node);
void delete_fixup(tree_t **root, tree_t *node, tree_t *parent);

void transplant(tree_t **root, tree_t *u, tree_t *v);

void inorder(tree_t *root);
void destroy_tree(tree_t *root);

#endif
