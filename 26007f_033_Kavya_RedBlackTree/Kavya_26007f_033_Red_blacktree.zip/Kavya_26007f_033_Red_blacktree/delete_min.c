#include <stdlib.h>
#include "rbt.h"

int delete_minimum(tree_t **root)
{
    if (root == NULL || *root == NULL)
        return FAILURE;

    tree_t *node = minimum_node(*root);

    return delete(root, node->data);
}

