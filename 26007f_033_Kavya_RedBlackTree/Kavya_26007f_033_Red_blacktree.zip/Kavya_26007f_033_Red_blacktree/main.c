/*  Name: Kavya.M
    Date: 16.10.2026
    Description : A red�black tree is a kind of self-balancing binary search tree. Each node of the binary tree
    has an extra bit, and that bit is often interpreted as the color (red or black) of the node. These
    color bits are used to ensure the tree remains approximately balanced during insertions and
    deletions.

    Operations to be Implemented:
    1. Insertion
    2. Deletion
    3. Search
    4. Find Min
    5. Delete Min
    6. Find Max
    7. Delete Max
*/


#include <stdio.h>
#include <stdlib.h>
#include "rbt.h"

int main(void)
{
    tree_t *root = NULL;
    int choice, item, value;

    do
    {
        printf("\n--- RED BLACK TREE ---\n");
        printf("1. Insert\n");
        printf("2. Delete\n");
        printf("3. Search\n");
        printf("4. Find Minimum\n");
        printf("5. Delete Minimum\n");
        printf("6. Find Maximum\n");
        printf("7. Delete Maximum\n");
        printf("8. Display Inorder\n");
        printf("0. Exit\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1)
        {
            destroy_tree(root);
            return 0;
        }

        switch (choice)
        {
            case 1:
                printf("Enter item: ");
                if (scanf("%d", &item) != 1)
                    break;

                if (insert(&root, item) == SUCCESS)
                    printf("Inserted successfully\n");
                else
                    printf("Insertion failed\n");
                break;

            case 2:
                printf("Enter item: ");
                if (scanf("%d", &item) != 1)
                    break;

                if (delete(&root, item) == SUCCESS)
                    printf("Deleted successfully\n");
                else
                    printf("Item not found\n");
                break;

            case 3:
                printf("Enter item: ");
                if (scanf("%d", &item) != 1)
                    break;

                if (search(&root, item) == SUCCESS)
                    printf("Item found\n");
                else
                    printf("Item not found\n");
                break;

            case 4:
                if (find_minimum(&root, &value) == SUCCESS)
                    printf("Minimum = %d\n", value);
                else
                    printf("Tree is empty\n");
                break;

            case 5:
                if (delete_minimum(&root) == SUCCESS)
                    printf("Minimum deleted\n");
                else
                    printf("Tree is empty\n");
                break;

            case 6:
                if (find_maximum(&root, &value) == SUCCESS)
                    printf("Maximum = %d\n", value);
                else
                    printf("Tree is empty\n");
                break;

            case 7:
                if (delete_maximum(&root) == SUCCESS)
                    printf("Maximum deleted\n");
                else
                    printf("Tree is empty\n");
                break;

            case 8:
                if (root == NULL)
                    printf("Tree is empty\n");
                else
                {
                    inorder(root);
                    printf("\n");
                }
                break;

            case 0:
                break;

            default:
                printf("Invalid choice\n");
        }

    } while (choice != 0);

    destroy_tree(root);
    return 0;
}

