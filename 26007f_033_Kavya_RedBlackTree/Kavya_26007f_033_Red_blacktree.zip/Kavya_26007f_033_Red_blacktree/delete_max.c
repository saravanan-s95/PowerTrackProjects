#include <stdlib.h>
#include "rbt.h"

int delete_maximum(tree_t **root)
{
    if (root == NULL || *root == NULL)
        return FAILURE;

    tree_t *node = maximum_node(*root);

    return delete(root, node->data);
}

