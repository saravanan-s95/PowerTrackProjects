
#include <stdlib.h>
#include <stdlib.h>
#include "rbt.h"

int insert(tree_t **root, data_t item)
{
    if (root == NULL)
        return FAILURE;

    tree_t *parent = NULL;
    tree_t *current = *root;

    /* Find the correct insertion position */
    while (current != NULL)
    {
        parent = current;

        if (item == current->data)
            return FAILURE;  /* Duplicate not allowed */

        if (item < current->data)
            current = current->left;
        else
            current = current->right;
    }

    tree_t *node = malloc(sizeof(tree_t));

    if (node == NULL)
        return FAILURE;

    node->data = item;
    node->color = RED;
    node->left = NULL;
    node->right = NULL;
    node->parent = parent;

    if (parent == NULL)
        *root = node;
    else if (item < parent->data)
        parent->left = node;
    else
        parent->right = node;

    insert_fixup(root, node);

    return SUCCESS;
}

