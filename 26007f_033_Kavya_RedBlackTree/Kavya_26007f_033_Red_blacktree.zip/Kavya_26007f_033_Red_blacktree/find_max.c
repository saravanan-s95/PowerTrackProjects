#include <stdlib.h>
#include "rbt.h"

int find_maximum(tree_t **root, data_t *max)
{
    if (root == NULL || *root == NULL || max == NULL)
        return FAILURE;

    tree_t *node = maximum_node(*root);

    *max = node->data;

    return SUCCESS;
}

