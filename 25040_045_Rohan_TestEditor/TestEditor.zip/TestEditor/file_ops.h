#ifndef FILE_OPS_H
#define FILE_OPS_H

#include "text_editor.h"

int file_exists(const char *filename);
int load_from_file(const char *filename, TextEditor *editor);
int save_into_file(const char *filename, TextEditor *editor);
int append_into_file(const char *filename, TextEditor *editor);

#endif
