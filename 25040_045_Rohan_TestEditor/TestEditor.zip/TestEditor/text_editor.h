#ifndef TEXT_EDITOR_H
#define TEXT_EDITOR_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE_LENGTH 256
#define MAX_ACTION_TEXT 256
#define MAX_STACK_SIZE 100

typedef struct Node
{
    char line[MAX_LINE_LENGTH];
    struct Node *prev;
    struct Node *next;
} Node;

typedef struct
{
    Node *head;
    Node *tail;
    Node *cursor;
    int cursorLine;
    int cursorPos;
} TextEditor;

typedef struct
{
    char operation[20];
    char text[MAX_ACTION_TEXT];
    int cursorLine;
    int cursorPos;
} Action;

typedef struct
{
    Action *actions;
    int size;
    int capacity;
} DynamicArrayStack;

#endif
