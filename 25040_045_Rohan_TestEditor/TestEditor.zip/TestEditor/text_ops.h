#ifndef TEXT_OPS_H
#define TEXT_OPS_H

#include "text_editor.h"

void insertText(TextEditor *editor, char *text, DynamicArrayStack *undoStack, int flag);
void deleteCharacters(TextEditor *editor, int length, DynamicArrayStack *undoStack, int flag);
void deleteLine(TextEditor *editor, DynamicArrayStack *undoStack, int flag);
void undo(TextEditor *editor, DynamicArrayStack *undoStack, DynamicArrayStack *redoStack);
void redo(TextEditor *editor, DynamicArrayStack *redoStack);
void displayText(TextEditor *editor);

#endif
