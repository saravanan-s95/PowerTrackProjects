#include "text_ops.h"

 int pushStack(DynamicArrayStack *stack, const char *operation,const char *text, int cursorLine, int cursorPos)
{
    Action *newActions;

    if (stack == NULL || operation == NULL || text == NULL)
        return 0;

    if (stack->size + 1 >= stack->capacity)
    {
        int newCapacity = (stack->capacity > 0) ? stack->capacity * 2 : MAX_STACK_SIZE;

        newActions = realloc(stack->actions, newCapacity * sizeof(Action));
        if (newActions == NULL)
            return 0;

        stack->actions = newActions;
        stack->capacity = newCapacity;
    }

    stack->size++;

    strncpy(stack->actions[stack->size].operation, operation,
            sizeof(stack->actions[stack->size].operation) - 1);
    stack->actions[stack->size].operation[
        sizeof(stack->actions[stack->size].operation) - 1] = '\0';

    strncpy(stack->actions[stack->size].text, text,
            sizeof(stack->actions[stack->size].text) - 1);
    stack->actions[stack->size].text[
        sizeof(stack->actions[stack->size].text) - 1] = '\0';

    stack->actions[stack->size].cursorLine = cursorLine;
    stack->actions[stack->size].cursorPos = cursorPos;

    return 1;
}

 Action popStack(DynamicArrayStack *stack)
{
    Action action;

    memset(&action, 0, sizeof(action));

    if (stack == NULL || stack->size < 0)
        return action;

    action = stack->actions[stack->size];
    stack->size--;

    return action;
}

 Node *createNode(const char *text)
{
    Node *node = malloc(sizeof(Node));

    if (node == NULL)
        return NULL;

    node->prev = NULL;
    node->next = NULL;
    node->line[0] = '\0';

    if (text != NULL)
        strncpy(node->line, text, MAX_LINE_LENGTH - 1);

    node->line[MAX_LINE_LENGTH - 1] = '\0';

    return node;
}

 void appendText(Node *node, const char *text)
{
    size_t current;
    size_t available;

    if (node == NULL || text == NULL)
        return;

    current = strlen(node->line);

    if (current >= MAX_LINE_LENGTH - 1)
        return;

    available = MAX_LINE_LENGTH - 1 - current;
    strncat(node->line, text, available);
}

 int removeLastCharacters(TextEditor *editor, int length, char *removed)
{
    size_t lineLength;
    int actual;

    if (editor == NULL || editor->tail == NULL || length <= 0)
        return 0;

    lineLength = strlen(editor->tail->line);

    if (lineLength == 0)
        return 0;

    actual = length;

    if ((size_t)actual > lineLength)
        actual = (int)lineLength;

    if (actual >= MAX_ACTION_TEXT)
        actual = MAX_ACTION_TEXT - 1;

    memcpy(removed, editor->tail->line + lineLength - actual, actual);
    removed[actual] = '\0';

    editor->tail->line[lineLength - actual] = '\0';
    editor->cursor = editor->tail;
    editor->cursorPos = (int)strlen(editor->tail->line);

    return actual;
}

void insertText(TextEditor *editor, char *text,DynamicArrayStack *undoStack, int flag)
{
    Node *node;

    if (editor == NULL)
        return;

    if (text == NULL)
    {
        node = createNode("");

        if (node == NULL)
            return;

        if (editor->tail == NULL)
        {
            editor->head = node;
            editor->tail = node;
            editor->cursor = node;
            editor->cursorLine = 1;
        }
        else
        {
            node->prev = editor->tail;
            editor->tail->next = node;
            editor->tail = node;
            editor->cursor = node;
            editor->cursorLine++;
        }

        editor->cursorPos = 0;

        if (flag)
            pushStack(undoStack, "insert_line", "\n",
                      editor->cursorLine, editor->cursorPos);

        printf("Line Add Successfully\n");
        return;
    }

    if (editor->tail == NULL)
    {
        node = createNode(text);

        if (node == NULL)
            return;

        editor->head = node;
        editor->tail = node;
        editor->cursor = node;
        editor->cursorLine = 1;
        editor->cursorPos = (int)strlen(node->line);
    }
    else
    {
        int oldPos = editor->cursorPos;

        if (oldPos > 0 && editor->tail->line[oldPos - 1] != ' ')
            appendText(editor->tail, " ");

        appendText(editor->tail, text);

        editor->cursor = editor->tail;
        editor->cursorPos = (int)strlen(editor->tail->line);
    }

    if (flag)
    {
        pushStack(undoStack, "insert", text,
                  editor->cursorLine,
                  editor->cursorPos - (int)strlen(text));
    }

    printf("Text Add Successfully\n");
}

void deleteCharacters(TextEditor *editor, int length,DynamicArrayStack *undoStack, int flag)
{
    char removed[MAX_ACTION_TEXT];
    int actual;
    int oldLine;
    int oldPos;

    if (editor == NULL || editor->tail == NULL)
    {
        printf("No data for delete\n");
        return;
    }

    oldLine = editor->cursorLine;
    oldPos = editor->cursorPos;

    actual = removeLastCharacters(editor, length, removed);

    if (actual == 0)
    {
        printf("No data for delete\n");
        return;
    }

    if (flag)
        pushStack(undoStack, "delete", removed, oldLine, oldPos);

    printf("Characters Deleted Successfully\n");
}

void deleteLine(TextEditor *editor, DynamicArrayStack *undoStack, int flag)
{
    Node *temp;
    char saved[MAX_ACTION_TEXT];

    if (editor == NULL || editor->tail == NULL)
    {
        printf("No data for delete\n");
        return;
    }

    temp = editor->tail;

    strncpy(saved, temp->line, MAX_ACTION_TEXT - 1);
    saved[MAX_ACTION_TEXT - 1] = '\0';

    if (flag)
        pushStack(undoStack, "delete_line", saved,
                  editor->cursorLine, editor->cursorPos);

    editor->tail = temp->prev;

    if (editor->tail != NULL)
    {
        editor->tail->next = NULL;
        editor->cursor = editor->tail;
        editor->cursorLine--;
        editor->cursorPos = (int)strlen(editor->tail->line);
    }
    else
    {
        editor->head = NULL;
        editor->cursor = NULL;
        editor->cursorLine = 0;
        editor->cursorPos = 0;
    }

    free(temp);

    printf("Line Deleted Successfully\n");
}

void undo(TextEditor *editor, DynamicArrayStack *undoStack,DynamicArrayStack *redoStack)
{
    Action action;

    if (undoStack == NULL || undoStack->size < 0)
    {
        printf("No Undo Steps\n");
        return;
    }

    action = popStack(undoStack);

    if (strcmp(action.operation, "insert") == 0)
    {
        if (editor->tail != NULL)
        {
            size_t len = strlen(editor->tail->line);
            size_t removeLen = strlen(action.text);

            if (removeLen <= len)
                editor->tail->line[len - removeLen] = '\0';

            editor->cursor = editor->tail;
            editor->cursorLine = action.cursorLine;
            editor->cursorPos = (int)strlen(editor->tail->line);
        }

        pushStack(redoStack, "insert", action.text,
                  action.cursorLine, action.cursorPos);
    }
    else if (strcmp(action.operation, "insert_line") == 0)
    {
        if (editor->tail != NULL)
        {
            Node *temp = editor->tail;

            editor->tail = temp->prev;

            if (editor->tail != NULL)
            {
                editor->tail->next = NULL;
                editor->cursor = editor->tail;
                editor->cursorLine--;
                editor->cursorPos = (int)strlen(editor->tail->line);
            }
            else
            {
                editor->head = NULL;
                editor->cursor = NULL;
                editor->cursorLine = 0;
                editor->cursorPos = 0;
            }

            free(temp);
        }

        pushStack(redoStack, "insert_line", "\n",
                  action.cursorLine, action.cursorPos);
    }
    else if (strcmp(action.operation, "delete") == 0)
    {
        if (editor->tail != NULL)
        {
            appendText(editor->tail, action.text);
            editor->cursor = editor->tail;
            editor->cursorLine = action.cursorLine;
            editor->cursorPos = (int)strlen(editor->tail->line);
        }

        pushStack(redoStack, "delete", action.text,
                  action.cursorLine, action.cursorPos);
    }
    else if (strcmp(action.operation, "delete_line") == 0)
    {
        insertText(editor, NULL, NULL, 0);

        if (editor->tail != NULL)
        {
            strncpy(editor->tail->line, action.text, MAX_LINE_LENGTH - 1);
            editor->tail->line[MAX_LINE_LENGTH - 1] = '\0';
            editor->cursor = editor->tail;
            editor->cursorLine = action.cursorLine;
            editor->cursorPos = (int)strlen(editor->tail->line);
        }

        pushStack(redoStack, "delete_line", action.text,
                  action.cursorLine, action.cursorPos);
    }
}

void redo(TextEditor *editor, DynamicArrayStack *redoStack)
{
    Action action;

    if (redoStack == NULL || redoStack->size < 0)
    {
        printf("No Redo Steps\n");
        return;
    }

    action = popStack(redoStack);

    if (strcmp(action.operation, "insert") == 0)
        insertText(editor, action.text, NULL, 0);
    else if (strcmp(action.operation, "insert_line") == 0)
        insertText(editor, NULL, NULL, 0);
    else if (strcmp(action.operation, "delete") == 0)
        deleteCharacters(editor, (int)strlen(action.text), NULL, 0);
    else if (strcmp(action.operation, "delete_line") == 0)
        deleteLine(editor, NULL, 0);
}

void displayText(TextEditor *editor)
{
    Node *temp;

    if (editor == NULL || editor->head == NULL)
    {
        printf("No text to print\n");
        return;
    }

    temp = editor->head;

    while (temp != NULL)
    {
        printf("%s\n", temp->line);
        temp = temp->next;
    }

    printf("CursorLine: %d\tCursorPos: %d\n",
           editor->cursorLine, editor->cursorPos);
}
