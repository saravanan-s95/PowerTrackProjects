#include "file_ops.h"

static void clearEditor(TextEditor *editor)
{
    Node *temp;

    if (editor == NULL)
        return;

    while (editor->head != NULL)
    {
        temp = editor->head;
        editor->head = editor->head->next;
        free(temp);
    }

    editor->tail = NULL;
    editor->cursor = NULL;
    editor->cursorLine = 0;
    editor->cursorPos = 0;
}

static Node *createLoadedNode(const char *line)
{
    Node *node = malloc(sizeof(Node));

    if (node == NULL)
        return NULL;

    node->prev = NULL;
    node->next = NULL;

    strncpy(node->line, line, MAX_LINE_LENGTH - 1);
    node->line[MAX_LINE_LENGTH - 1] = '\0';

    return node;
}

int file_exists(const char *filename)
{
    FILE *fp;

    if (filename == NULL)
        return 0;

    fp = fopen(filename, "r");
    if (fp == NULL)
        return 0;

    fclose(fp);
    return 1;
}

int load_from_file(const char *filename, TextEditor *editor)
{
    FILE *fp;
    char line[MAX_LINE_LENGTH];

    if (filename == NULL || editor == NULL)
        return -1;

    fp = fopen(filename, "r");
    if (fp == NULL)
    {
        perror("fopen");
        return -1;
    }

    clearEditor(editor);

    while (fgets(line, sizeof(line), fp) != NULL)
    {
        Node *node;
        size_t len = strlen(line);

        if (len > 0 && line[len - 1] == '\n')
            line[len - 1] = '\0';

        if (len > 1 && line[len - 2] == '\r')
            line[len - 2] = '\0';

        node = createLoadedNode(line);
        if (node == NULL)
        {
            fclose(fp);
            clearEditor(editor);
            return -1;
        }

        if (editor->head == NULL)
        {
            editor->head = node;
            editor->tail = node;
        }
        else
        {
            node->prev = editor->tail;
            editor->tail->next = node;
            editor->tail = node;
        }

        editor->cursorLine++;
    }

    fclose(fp);

    editor->cursor = editor->tail;

    if (editor->cursor != NULL)
        editor->cursorPos = (int)strlen(editor->cursor->line);
    else
        editor->cursorLine = 0;

    return 0;
}

int save_into_file(const char *filename, TextEditor *editor)
{
    FILE *fp;
    Node *temp;

    if (filename == NULL || editor == NULL)
        return -1;

    fp = fopen(filename, "w");
    if (fp == NULL)
    {
        perror("fopen");
        return -1;
    }

    temp = editor->head;

    while (temp != NULL)
    {
        fprintf(fp, "%s", temp->line);

        if (temp->next != NULL)
            fputc('\n', fp);

        temp = temp->next;
    }

    fclose(fp);
    return 0;
}

int append_into_file(const char *filename, TextEditor *editor)
{
    FILE *fp;
    Node *temp;
    long size;

    if (filename == NULL || editor == NULL)
        return -1;

    fp = fopen(filename, "a+");
    if (fp == NULL)
    {
        perror("fopen");
        return -1;
    }

    fseek(fp, 0, SEEK_END);
    size = ftell(fp);

    if (size > 0 && editor->head != NULL)
        fputc('\n', fp);

    temp = editor->head;

    while (temp != NULL)
    {
        fprintf(fp, "%s", temp->line);

        if (temp->next != NULL)
            fputc('\n', fp);

        temp = temp->next;
    }

    fclose(fp);
    return 0;
}
