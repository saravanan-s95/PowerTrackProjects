#include "text_ops.h"
#include "file_ops.h"
void initStack(DynamicArrayStack *stack)
{
    stack->capacity = MAX_STACK_SIZE;
    stack->size = -1;
    stack->actions = malloc(stack->capacity * sizeof(Action));

    if (stack->actions == NULL)
    {
        fprintf(stderr, "Memory allocation failed\n");
        exit(EXIT_FAILURE);
    }
}
void freeEditor(TextEditor *editor)
{
    Node *temp;

    while (editor->head != NULL)
    {
        temp = editor->head;
        editor->head = editor->head->next;
        free(temp);
    }

    editor->tail = NULL;
    editor->cursor = NULL;
    editor->cursorLine = 0;
    editor->cursorPos = 0;
}
void freeStack(DynamicArrayStack *stack)
{
    free(stack->actions);
    stack->actions = NULL;
    stack->size = -1;
    stack->capacity = 0;
}
 void clearRedo(DynamicArrayStack *redoStack)
{
    if (redoStack != NULL)
        redoStack->size = -1;
}
 void printMenu(void)
{
    printf("\n=================== Text Editor Commands ===================\n");
    printf("insert <text>      - Insert text\n");
    printf("insert             - Create a new line\n");
    printf("delete <number>    - Delete characters\n");
    printf("delete             - Delete the last line\n");
    printf("undo               - Undo the last operation\n");
    printf("redo               - Redo the last undone operation\n");
    printf("print              - Display current text\n");
    printf("save               - Save text to file\n");
    printf("saveas             - Save using a new file name\n");
    printf("exit               - Exit the text editor\n");
    printf("=============================================================\n");
}
 int askSaveMode()
{
    char choice[20];

    printf("\nFile already exists.\n");
    printf("1. Overwrite existing file\n");
    printf("2. Append current editor text to file\n");
    printf("Enter choice: ");

    if (fgets(choice, sizeof(choice), stdin) == NULL)
        return 0;

    if (choice[0] == '1')
        return 1;

    if (choice[0] == '2')
        return 2;

    printf("Invalid choice\n");
    return 0;
}
 int saveWithMode(TextEditor *editor, const char *filename)
{
    int mode;

    if (filename == NULL || filename[0] == '\0')
        return -1;

    if (file_exists(filename))
    {
        mode = askSaveMode();

        if (mode == 1)
            return save_into_file(filename, editor);

        if (mode == 2)
            return append_into_file(filename, editor);

        return -1;
    }

    return save_into_file(filename, editor);
}
 void saveWithPrompt(TextEditor *editor, const char *currentFile)
{
    char filename[256];

    if (currentFile != NULL)
    {
        if (saveWithMode(editor, currentFile) == 0)
            printf("File saved successfully: %s\n", currentFile);
        else
            printf("File save cancelled/failed\n");

        return;
    }

    printf("Give the file name: ");

    if (fgets(filename, sizeof(filename), stdin) == NULL)
        return;

    filename[strcspn(filename, "\n")] = '\0';

    if (filename[0] == '\0')
    {
        printf("Invalid file name\n");
        return;
    }

    if (saveWithMode(editor, filename) == 0)
        printf("File saved successfully: %s\n", filename);
    else
        printf("File save cancelled/failed\n");
}
 void loadCommandLineFile(TextEditor *editor, const char *filename)
{
    if (file_exists(filename))
    {
        if (load_from_file(filename, editor) == 0)
        {
            printf("Command-line file loaded successfully: %s\n", filename);
            printf("Existing data is now available in the editor.\n");
        }
        else
        {
            printf("Could not load command-line file\n");
        }
    }
    else
    {
        printf("Command-line file does not exist: %s\n", filename);
        printf("It will be created when you save.\n");
    }
}

int main(int argc, char *argv[])
{
    TextEditor editor;
    DynamicArrayStack undoStack;
    DynamicArrayStack redoStack;
    char command[256];
    const char *currentFile = NULL;

    memset(&editor, 0, sizeof(editor));
    initStack(&undoStack);
    initStack(&redoStack);

    if (argc > 1)
    {
        currentFile = argv[1];
        loadCommandLineFile(&editor, currentFile);
    }

    while (1)
    {
        printMenu();
        printf("Enter command: ");

        if (fgets(command, sizeof(command), stdin) == NULL)
            break;

        command[strcspn(command, "\n")] = '\0';

        if (strcmp(command, "exit") == 0)
        {
            char choice[10];

            printf("Do you want to save TextEditor file (y/n): ");

            if (fgets(choice, sizeof(choice), stdin) != NULL &&
                (choice[0] == 'y' || choice[0] == 'Y'))
            {
                saveWithPrompt(&editor, currentFile);
            }

            break;
        }

        if (strcmp(command, "save") == 0)
        {
            saveWithPrompt(&editor, currentFile);
            continue;
        }

        if (strcmp(command, "saveas") == 0)
        {
            saveWithPrompt(&editor, NULL);
            continue;
        }

        if (strncmp(command, "insert", 6) == 0 &&
            (command[6] == '\0' || command[6] == ' '))
        {
            if (command[6] == '\0')
            {
                insertText(&editor, NULL, &undoStack, 1);
            }
            else
            {
                char *text = command + 7;

                if (*text != '\0')
                    insertText(&editor, text, &undoStack, 1);
                else
                    insertText(&editor, NULL, &undoStack, 1);
            }

            clearRedo(&redoStack);
        }
        else if (strcmp(command, "print") == 0)
        {
            displayText(&editor);
        }
        else if (strncmp(command, "delete", 6) == 0 &&
                 (command[6] == '\0' || command[6] == ' '))
        {
            if (command[6] == '\0')
            {
                deleteLine(&editor, &undoStack, 1);
                clearRedo(&redoStack);
            }
            else
            {
                char *number = command + 7;
                char *endptr;
                long value = strtol(number, &endptr, 10);

                if (*number == '\0' || *endptr != '\0' || value <= 0)
                {
                    printf("Invalid delete length\n");
                }
                else
                {
                    deleteCharacters(&editor, (int)value,
                                      &undoStack, 1);
                    clearRedo(&redoStack);
                }
            }
        }
        else if (strcmp(command, "undo") == 0)
        {
            undo(&editor, &undoStack, &redoStack);
        }
        else if (strcmp(command, "redo") == 0)
        {
            redo(&editor, &redoStack);
        }
        else
        {
            printf("Invalid command\n");
        }
    }

    freeEditor(&editor);
    freeStack(&undoStack);
    freeStack(&redoStack);

    return 0;
}
