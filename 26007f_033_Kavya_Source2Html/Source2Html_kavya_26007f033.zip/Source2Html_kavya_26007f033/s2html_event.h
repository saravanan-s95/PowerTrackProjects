
#ifndef S2HTML_EVENT_H
#define S2HTML_EVENT_H

#include <stdio.h>

typedef enum
{
    PEVENT_PREPROCESSOR_DIRECTIVE,
    PEVENT_SINGLE_LINE_COMMENT,
    PEVENT_MULTI_LINE_COMMENT,
    PEVENT_STRING,
    PEVENT_HEADER_FILE,
    PEVENT_NUMERIC_CONSTANT,
    PEVENT_RESERVED_KEYWORD,
    PEVENT_ASCII_CHAR,
    PEVENT_REGULAR_EXP,
    PEVENT_EOF
} pevent_type_t;

typedef enum
{
    USER_HEADER_FILE,
    SYSTEM_HEADER_FILE,
    RS_KEYWORD_DATA
} pevent_property_t;

typedef struct
{
    pevent_type_t type;
    pevent_property_t property;
    char data[1024];
} pevent_t;

pevent_t *get_parser_event(FILE *src_fp);

#endif

