
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "s2html_event.h"

#define WORD_BUFF_SIZE 100

static pevent_t pevent_data;
static int at_line_start = 1;
static int expect_header = 0;

static char *res_kwords_data[] = { "const", "volatile", "extern", "auto", "register",
    "static", "signed", "unsigned", "short", "long",
    "int", "char", "float", "double", "void",
    "if", "else", "switch", "case", "default",
    "break", "continue", "for", "while", "do",
    "return", "sizeof", "struct", "union", "enum",
    "typedef", "goto"};

#define KEYWORD_COUNT \
    (sizeof(res_kwords_data) / sizeof(res_kwords_data[0]))

static int is_reserved_keyword(const char *word)
{
    int i;

    for (i = 0; i < (int)KEYWORD_COUNT; i++)
    {
        if (strcmp(word, res_kwords_data[i]) == 0)
        {
            return 1;
        }
    }

    return 0;
}

static pevent_t *create_event(pevent_type_t type, pevent_property_t property, const char *data)
{
    pevent_data.type = type;
    pevent_data.property = property;

    snprintf(pevent_data.data, sizeof(pevent_data.data), "%s", data);

    return &pevent_data;
}

pevent_t *get_parser_event(FILE *src_fp)
{
    int ch;
    int next;
    int i = 0;
    char word[1024] = {0};

    if (src_fp == NULL)
    {
        return create_event(PEVENT_EOF, RS_KEYWORD_DATA, "");
    }

    ch = fgetc(src_fp);

    if (ch == EOF)
    {
        return create_event(PEVENT_EOF, RS_KEYWORD_DATA, "");
    }

    /* Preserve whitespace */
    if (isspace((unsigned char)ch))
    {
        word[i++] = (char)ch;
        word[i] = '\0';

        if (ch == '\n')
        {
            at_line_start = 1;
        }

        return create_event(PEVENT_REGULAR_EXP, RS_KEYWORD_DATA, word);
    }

    /* Preprocessor directive */
    if (ch == '#' && at_line_start)
    {
        word[i++] = (char)ch;

        while ((ch = fgetc(src_fp)) != EOF &&
               ch != '\n' && ch != '<' && ch != '"')
        {
            if (i < (int)sizeof(word) - 1)
            {
                word[i++] = (char)ch;
            }
        }

        word[i] = '\0';

        if (ch != EOF)
        {
            ungetc(ch, src_fp);
        }

        at_line_start = 0;
        if (strstr(word, "#include") != NULL)
        {
            expect_header = 1;
        }

        return create_event(PEVENT_PREPROCESSOR_DIRECTIVE, RS_KEYWORD_DATA, word);
    }

    /* Header file */
    if (expect_header && (ch == '<' || ch == '"'))
    {
        int closing_char = (ch == '<') ? '>' : '"';

        word[i++] = (char)ch;

        while ((ch = fgetc(src_fp)) != EOF)
        {
            if (i < (int)sizeof(word) - 1)
            {
                word[i++] = (char)ch;
            }

            if (ch == closing_char)
            {
                break;
            }
        }

        word[i] = '\0';
        expect_header = 0;

        return create_event(PEVENT_HEADER_FILE, (closing_char == '>') ? SYSTEM_HEADER_FILE : USER_HEADER_FILE, word);
    }


    if (ch != ' ' && ch != '\t' && ch != '\r')
    {
        at_line_start = 0;
    }

    /* Single-line or multi-line comment */
    if (ch == '/')
    {
        next = fgetc(src_fp);

        if (next == '/')
        {
            word[i++] = '/';
            word[i++] = '/';

            while ((ch = fgetc(src_fp)) != EOF)
            {
                if (i < (int)sizeof(word) - 1)
                {
                    word[i++] = (char)ch;
                    word[i] = '\0';
                }

                if (ch == '\n')
                {
                    at_line_start = 1;
                    break;
                }
            }

            return create_event(PEVENT_SINGLE_LINE_COMMENT, RS_KEYWORD_DATA, word);
        }

        if (next == '*')
        {
            int previous = 0;

            word[i++] = '/';
            word[i++] = '*';

            while ((ch = fgetc(src_fp)) != EOF)
            {
                if (i < (int)sizeof(word) - 1)
                {
                    word[i++] = (char)ch;
                    word[i] = '\0';
                }

                if (ch == '\n')
                {
                    at_line_start = 1;
                }

                if (previous == '*' && ch == '/')
                {
                    break;
                }

                previous = ch;
            }

            return create_event(PEVENT_MULTI_LINE_COMMENT, RS_KEYWORD_DATA, word);
        }

        if (next != EOF)
        {
            ungetc(next, src_fp);
        }

        word[0] = '/';
        word[1] = '\0';

        return create_event(PEVENT_REGULAR_EXP, RS_KEYWORD_DATA, word);
    }

    /* String literal */
    if (ch == '"')
    {
        word[i++] = '"';

        while ((ch = fgetc(src_fp)) != EOF)
        {
            if (i < (int)sizeof(word) - 1)
            {
                word[i++] = (char)ch;
                word[i] = '\0';
            }

            if (ch == '\\')
            {
                ch = fgetc(src_fp);

                if (ch == EOF)
                {
                    break;
                }

                if (i < (int)sizeof(word) - 1)
                {
                    word[i++] = (char)ch;
                    word[i] = '\0';
                }

                continue;
            }

            if (ch == '"')
            {
                break;
            }
        }

        return create_event(PEVENT_STRING, RS_KEYWORD_DATA, word);
    }

    /* ASCII character constant */
    if (ch == '\'')
    {
        word[i++] = '\'';

        while ((ch = fgetc(src_fp)) != EOF)
        {
            if (i < (int)sizeof(word) - 1)
            {
                word[i++] = (char)ch;
                word[i] = '\0';
            }

            if (ch == '\\')
            {
                ch = fgetc(src_fp);

                if (ch == EOF)
                {
                    break;
                }

                if (i < (int)sizeof(word) - 1)
                {
                    word[i++] = (char)ch;
                    word[i] = '\0';
                }

                continue;
            }

            if (ch == '\'')
            {
                break;
            }
        }

        return create_event(PEVENT_ASCII_CHAR, RS_KEYWORD_DATA, word);
    }

    /* Numeric constant */
    if (isdigit((unsigned char)ch))
    {
        word[i++] = (char)ch;

        while ((ch = fgetc(src_fp)) != EOF && (isalnum((unsigned char)ch) || ch == '.' || ch == '_'))
        {
            if (i < (int)sizeof(word) - 1)
            {
                word[i++] = (char)ch;
                word[i] = '\0';
            }
        }

        if (ch != EOF)
        {
            ungetc(ch, src_fp);
        }

        return create_event(PEVENT_NUMERIC_CONSTANT, RS_KEYWORD_DATA, word);
    }

    /* Identifier or reserved keyword */
    if (isalpha((unsigned char)ch) || ch == '_')
    {
        word[i++] = (char)ch;

        while ((ch = fgetc(src_fp)) != EOF && (isalnum((unsigned char)ch) || ch == '_'))
        {
            if (i < (int)sizeof(word) - 1)
            {
                word[i++] = (char)ch;
                word[i] = '\0';
            }
        }

        if (ch != EOF)
        {
            ungetc(ch, src_fp);
        }

        if (is_reserved_keyword(word))
        {
            return create_event(PEVENT_RESERVED_KEYWORD, RS_KEYWORD_DATA, word);
        }

        return create_event(PEVENT_REGULAR_EXP, RS_KEYWORD_DATA, word);
    }

    /* Other symbols and operators */
    word[0] = (char)ch;
    word[1] = '\0';

    return create_event(PEVENT_REGULAR_EXP, RS_KEYWORD_DATA, word);
}
