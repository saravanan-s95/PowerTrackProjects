
#include <stdio.h>
#include <string.h>
#include "s2html_event.h"
#include "s2html_conv.h"

int main(int argc, char *argv[])
{
    FILE *sfp, *dfp;
    pevent_t *event;
    char dest_file[200];

    if (argc < 2)
    {
        printf("Error! Please enter the file name.\n");
        printf("Usage: <executable> <filename> [output_name]\n");
        printf("Example: ./a.out abc.c\n");
        return 1;
    }

#ifdef DEBUG
    printf("File to be opened: %s\n", argv[1]);
#endif

    /* Open source file */
    sfp = fopen(argv[1], "r");

    if (sfp == NULL)
    {
        printf("Error! File %s could not be opened.\n", argv[1]);
        return 2;
    }

    /* Create destination filename */
    if (argc > 2)
    {
        snprintf(dest_file, sizeof(dest_file),
                 "%s.html", argv[2]);
    }
    else
    {
        snprintf(dest_file, sizeof(dest_file),
                 "%s.html", argv[1]);
    }

    /* Open destination file */
    dfp = fopen(dest_file, "w");

    if (dfp == NULL)
    {
        printf("Error! Could not create output file %s.\n",
               dest_file);
        fclose(sfp);
        return 3;
    }

    /* Generate HTML */
    html_begin(dfp, HTML_OPEN);

    do
    {
        event = get_parser_event(sfp);

        if (event == NULL)
        {
            printf("Error! Failed to get parser event.\n");
            fclose(sfp);
            fclose(dfp);
            return 4;
        }

        source_to_html(dfp, event);

    } while (event->type != PEVENT_EOF);

    html_end(dfp, HTML_CLOSE);

    printf("\nOutput file %s generated successfully.\n", dest_file);

    fclose(sfp);
    fclose(dfp);

    return 0;
}
