/* Code to print sum of 2 numbers */

#include <stdio.h>
int main()
{
    int a = 10;
    int b = 20;
    // print result
    printf("Sum = %d", a + b);
    return 0;
}
